# PLATAFORMA COMPUTAPLAY
## Gamificação e Acessibilidade no Ensino de Pensamento Computacional para Alunos do Ensino Fundamental II

---

### Informações do Projeto

**Instituição:** UNIPÊ
**Curso:** Ciência da Computação
**Disciplina:** Projeto Interdisciplinar I
**Período:** 2025.2

---

### Equipe do Projeto

| Nome | E-mail |
|------|--------|
| Luiz Henrique da Silva Araujo | luiz.araujo04@cs.unipe.edu.br |
| Kaua Douglas Pereira Moura | kaua.moura@cs.unipe.edu.br |
| Pedro Henrique Falcao | pedro.falcao@cs.unipe.edu.br|

---

### Orientação

**Professor Orientador:** Ricardo Dantas Silva
**Data de Apresentação:** 30/11/2025

---

**João Pessoa - PB**
**2025**
