# 3.4 DIAGRAMA DE SEQUÊNCIA

## 1. Sequência: Resolver Desafio

### Participantes:
- Aluno (Usuário)
- Interface
- Controlador de Desafio
- Validador de Código
- Executor de Blocos
- Gerenciador de Gamificação
- Banco de Dados

### Fluxo:

```
Aluno -> Interface: clicarDesafio(idDesafio)
Interface -> ControladorDesafio: carregarDesafio(idDesafio)
ControladorDesafio -> BD: buscarDesafio(idDesafio)
BD --> ControladorDesafio: dadosDesafio
ControladorDesafio --> Interface: exibirDesafio()
Interface --> Aluno: [Tela do desafio com editor]

Aluno -> Interface: arrastarBlocos()
Interface -> Interface: validarEncaixe()
Interface --> Aluno: [Feedback visual]

Aluno -> Interface: clicarExecutar()
Interface -> ValidadorCodigo: validarSintaxe(codigo)
ValidadorCodigo --> Interface: sintaxeValida = true

Interface -> ExecutorBlocos: executar(codigo)
ExecutorBlocos -> ExecutorBlocos: interpretarBlocos()
ExecutorBlocos --> Interface: animacaoExecucao
Interface --> Aluno: [Animação passo a passo]

ExecutorBlocos -> ControladorDesafio: verificarResultado(resultado)
ControladorDesafio -> ControladorDesafio: compararComSolucao()
ControladorDesafio --> ExecutorBlocos: sucessoStatus = true

ControladorDesafio -> GerenciadorGamificacao: calcularXP(tentativas, eficiencia)
GerenciadorGamificacao --> ControladorDesafio: xpGanho = 120

ControladorDesafio -> BD: salvarProgresso(alunoId, desafioId, xp)
BD --> ControladorDesafio: confirmacao

ControladorDesafio -> GerenciadorGamificacao: verificarMedalhas(aluno)
GerenciadorGamificacao -> BD: buscarConquistas(alunoId)
BD --> GerenciadorGamificacao: historicoConquistas
GerenciadorGamificacao --> ControladorDesafio: medalhaDesbloqueada = "Primeira Vitória"

ControladorDesafio -> Interface: exibirSucesso(xp, medalha)
Interface --> Aluno: [Tela de parabéns com animação]
```

---

## 2. Sequência: Criar Turma (Professor)

### Participantes:
- Professor
- Interface
- Controlador de Turma
- Gerador de Código
- Banco de Dados

### Fluxo:

```
Professor -> Interface: clicarNovaTurma()
Interface --> Professor: [Formulário de criação]

Professor -> Interface: preencherDados(nome, anoEscolar, escola)
Professor -> Interface: clicarCriar()

Interface -> ControladorTurma: criarTurma(dados)
ControladorTurma -> ControladorTurma: validarDados()

ControladorTurma -> GeradorCodigo: gerarCodigoUnico()
GeradorCodigo -> BD: verificarCodigoExiste(codigo)
BD --> GeradorCodigo: existe = false
GeradorCodigo --> ControladorTurma: codigo = "A3F7K2"

ControladorTurma -> BD: inserirTurma(dados, codigo, professorId)
BD --> ControladorTurma: turmaId = 12345

ControladorTurma -> BD: associarProfessorTurma(professorId, turmaId)
BD --> ControladorTurma: confirmacao

ControladorTurma --> Interface: turmaCriada(codigo, turmaId)
Interface --> Professor: [Exibir código em formato grande]
```

---

## 3. Sequência: Identificar Aluno com Dificuldades (Automático)

### Participantes:
- Sistema (Job Scheduler)
- Analisador de Progresso
- Banco de Dados
- Gerador de Alertas
- Serviço de Notificação

### Fluxo:

```
Sistema -> AnalisadorProgresso: executarAnalise()

loop Para cada turma ativa
    AnalisadorProgresso -> BD: buscarAlunosTurma(turmaId)
    BD --> AnalisadorProgresso: listaAlunos[]

    loop Para cada aluno
        AnalisadorProgresso -> BD: buscarHistoricoRecente(alunoId, 7dias)
        BD --> AnalisadorProgresso: historicoDesafios[]

        AnalisadorProgresso -> AnalisadorProgresso: analisarPadroes(historico)
        AnalisadorProgresso -> AnalisadorProgresso: aplicarCriterios()

        alt Se detectou dificuldade
            AnalisadorProgresso -> GeradorAlertas: criarAlerta(alunoId, tipo, severidade)
            GeradorAlertas -> BD: buscarConceitoComDificuldade(alunoId)
            BD --> GeradorAlertas: conceito = "Loops"

            GeradorAlertas -> GeradorAlertas: gerarSugestoes(conceito)
            GeradorAlertas -> BD: salvarAlerta(alerta)
            BD --> GeradorAlertas: alertaId

            GeradorAlertas -> ServicoNotificacao: notificarProfessor(professorId, alertaId)
            ServicoNotificacao --> Professor: [Notificação push/email]
        end
    end
end

AnalisadorProgresso --> Sistema: analiseCompleta()
```

---

## Código PlantUML - Exemplo: Resolver Desafio

```plantuml
@startuml
actor Aluno
participant "Interface" as UI
participant "Controlador\nDesafio" as Controller
participant "Validador\nCódigo" as Validator
participant "Executor\nBlocos" as Executor
participant "Gerenciador\nGamificacao" as Gamification
database "BD" as DB

Aluno -> UI: clicarDesafio(idDesafio)
UI -> Controller: carregarDesafio(idDesafio)
Controller -> DB: buscarDesafio(idDesafio)
DB --> Controller: dadosDesafio
Controller --> UI: exibirDesafio()
UI --> Aluno: [Tela do editor]

Aluno -> UI: arrastarBlocos()
UI -> UI: validarEncaixe()
UI --> Aluno: [Feedback visual]

Aluno -> UI: clicarExecutar()
UI -> Validator: validarSintaxe(codigo)
Validator --> UI: sintaxeValida

UI -> Executor: executar(codigo)
Executor -> Executor: interpretarBlocos()
Executor --> UI: animacao
UI --> Aluno: [Animação]

Executor -> Controller: verificarResultado()
Controller -> Gamification: calcularXP(tentativas, eficiencia)
Gamification --> Controller: xp = 120

Controller -> DB: salvarProgresso()
DB --> Controller: OK

Controller -> Gamification: verificarMedalhas()
Gamification --> Controller: medalha

Controller -> UI: exibirSucesso(xp, medalha)
UI --> Aluno: [Parabéns!]

@enduml
```

## Entregáveis

1. **sequencia-resolver-desafio.png**
2. **sequencia-criar-turma.png**
3. **sequencia-identificar-dificuldades.png**

Local: `/diagramas/`
