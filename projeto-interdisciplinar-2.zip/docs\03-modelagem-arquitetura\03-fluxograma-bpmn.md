# 3.3 FLUXOGRAMAS E BPMN

## 1. FLUXOGRAMA: Resolução de Desafio pelo Aluno

### Descrição
Fluxo completo desde a seleção até a conclusão de um desafio.

### Passos:

```
[INÍCIO]
   ↓
[Aluno seleciona desafio]
   ↓
<Desafio está desbloqueado?> ─NO─> [Exibir mensagem: Complete desafios anteriores] → [FIM]
   ↓ YES
[Carregar interface do desafio]
   ↓
[Exibir descrição e objetivo]
   ↓
[Exibir editor de blocos]
   ↓
[Aluno arrasta blocos]
   ↓
<Blocos se encaixam corretamente?> ─NO─> [Feedback visual de erro] → [Retornar para arrastar blocos]
   ↓ YES
[Salvar progresso automaticamente]
   ↓
<Aluno clica em "Executar"?> ─NO─> [Aguardar ação] → [Loop]
   ↓ YES
[Validar sintaxe do código]
   ↓
<Sintaxe válida?> ─NO─> [Exibir erro específico] → [Retornar para editar]
   ↓ YES
[Executar animação passo a passo]
   ↓
[Verificar resultado]
   ↓
<Objetivo atingido?> ─NO─> [Incrementar contador de tentativas]
   ↓                        ↓
   ↓                   <Tentativas > 3?> ─YES─> [Oferecer dica]
   ↓                        ↓ NO
   ↓                   [Exibir feedback de erro]
   ↓                        ↓
   ↓                   [Retornar para editar]
   ↓ YES
[Calcular XP (base + bônus - penalidades)]
   ↓
[Conceder XP ao aluno]
   ↓
[Atualizar progresso do desafio]
   ↓
[Verificar critérios de medalhas]
   ↓
<Medalha desbloqueada?> ─YES─> [Exibir animação de conquista]
   ↓ NO                          ↓
[Verificar XP total]            [Registrar medalha]
   ↓                             ↓
<Subiu de nível?> ─YES─> [Exibir animação de nível] → [Desbloquear novos conteúdos]
   ↓ NO
[Salvar progresso final]
   ↓
[Exibir tela de sucesso com estatísticas]
   ↓
[Desbloquear próximo desafio]
   ↓
[FIM]
```

---

## 2. BPMN: Criação de Turma pelo Professor

### Descrição
Processo de negócio para criação e configuração de uma turma.

### Raias (Lanes):
- **Professor**
- **Sistema**
- **Banco de Dados**

### Processo:

```
[INÍCIO - Professor]
   ↓
[Acessa seção "Minhas Turmas"]
   ↓
[Clica em "Nova Turma"]
   ↓
[Sistema exibe formulário]
   ↓
[Professor preenche dados:
 - Nome da turma
 - Ano escolar (6-9)
 - Escola]
   ↓
[Professor clica em "Criar"]
   ↓
┌────────────────────────────────────┐
│        SISTEMA PROCESSA            │
├────────────────────────────────────┤
│ [Validar dados do formulário]      │
│   ↓                                │
│ <Dados válidos?> ─NO─> [Exibir erro] → [Retornar]
│   ↓ YES                            │
│ [Gerar código único 6 caracteres] │
│   ↓                                │
│ [Verificar se código já existe]   │
│   ↓                                │
│ <Código único?> ─NO─> [Gerar novo código] → [Loop]
│   ↓ YES                            │
│ [Criar registro no BD]            │
│   ↓                                │
│ [Associar professor à turma]      │
│   ↓                                │
│ [Enviar confirmação]              │
└────────────────────────────────────┘
   ↓
[Sistema exibe código em formato grande]
   ↓
[Oferecer opções:
 ○ Imprimir código
 ○ Projetar código
 ○ Copiar para compartilhar]
   ↓
<Professor escolhe ação?> ─YES─> [Executar ação]
   ↓ NO
[Turma criada com sucesso]
   ↓
[FIM]
```

---

## 3. FLUXOGRAMA: Identificação Automática de Dificuldades

### Descrição
Processo automatizado que monitora alunos e gera alertas.

```
[INÍCIO - Evento: Aluno conclui tentativa]
   ↓
[Sistema registra dados:
 - Desafio ID
 - Aluno ID
 - Sucesso/Falha
 - Tempo gasto
 - Tentativas]
   ↓
[Buscar histórico do aluno (últimos 7 dias)]
   ↓
┌────────────────────────────────────┐
│    ANÁLISE DE PADRÕES              │
├────────────────────────────────────┤
│ Verificar Critério 1:              │
│ <3+ tentativas erradas em 3        │
│  desafios consecutivos?>           │
│   ↓ YES                            │
│ [Marcar FLAG_DIFICULDADE_CONCEITO] │
│                                    │
│ Verificar Critério 2:              │
│ <Tempo médio > 50% acima           │
│  da média da turma?>               │
│   ↓ YES                            │
│ [Marcar FLAG_LENTIDAO]             │
│                                    │
│ Verificar Critério 3:              │
│ <0 desafios concluídos em 7 dias   │
│  com aluno ativo?>                 │
│   ↓ YES                            │
│ [Marcar FLAG_INATIVIDADE]          │
└────────────────────────────────────┘
   ↓
<Alguma FLAG marcada?> ─NO─> [FIM]
   ↓ YES
[Determinar severidade:
 - 1 FLAG = ATENÇÃO (Amarelo)
 - 2+ FLAGS = URGENTE (Vermelho)]
   ↓
[Identificar conceito específico com dificuldade]
   ↓
[Buscar sugestões de atividades remediais]
   ↓
[Criar objeto Alerta]
   ↓
[Salvar no banco de dados]
   ↓
[Associar ao Dashboard do professor]
   ↓
[Enviar notificação ao professor]
   ↓
[FIM]
```

---

## 4. BPMN: Geração de Relatório de Desempenho

### Raias:
- **Professor**
- **Sistema**
- **Gerador de Relatórios**
- **Banco de Dados**

```
[INÍCIO - Professor]
   ↓
[Acessa seção "Relatórios"]
   ↓
[Seleciona tipo: Individual/Turma]
   ↓
[Seleciona alunos (se individual)]
   ↓
[Define período: última semana/mês/customizado]
   ↓
[Escolhe formato: PDF/CSV]
   ↓
[Clica em "Gerar Relatório"]
   ↓
┌────────────────────────────────────┐
│        SISTEMA PROCESSA            │
├────────────────────────────────────┤
│ [Validar parâmetros]               │
│   ↓                                │
│ [Buscar dados no BD:               │
│  - Desafios concluídos             │
│  - XP ganho                        │
│  - Tempo médio                     │
│  - Medalhas conquistadas           │
│  - Competências BNCC atingidas]    │
│   ↓                                │
│ [Calcular estatísticas agregadas]  │
│   ↓                                │
│ [Gerar gráficos]                   │
│   ↓                                │
│ <Formato PDF?> ─YES─> [Template visual com gráficos]
│   ↓ NO (CSV)                       │
│ [Exportar dados tabulares]         │
└────────────────────────────────────┘
   ↓
[Criar arquivo temporário]
   ↓
[Disponibilizar link de download]
   ↓
[Notificar professor: "Relatório pronto"]
   ↓
[Professor clica em download]
   ↓
[Arquivo baixado]
   ↓
[Sistema registra log de exportação]
   ↓
[Agendar exclusão do arquivo após 24h]
   ↓
[FIM]
```

---

## 5. FLUXOGRAMA: Pedido de Ajuda entre Colegas

```
[INÍCIO]
   ↓
[Aluno está em desafio com dificuldade]
   ↓
[Clica em "Pedir Ajuda a Colega"]
   ↓
[Sistema busca colegas elegíveis:
 - Online
 - Já resolveram este desafio
 - Mesma turma]
   ↓
<Há colegas disponíveis?> ─NO─> [Exibir: "Nenhum colega disponível"] → [Sugerir dicas] → [FIM]
   ↓ YES
[Exibir lista de colegas (máx 5)]
   ↓
[Aluno seleciona colega]
   ↓
[Sistema envia notificação ao colega]
   ↓
[Aguardar resposta (timeout 2min)]
   ↓
<Colega aceita?> ─NO─> [Notificar solicitante] → [Sugerir outro colega] → [Loop]
   ↓ YES
[Abrir chat temporário]
   ↓
[Exibir código do solicitante para ajudante]
   ↓
[Permitir troca de mensagens (limitadas)]
   ↓
[Ajudante fornece orientações]
   ↓
<Solicitante marca "Ajuda Concluída"?> ─NO─> [Aguardar] → [Loop]
   ↓ YES
[Sistema concede XP bônus ao ajudante (+15 XP)]
   ↓
[Verificar critério de medalha "Ajudante"]
   ↓
<Ajudou 3+ colegas?> ─YES─> [Conceder medalha]
   ↓ NO
[Fechar chat]
   ↓
[Salvar log da interação]
   ↓
[Exibir mensagem de agradecimento]
   ↓
[FIM]
```

---

## Símbolos Utilizados

### Fluxograma
- `[   ]` = Processo/Ação
- `<   >` = Decisão (if/else)
- `(   )` = Início/Fim
- `→` = Fluxo de sequência

### BPMN
- `○` = Evento de início/fim
- `□` = Tarefa
- `◇` = Gateway (decisão)
- `┌─┐` = Subprocesso
- `||` = Gateway paralelo
- `⊕` = Gateway exclusivo

## Modelagem

Os diagramas serão criados seguindo a notação BPMN 2.0 padrão, utilizando ferramentas de modelagem de processos.

## Entregáveis

1. **fluxograma-resolucao-desafio.png**
2. **bpmn-criacao-turma.png**
3. **fluxograma-identificacao-dificuldades.png**
4. **bpmn-geracao-relatorio.png**
5. **fluxograma-ajuda-colegas.png**

Local: `/diagramas/`
