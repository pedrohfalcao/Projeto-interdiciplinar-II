# 3.2 DIAGRAMA DE CLASSES

## Visão Geral

O diagrama de classes representa a estrutura estática do sistema ComputaPlay, mostrando as principais classes, seus atributos, métodos e relacionamentos.

## Classes Principais

### 1. CLASSE: Usuario (Abstrata)
**Responsabilidade**: Classe base para todos os usuários do sistema

**Atributos**:
- id: String (PK)
- nome: String
- email: String (unique)
- senha: String (hash)
- dataCriacao: DateTime
- ultimoAcesso: DateTime
- preferenciasAcessibilidade: PreferenciasAcessibilidade

**Métodos**:
+ autenticar(email: String, senha: String): Boolean
+ alterarSenha(senhaAtual: String, novaSenha: String): Boolean
+ atualizarPerfil(dados: Object): Boolean
+ exportarDados(): JSON

---

### 2. CLASSE: Aluno (herda de Usuario)
**Responsabilidade**: Representa um estudante que usa a plataforma

**Atributos**:
- idTurma: String (FK)
- avatar: Avatar
- xpTotal: Integer
- nivelAtual: Integer
- medalhas: List<Medalha>
- desafiosConcluidos: List<ProgressoDesafio>

**Métodos**:
+ ganharXP(quantidade: Integer): void
+ subirNivel(): void
+ desbloquearMedalha(medalha: Medalha): void
+ selecionarDesafio(desafio: Desafio): void
+ salvarProgresso(codigo: CodigoEmBlocos): void
+ calcularPontuacaoRanking(): Float

---

### 3. CLASSE: Professor (herda de Usuario)
**Responsabilidade**: Gerencia turmas e acompanha progresso dos alunos

**Atributos**:
- instituicao: String
- turmas: List<Turma>
- documentoIdentificacao: String

**Métodos**:
+ criarTurma(nome: String, anoEscolar: Integer): Turma
+ visualizarDashboard(turma: Turma): Dashboard
+ gerarRelatorio(turma: Turma, periodo: DateRange): Relatorio
+ identificarDificuldades(turma: Turma): List<Alerta>
+ atribuirTarefa(aluno: Aluno, desafio: Desafio): void

---

### 4. CLASSE: Administrador (herda de Usuario)
**Responsabilidade**: Gerencia conteúdo e configurações do sistema

**Atributos**:
- permissoes: List<String>

**Métodos**:
+ criarDesafio(dados: Object): Desafio
+ editarDesafio(id: String, dados: Object): Boolean
+ excluirDesafio(id: String): Boolean
+ moderarConteudo(): void
+ visualizarLogs(): List<Log>

---

### 5. CLASSE: Turma
**Responsabilidade**: Agrupa alunos e gerencia código de acesso

**Atributos**:
- id: String (PK)
- nome: String
- anoEscolar: Integer (6-9)
- escola: String
- codigoAcesso: String (unique, 6 chars)
- professor: Professor (FK)
- alunos: List<Aluno>
- dataCriacao: DateTime
- ativa: Boolean

**Métodos**:
+ gerarCodigoAcesso(): String
+ adicionarAluno(aluno: Aluno): Boolean
+ removerAluno(aluno: Aluno): Boolean
+ calcularEstatisticas(): Estatisticas
+ listarAlunosComDificuldades(): List<Aluno>

---

### 6. CLASSE: Desafio
**Responsabilidade**: Representa um desafio/exercício de programação

**Atributos**:
- id: String (PK)
- titulo: String
- descricao: String
- dificuldade: Enum (FACIL, MEDIO, DIFICIL, EXPERT)
- xpBase: Integer
- anoEscolarRecomendado: Integer
- competenciasBNCC: List<String>
- pilarPensamentoComputacional: Enum
- blocosDisponiveis: List<TipoBloco>
- solucaoEsperada: CodigoEmBlocos
- dicas: List<Dica>
- contextualizacao: String (narrativa)
- temaCultural: String

**Métodos**:
+ validarSolucao(codigo: CodigoEmBlocos): Boolean
+ calcularXP(eficiencia: Float, tentativas: Integer): Integer
+ obterDica(nivel: Integer): Dica
+ verificarPreRequisitos(aluno: Aluno): Boolean

---

### 7. CLASSE: CodigoEmBlocos
**Responsabilidade**: Representa o código criado pelo aluno

**Atributos**:
- blocos: List<Bloco>
- ordem: List<Integer>
- dataModificacao: DateTime

**Métodos**:
+ adicionarBloco(bloco: Bloco, posicao: Integer): void
+ removerBloco(posicao: Integer): void
+ validarSintaxe(): Boolean
+ executar(): ResultadoExecucao
+ calcularEficiencia(): Float
+ serializar(): JSON

---

### 8. CLASSE: Bloco (Abstrata)
**Responsabilidade**: Classe base para blocos de programação

**Atributos**:
- id: String
- tipo: TipoBloco
- parametros: Map<String, Object>

**Métodos Abstratos**:
+ executar(): void
+ validar(): Boolean
+ clonar(): Bloco

**Subclasses**:
- BlocoMovimento
- BlocoLoop
- BlocoCondicional
- BlocoVariavel
- BlocoFuncao

---

### 9. CLASSE: BlocoLoop (herda de Bloco)
**Atributos**:
- tipoLoop: Enum (PARA, ENQUANTO)
- condicao: String
- iteracoes: Integer
- blocoInterno: List<Bloco>

**Métodos**:
+ executar(): void
+ validar(): Boolean

---

### 10. CLASSE: BlocoCondicional (herda de Bloco)
**Atributos**:
- condicao: String
- blocosSeVerdadeiro: List<Bloco>
- blocosSeFalso: List<Bloco>

**Métodos**:
+ executar(): void
+ validar(): Boolean

---

### 11. CLASSE: ProgressoDesafio
**Responsabilidade**: Registra o progresso do aluno em um desafio

**Atributos**:
- id: String (PK)
- aluno: Aluno (FK)
- desafio: Desafio (FK)
- status: Enum (NAO_INICIADO, EM_PROGRESSO, CONCLUIDO)
- tentativas: Integer
- tempoGasto: Integer (segundos)
- xpGanho: Integer
- codigoFinal: CodigoEmBlocos
- dicasUsadas: Integer
- dataInicio: DateTime
- dataConclusao: DateTime

**Métodos**:
+ iniciar(): void
+ concluir(codigo: CodigoEmBlocos): void
+ incrementarTentativa(): void
+ usarDica(): void

---

### 12. CLASSE: Medalha
**Responsabilidade**: Representa uma conquista desbloqueável

**Atributos**:
- id: String (PK)
- nome: String
- descricao: String
- categoria: Enum (PROGRESSO, MAESTRIA, COLABORACAO, ESPECIAL)
- icone: String (URL)
- criterio: String (JSON com condições)
- raridade: Enum (BRONZE, PRATA, OURO, ESPECIAL)

**Métodos**:
+ verificarCriterio(aluno: Aluno): Boolean
+ conceder(aluno: Aluno): void

---

### 13. CLASSE: Avatar
**Responsabilidade**: Personalização visual do aluno

**Atributos**:
- tomPele: String
- cabelo: String
- roupa: String
- acessorios: List<String>
- itensDesbloqueados: List<String>

**Métodos**:
+ customizar(item: String, tipo: TipoItem): Boolean
+ desbloquearItem(item: String): void
+ renderizar(): Image

---

### 14. CLASSE: Dashboard
**Responsabilidade**: Consolida dados de desempenho para professores

**Atributos**:
- turma: Turma (FK)
- estatisticas: Estatisticas
- alertas: List<Alerta>
- graficos: List<Grafico>

**Métodos**:
+ atualizarDados(): void
+ filtrarPorPeriodo(inicio: Date, fim: Date): void
+ exportar(formato: String): File

---

### 15. CLASSE: Alerta
**Responsabilidade**: Notifica professor sobre dificuldades de alunos

**Atributos**:
- id: String (PK)
- aluno: Aluno (FK)
- tipo: Enum (ATENCAO, URGENTE)
- descricao: String
- sugestoes: List<String>
- dataGeracao: DateTime
- visualizado: Boolean

**Métodos**:
+ marcarComoVisualizado(): void
+ gerarSugestoes(): List<String>

---

### 16. CLASSE: Relatorio
**Responsabilidade**: Gera relatórios exportáveis

**Atributos**:
- titulo: String
- periodo: DateRange
- dados: Object
- formato: Enum (PDF, CSV)

**Métodos**:
+ gerar(): File
+ exportar(caminho: String): Boolean

---

### 17. CLASSE: PlanoDeAula
**Responsabilidade**: Recurso pedagógico pronto para professores

**Atributos**:
- id: String (PK)
- titulo: String
- anoEscolar: Integer
- conceito: String
- objetivos: List<String>
- tempoEstimado: Integer (minutos)
- materiais: List<String>
- passoPasso: List<String>
- competenciasBNCC: List<String>
- atividadesDesplugadas: List<AtividadeDesplugada>

**Métodos**:
+ visualizar(): void
+ editar(modificacoes: Object): PlanoDeAula
+ exportarPDF(): File

---

### 18. CLASSE: AtividadeDesplugada
**Responsabilidade**: Atividade sem computador

**Atributos**:
- id: String (PK)
- titulo: String
- conceito: String
- duracao: Integer (minutos)
- materiaisNecessarios: List<String>
- instrucoes: String
- avaliacaoSugerida: String

**Métodos**:
+ visualizar(): void
+ imprimir(): File

---

### 19. CLASSE: PreferenciasAcessibilidade
**Responsabilidade**: Configurações de acessibilidade do usuário

**Atributos**:
- tamanhoFonte: Enum (P, M, G, XG)
- tema: Enum (CLARO, ESCURO, ALTO_CONTRASTE)
- leitorTela: Boolean
- navegacaoTeclado: Boolean
- legendasAtivas: Boolean

**Métodos**:
+ aplicar(): void
+ resetarPadrao(): void

---

### 20. CLASSE: Ranking
**Responsabilidade**: Calcula e exibe classificação da turma

**Atributos**:
- turma: Turma (FK)
- periodo: DateRange
- posicoes: List<PosicaoRanking>

**Métodos**:
+ calcular(): void
+ obterTopN(n: Integer): List<PosicaoRanking>
+ obterPosicao(aluno: Aluno): Integer

---

### 21. CLASSE: PosicaoRanking
**Atributos**:
- aluno: Aluno (FK)
- pontuacao: Float
- posicao: Integer

---

## Relacionamentos entre Classes

### Herança
- `Aluno`, `Professor`, `Administrador` **herdam de** `Usuario`
- `BlocoLoop`, `BlocoCondicional`, `BlocoMovimento`, etc. **herdam de** `Bloco`

### Composição (◆)
- `Usuario` **compõe** `PreferenciasAcessibilidade` (1:1)
- `Aluno` **compõe** `Avatar` (1:1)
- `CodigoEmBlocos` **compõe** `List<Bloco>` (1:*)
- `Desafio` **compõe** `List<Dica>` (1:*)

### Agregação (◇)
- `Turma` **agrega** `List<Aluno>` (1:*)
- `Professor` **agrega** `List<Turma>` (1:*)
- `Aluno` **agrega** `List<Medalha>` (1:*)
- `Aluno` **agrega** `List<ProgressoDesafio>` (1:*)

### Associação (—)
- `ProgressoDesafio` **associa** `Aluno` e `Desafio` (M:N)
- `Dashboard` **associa** `Turma` (1:1)
- `Alerta` **associa** `Aluno` (1:*)
- `Ranking` **associa** `Turma` (1:1)

### Dependência (- - >)
- `Desafio` **depende de** `CodigoEmBlocos` para validação
- `Dashboard` **depende de** `Estatisticas`
- `Relatorio` **depende de** `Dashboard`

## Multiplicidade

| Relacionamento | Multiplicidade |
|----------------|----------------|
| Professor - Turma | 1..* (um professor, várias turmas) |
| Turma - Aluno | 1..50 (uma turma, até 50 alunos) |
| Aluno - ProgressoDesafio | 1..* (um aluno, vários progressos) |
| Desafio - ProgressoDesafio | 1..* (um desafio, vários alunos) |
| Aluno - Medalha | *..* (muitos-para-muitos) |
| CodigoEmBlocos - Bloco | 1..* (um código, vários blocos) |

## Código PlantUML (Exemplo Simplificado)

```plantuml
@startuml
abstract class Usuario {
  - id: String
  - nome: String
  - email: String
  - senha: String
  + autenticar()
  + alterarSenha()
}

class Aluno {
  - xpTotal: Integer
  - nivelAtual: Integer
  + ganharXP()
  + subirNivel()
}

class Professor {
  - instituicao: String
  + criarTurma()
  + gerarRelatorio()
}

class Turma {
  - nome: String
  - codigoAcesso: String
  + gerarCodigoAcesso()
  + adicionarAluno()
}

class Desafio {
  - titulo: String
  - dificuldade: Enum
  - xpBase: Integer
  + validarSolucao()
  + calcularXP()
}

class CodigoEmBlocos {
  - blocos: List<Bloco>
  + executar()
  + validarSintaxe()
}

abstract class Bloco {
  - tipo: TipoBloco
  + executar()
  + validar()
}

class Medalha {
  - nome: String
  - categoria: Enum
  + verificarCriterio()
}

Usuario <|-- Aluno
Usuario <|-- Professor
Professor "1" o-- "*" Turma
Turma "1" o-- "1..*" Aluno
Aluno "1" *-- "1" Avatar
Aluno "1" -- "*" ProgressoDesafio
Desafio "1" -- "*" ProgressoDesafio
Aluno "*" -- "*" Medalha
CodigoEmBlocos "1" *-- "*" Bloco
Bloco <|-- BlocoLoop
Bloco <|-- BlocoCondicional

@enduml
```

## Observações

1. O diagrama completo deve incluir todas as 21 classes
2. Destacar classes principais com cores diferentes
3. Incluir getters/setters implícitos (não listar todos)
4. Focar em métodos de lógica de negócio
5. Usar pacotes para organizar classes relacionadas:
   - `model.usuario` (Usuario, Aluno, Professor)
   - `model.desafio` (Desafio, Bloco, CodigoEmBlocos)
   - `model.gamificacao` (Medalha, Ranking)
   - `model.gestao` (Turma, Dashboard, Relatorio)

## Entregável

- **Arquivo**: diagrama-classes.png (ou .pdf)
- **Local**: `/diagramas/diagrama-classes.png`
- **Resolução mínima**: 2560x1440px (diagrama grande)
