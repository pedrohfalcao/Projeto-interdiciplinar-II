# 2.2 HISTÓRIAS DE USUÁRIO

As histórias de usuário descrevem funcionalidades do ponto de vista de quem as utilizará, seguindo o formato: "Como [tipo de usuário], eu quero [ação/recurso] para [benefício/objetivo]".

---

## ÉPICO 1: Cadastro e Onboarding

### HU01 - Cadastro de Aluno
**Como** aluno do Ensino Fundamental II,
**Quero** me cadastrar na plataforma usando um código de turma,
**Para** começar a aprender pensamento computacional.

**Critérios de Aceitação:**
- Formulário solicita: nome, usuário, senha e código da turma
- Código da turma é validado em tempo real
- Senha deve ter no mínimo 6 caracteres
- Confirmação de cadastro enviada ao e-mail (opcional)
- Redirecionamento automático para tutorial inicial

**Prioridade:** Alta | **Estimativa:** 5 pontos

---

### HU02 - Criação de Avatar
**Como** aluno,
**Quero** criar e personalizar meu avatar,
**Para** me sentir representado na plataforma e ter uma experiência mais pessoal.

**Critérios de Aceitação:**
- Opções diversificadas de tons de pele, cabelos, roupas e acessórios
- Prévia do avatar em tempo real
- Possibilidade de editar avatar depois
- Novos itens desbloqueados conforme progresso

**Prioridade:** Média | **Estimativa:** 8 pontos

---

### HU03 - Tutorial Inicial Interativo
**Como** aluno sem experiência em programação,
**Quero** fazer um tutorial interativo que me ensine os controles básicos,
**Para** entender como usar a plataforma sem precisar de ajuda.

**Critérios de Aceitação:**
- Tutorial com no máximo 5 passos simples
- Explicações em linguagem adequada à faixa etária
- Impossível pular tutorial na primeira vez
- Pode ser revisitado depois através do menu de ajuda
- Conclusão do tutorial concede primeira medalha

**Prioridade:** Alta | **Estimativa:** 8 pontos

---

## ÉPICO 2: Programação em Blocos

### HU04 - Resolver Desafio com Blocos
**Como** aluno,
**Quero** arrastar e soltar blocos de comandos para resolver desafios,
**Para** criar algoritmos de forma visual e intuitiva.

**Critérios de Aceitação:**
- Editor visual com área de blocos disponíveis e área de trabalho
- Blocos se encaixam apenas se sintaxe correta
- Feedback visual de encaixe (cores, animações)
- Botão "Executar" claramente visível
- Possibilidade de desfazer e refazer ações

**Prioridade:** Alta | **Estimativa:** 13 pontos

---

### HU05 - Executar Algoritmo e Ver Resultado
**Como** aluno,
**Quero** executar meu código e ver uma animação visual do resultado,
**Para** entender se minha solução está correta.

**Critérios de Aceitação:**
- Execução passo a passo com animação
- Controles de play, pause, reiniciar
- Velocidade de execução ajustável
- Indicação clara de sucesso ou falha
- Explicação do erro quando falhar

**Prioridade:** Alta | **Estimativa:** 13 pontos

---

### HU06 - Receber Dicas Quando Travado
**Como** aluno com dificuldade em um desafio,
**Quero** receber dicas progressivas,
**Para** conseguir resolver o problema sem que a resposta seja entregue.

**Critérios de Aceitação:**
- Botão "Preciso de Ajuda" sempre visível
- Dicas reveladas gradualmente (3 níveis)
- Primeira dica: conceito geral
- Segunda dica: estratégia específica
- Terceira dica: quase a solução (mas não completa)
- Dicas não reduzem XP ganho

**Prioridade:** Alta | **Estimativa:** 8 pontos

---

### HU07 - Usar Diferentes Tipos de Blocos
**Como** aluno avançando na trilha,
**Quero** desbloquear e usar novos tipos de blocos (loops, condicionais, variáveis),
**Para** resolver desafios mais complexos.

**Critérios de Aceitação:**
- Blocos básicos: movimento, ações simples
- Blocos intermediários: loops (para, enquanto)
- Blocos avançados: condicionais (se, senão)
- Blocos expert: variáveis, funções
- Introdução de cada novo tipo através de desafio tutorial
- Referência rápida dos blocos disponível

**Prioridade:** Alta | **Estimativa:** 13 pontos

---

## ÉPICO 3: Gamificação e Engajamento

### HU08 - Ganhar Pontos de Experiência (XP)
**Como** aluno,
**Quero** ganhar XP ao completar desafios,
**Para** ver meu progresso e me sentir recompensado.

**Critérios de Aceitação:**
- XP exibido claramente após conclusão do desafio
- Animação celebratória ao ganhar XP
- Barra de progresso para próximo nível visível
- XP varia conforme dificuldade do desafio
- Bônus por soluções eficientes (menos blocos usados)

**Prioridade:** Média | **Estimativa:** 5 pontos

---

### HU09 - Desbloquear Medalhas
**Como** aluno,
**Quero** conquistar medalhas por diferentes realizações,
**Para** colecionar conquistas e me motivar a explorar todas as funcionalidades.

**Critérios de Aceitação:**
- Galeria de medalhas mostrando conquistadas e bloqueadas
- Notificação animada ao desbloquear medalha
- Descrição clara de como conquistar cada medalha
- Categorias: Progresso, Colaboração, Maestria, Especiais
- Exemplos: "Primeira Vitória", "Ajudante", "Mestre do Loop", "Maratonista" (10 desafios em um dia)

**Prioridade:** Média | **Estimativa:** 8 pontos

---

### HU10 - Subir de Nível
**Como** aluno,
**Quero** subir de nível conforme acumulo XP,
**Para** desbloquear novos conteúdos e ver minha evolução.

**Critérios de Aceitação:**
- Sistema de níveis de 1 a 50
- Cada nível requer mais XP que o anterior
- Animação especial ao subir de nível
- Desbloqueio de novos itens de avatar
- Mensagem indicando o que foi desbloqueado

**Prioridade:** Média | **Estimativa:** 5 pontos

---

### HU11 - Ver Ranking da Turma
**Como** aluno,
**Quero** ver minha posição no ranking da turma,
**Para** me comparar com colegas de forma saudável.

**Critérios de Aceitação:**
- Ranking mostra top 10 + posição do usuário
- Pontuação considera XP (60%) + colaboração (40%)
- Não identificar alunos nas últimas posições (privacidade)
- Pode ser desativado pelo professor
- Mensagens motivacionais para todas as posições

**Prioridade:** Baixa | **Estimativa:** 5 pontos

---

### HU12 - Acompanhar Narrativa do Jogo
**Como** aluno,
**Quero** seguir uma história envolvente enquanto resolvo desafios,
**Para** me sentir imerso em uma aventura.

**Critérios de Aceitação:**
- Narrativa baseada em elementos culturais paraibanos
- Personagens carismáticos que guiam a jornada
- Missões temáticas (ex: "Festival Junino de São João")
- História avança com progresso do aluno
- Diálogos curtos e adequados à faixa etária

**Prioridade:** Média | **Estimativa:** 13 pontos

---

## ÉPICO 4: Colaboração

### HU13 - Resolver Desafio em Equipe
**Como** aluno,
**Quero** trabalhar com colegas para resolver desafios colaborativos,
**Para** aprender a trabalhar em equipe e ajudar uns aos outros.

**Critérios de Aceitação:**
- Professor pode criar grupos de 2-4 alunos
- Cada aluno vê código dos colegas em tempo real
- Chat simples para coordenação (moderado)
- XP dividido igualmente entre participantes
- Medalha específica para desafios colaborativos

**Prioridade:** Baixa | **Estimativa:** 21 pontos

---

### HU14 - Pedir Ajuda a Colega
**Como** aluno com dificuldade,
**Quero** pedir ajuda a um colega que já resolveu o desafio,
**Para** aprender com quem entendeu a solução.

**Critérios de Aceitação:**
- Botão "Pedir Ajuda a Colega"
- Sistema sugere colegas disponíveis
- Colega recebe notificação e pode aceitar/recusar
- Chat temporário durante a ajuda
- Quem ajuda ganha XP bônus e medalhas de colaboração

**Prioridade:** Baixa | **Estimativa:** 13 pontos

---

## ÉPICO 5: Gestão do Professor

### HU15 - Criar Turma
**Como** professor,
**Quero** criar uma turma e obter código de acesso,
**Para** que meus alunos possam se inscrever facilmente.

**Critérios de Aceitação:**
- Formulário simples: nome da turma, ano escolar, escola
- Código gerado automaticamente (6 caracteres alfanuméricos)
- Código pode ser regenerado se necessário
- Possibilidade de criar múltiplas turmas
- Código exibido em formato grande para projeção

**Prioridade:** Alta | **Estimativa:** 5 pontos

---

### HU16 - Acompanhar Progresso da Turma
**Como** professor,
**Quero** ver um dashboard com o desempenho geral da turma,
**Para** entender como os alunos estão evoluindo.

**Critérios de Aceitação:**
- Gráficos de progresso geral (média de desafios concluídos)
- Lista de alunos com porcentagem de conclusão
- Identificação visual de alunos com dificuldades (ícone de alerta)
- Filtros por período (última semana, mês, desde o início)
- Atualização em tempo real

**Prioridade:** Alta | **Estimativa:** 13 pontos

---

### HU17 - Identificar Alunos com Dificuldades
**Como** professor,
**Quero** ser alertado sobre alunos que estão enfrentando dificuldades recorrentes,
**Para** intervir e oferecer suporte personalizado.

**Critérios de Aceitação:**
- Sistema identifica padrões: muitas tentativas, tempo excessivo, desafios não concluídos
- Alertas categorizados: "Atenção" (amarelo), "Urgente" (vermelho)
- Detalhamento das dificuldades específicas (ex: "problemas com loops")
- Sugestões automáticas de atividades remediais
- Histórico de alertas anteriores

**Prioridade:** Alta | **Estimativa:** 13 pontos

---

### HU18 - Gerar Relatório de Desempenho
**Como** professor,
**Quero** gerar relatórios exportáveis de desempenho,
**Para** documentar o progresso dos alunos e compartilhar com coordenação/pais.

**Critérios de Aceitação:**
- Relatórios individuais ou da turma
- Formatos: PDF (visual) e CSV (dados)
- Conteúdo: desafios concluídos, XP, tempo médio, medalhas, competências BNCC atingidas
- Filtros de período personalizáveis
- Geração rápida (< 10 segundos)

**Prioridade:** Média | **Estimativa:** 8 pontos

---

### HU19 - Acessar Planos de Aula Prontos
**Como** professor sem formação em programação,
**Quero** acessar planos de aula estruturados e alinhados à BNCC,
**Para** aplicar o ensino de pensamento computacional sem precisar criar tudo do zero.

**Critérios de Aceitação:**
- Biblioteca organizada por ano escolar e conceito
- Cada plano contém: objetivos, tempo estimado, materiais necessários, passo a passo, avaliação
- Possibilidade de editar e salvar versões personalizadas
- Download em PDF
- Indicação de competências BNCC atendidas

**Prioridade:** Média | **Estimativa:** 8 pontos

---

### HU20 - Encontrar Atividades Desplugadas
**Como** professor que nem sempre tem acesso a computadores,
**Quero** acessar atividades sem tecnologia que ensinem os mesmos conceitos,
**Para** complementar ou substituir aulas online quando necessário.

**Critérios de Aceitação:**
- Banco de atividades organizadas por conceito (decomposição, algoritmos, etc.)
- Filtros: duração, materiais necessários, ano escolar
- Instruções detalhadas passo a passo
- Materiais de baixo custo ou gratuitos
- Possibilidade de imprimir ou baixar

**Prioridade:** Média | **Estimativa:** 5 pontos

---

### HU21 - Atribuir Tarefa Específica
**Como** professor,
**Quero** atribuir desafios específicos ou extras a alunos selecionados,
**Para** oferecer reforço ou extensão personalizada.

**Critérios de Aceitação:**
- Seleção de alunos individual ou por grupo
- Escolha de desafio do catálogo
- Definição de prazo opcional
- Notificação automática para alunos
- Acompanhamento de conclusão no dashboard

**Prioridade:** Baixa | **Estimativa:** 8 pontos

---

## ÉPICO 6: Acessibilidade

### HU22 - Navegar Apenas com Teclado
**Como** aluno com dificuldades motoras que não consigo usar mouse,
**Quero** navegar e usar todas as funcionalidades apenas com o teclado,
**Para** ter acesso completo à plataforma.

**Critérios de Aceitação:**
- Tab navega entre elementos interativos
- Enter/Espaço ativa botões
- Setas movem entre opções
- Esc fecha modais
- Indicador visual claro do foco
- Atalhos de teclado documentados

**Prioridade:** Alta | **Estimativa:** 8 pontos

---

### HU23 - Usar Leitor de Tela
**Como** aluno com deficiência visual,
**Quero** usar a plataforma com leitor de tela,
**Para** aprender pensamento computacional independentemente.

**Critérios de Aceitação:**
- Todos os elementos têm labels descritivas
- Blocos de código têm descrição textual
- Leitura da ordem de execução do algoritmo
- Feedback de sucesso/erro em texto
- Testes com NVDA, JAWS, VoiceOver e TalkBack

**Prioridade:** Alta | **Estimativa:** 13 pontos

---

### HU24 - Ajustar Contraste e Tamanho de Fonte
**Como** aluno com baixa visão,
**Quero** aumentar o tamanho das fontes e mudar para alto contraste,
**Para** conseguir ler todo o conteúdo confortavelmente.

**Critérios de Aceitação:**
- Menu de acessibilidade facilmente acessível
- 4 tamanhos de fonte: P, M, G, XG
- 3 temas: Claro, Escuro, Alto Contraste
- Preferências salvas automaticamente
- Todas as telas responsivas aos ajustes

**Prioridade:** Alta | **Estimativa:** 5 pontos

---

### HU25 - Assistir Vídeos com Legendas
**Como** aluno surdo ou com deficiência auditiva,
**Quero** que todos os vídeos tenham legendas,
**Para** compreender completamente o conteúdo audiovisual.

**Critérios de Aceitação:**
- Legendas em português claro
- Sincronização precisa com áudio
- Possibilidade de ativar/desativar legendas
- Transcrição completa disponível
- Opção futura: interpretação em Libras

**Prioridade:** Média | **Estimativa:** 5 pontos

---

## ÉPICO 7: Progressão e Acompanhamento

### HU26 - Ver Meu Histórico de Progresso
**Como** aluno,
**Quero** ver gráficos e estatísticas do meu progresso,
**Para** entender minha evolução ao longo do tempo.

**Critérios de Aceitação:**
- Gráfico de desafios concluídos por semana
- Total de XP acumulado
- Medalhas conquistadas
- Conceitos dominados vs. em desenvolvimento
- Comparação com meu desempenho anterior (não com outros alunos)

**Prioridade:** Média | **Estimativa:** 8 pontos

---

### HU27 - Revisar Desafios Concluídos
**Como** aluno,
**Quero** revisitar e refazer desafios que já completei,
**Para** praticar e melhorar minha solução.

**Critérios de Aceitação:**
- Desafios concluídos marcados com ícone de check
- Possibilidade de reabrir e editar solução anterior
- Comparação entre solução antiga e nova
- XP bônus se melhorar eficiência (menos blocos)
- Histórico de tentativas salvo

**Prioridade:** Baixa | **Estimativa:** 5 pontos

---

## ÉPICO 8: Conteúdo e Narrativa

### HU28 - Aprender Conceitos Progressivamente
**Como** aluno,
**Quero** que novos conceitos sejam introduzidos gradualmente,
**Para** não me sentir sobrecarregado.

**Critérios de Aceitação:**
- Trilha de aprendizagem estruturada
- Cada conceito novo tem desafio introdutório
- Explicação simples antes do desafio
- Conceitos revisitados em complexidade crescente
- Feedback mostra qual conceito está sendo praticado

**Prioridade:** Alta | **Estimativa:** 13 pontos

---

### HU29 - Conectar com Cultura Local
**Como** aluno paraibano,
**Quero** encontrar elementos da minha cultura nos desafios,
**Para** me sentir representado e mais conectado ao conteúdo.

**Critérios de Aceitação:**
- Personagens e cenários inspirados na Paraíba
- Referências a festas juninas, literatura de cordel, artesanato
- Desafios contextualizados (ex: organizar quadrilha, roteiro turístico)
- Linguagem inclusiva e regional quando apropriado
- Valorização de conhecimentos locais

**Prioridade:** Média | **Estimativa:** 13 pontos

---

## Resumo de Prioridades

| Prioridade | Quantidade | Histórias |
|-----------|-----------|-----------|
| **Alta** | 11 | HU01, HU03, HU04, HU05, HU06, HU07, HU15, HU16, HU17, HU22, HU23, HU24, HU28 |
| **Média** | 11 | HU02, HU08, HU09, HU10, HU12, HU18, HU19, HU20, HU25, HU26, HU29 |
| **Baixa** | 7 | HU11, HU13, HU14, HU21, HU27 |

---

## Estimativas de Esforço

Escala de Fibonacci: 1, 2, 3, 5, 8, 13, 21

- **1-3 pontos**: Mudanças simples, implementação rápida
- **5-8 pontos**: Funcionalidades de complexidade moderada
- **13-21 pontos**: Features complexas, múltiplos componentes

**Total estimado**: ~260 pontos (aproximadamente 6-8 sprints de 2 semanas)
