const loginForm = document.getElementById('loginForm');
const erroDiv = document.getElementById('erroMessage');

loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    erroDiv.textContent = '';
    erroDiv.classList.remove('visible');

    const usuario = document.getElementById('usuario').value.trim();
    const senha = document.getElementById('senha').value.trim();

    if (!usuario || !senha) {
        erroDiv.textContent = 'Preencha usuário e senha.';
        erroDiv.classList.add('visible');
        return;
    }

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usuario, senha })
        });

        const data = await response.json();

        if (!data.sucesso) {
            erroDiv.textContent = data.mensagem || 'Usuário ou senha incorretos.';
            erroDiv.classList.add('visible');
            return;
        }

        localStorage.setItem('computaplay-usuario', JSON.stringify(data.usuario));
        location.href = data.usuario.tipo === 'professor' ? 'professor.html' : 'aluno.html';
    } catch (error) {
        erroDiv.textContent = 'Erro de conexão. Tente novamente.';
        erroDiv.classList.add('visible');
    }
});
