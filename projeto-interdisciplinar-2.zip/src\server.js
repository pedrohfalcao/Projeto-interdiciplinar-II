// servidor do ComputaPlay com autenticação e sessão
// implementado pela equipe UNIFACISA

const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || 'computaplay-secret-key';
const DADOS_FILE = path.join(__dirname, 'dados.json');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(
    session({
        secret: SESSION_SECRET,
        resave: false,
        saveUninitialized: false,
        cookie: {
            httpOnly: true,
            sameSite: 'lax',
            maxAge: 1000 * 60 * 60
        }
    })
);

function lerDados() {
    try {
        if (fs.existsSync(DADOS_FILE)) {
            const data = fs.readFileSync(DADOS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (err) {
        console.log('erro ao ler dados:', err);
    }

    return {
        usuarios: [
            { id: 1, nome: 'Maria Silva', tipo: 'aluno', usuario: 'maria', senha: '123456', xp: 150, nivel: 2, turmaId: 1, medalhas: [1] },
            { id: 2, nome: 'João Santos', tipo: 'aluno', usuario: 'joao', senha: '123456', xp: 80, nivel: 1, turmaId: 1, medalhas: [] },
            { id: 3, nome: 'Prof. Carla', tipo: 'professor', usuario: 'carla', senha: 'prof123', turmas: [1] }
        ],
        medalhas: [
            { id: 1, nome: 'Primeira Vitória', icone: '🏆', requisito: 'Concluir primeiro desafio' },
            { id: 2, nome: 'Mestre dos Loops', icone: '🔄', requisito: 'Usar loops em 3 desafios' },
            { id: 3, nome: 'Pensador Lógico', icone: '🧠', requisito: 'Concluir todos os desafios' },
            { id: 4, nome: 'Persistente', icone: '💪', requisito: 'Tentar 10 vezes' }
        ],
        desafios: [
            {
                id: 1,
                titulo: 'Primeiro Passo',
                descricao: 'Mova o personagem até a estrela',
                dificuldade: 'facil',
                xp: 10,
                concluido: []
            },
            {
                id: 2,
                titulo: 'Labirinto Simples',
                descricao: 'Use loops para resolver o labirinto',
                dificuldade: 'medio',
                xp: 25,
                concluido: []
            },
            {
                id: 3,
                titulo: 'Festa Junina',
                descricao: 'Organize a quadrilha com algoritmos',
                dificuldade: 'dificil',
                xp: 50,
                concluido: []
            }
        ],
        turmas: [
            { id: 1, nome: '7º Ano A', codigo: 'A3F7K2', professorId: 3, alunos: [1, 2] }
        ]
    };
}

function salvarDados(dados) {
    try {
        fs.writeFileSync(DADOS_FILE, JSON.stringify(dados, null, 2));
        return true;
    } catch (err) {
        console.log('erro ao salvar:', err);
        return false;
    }
}

async function validarSenha(user, senha) {
    if (!user || !user.senha) {
        return false;
    }
    if (user.senha.startsWith('$2')) {
        return bcrypt.compare(senha, user.senha);
    }
    return user.senha === senha;
}

function requireAuth(req, res, next) {
    if (!req.session || !req.session.user) {
        return res.status(401).json({ erro: 'Não autorizado' });
    }
    next();
}

function requireTipo(tipo) {
    return (req, res, next) => {
        if (!req.session || req.session.user.tipo !== tipo) {
            return res.status(403).json({ erro: 'Acesso negado' });
        }
        next();
    };
}

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/api/login', async (req, res) => {
    const { usuario, senha } = req.body;
    const dados = lerDados();
    const user = dados.usuarios.find((u) => u.usuario === usuario);

    if (!user) {
        return res.json({ sucesso: false, mensagem: 'Usuário ou senha incorretos' });
    }

    const senhaValida = await validarSenha(user, senha);
    if (!senhaValida) {
        return res.json({ sucesso: false, mensagem: 'Usuário ou senha incorretos' });
    }

    if (!user.senha.startsWith('$2')) {
        user.senha = await bcrypt.hash(user.senha, 10);
        salvarDados(dados);
    }

    req.session.user = {
        id: user.id,
        nome: user.nome,
        tipo: user.tipo,
        xp: user.xp || 0,
        nivel: user.nivel || 1
    };

    res.json({ sucesso: true, usuario: req.session.user });
});

app.post('/api/logout', requireAuth, (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ erro: 'Erro ao encerrar sessão' });
        }
        res.json({ sucesso: true });
    });
});

app.get('/api/autenticado', requireAuth, (req, res) => {
    res.json({ usuario: req.session.user });
});

app.get('/api/desafios', requireAuth, (req, res) => {
    const dados = lerDados();
    res.json(dados.desafios);
});

app.post('/api/concluir-desafio', requireAuth, requireTipo('aluno'), (req, res) => {
    const { alunoId, desafioId } = req.body;
    const dados = lerDados();

    const aluno = dados.usuarios.find((u) => u.id === alunoId);
    const desafio = dados.desafios.find((d) => d.id === desafioId);

    if (!aluno || !desafio) {
        return res.json({ sucesso: false, mensagem: 'Erro ao concluir desafio' });
    }

    aluno.xp = (aluno.xp || 0) + desafio.xp;
    aluno.nivel = Math.floor(aluno.xp / 100) + 1;

    if (!desafio.concluido) desafio.concluido = [];
    if (!desafio.concluido.includes(alunoId)) {
        desafio.concluido.push(alunoId);
    }

    salvarDados(dados);

    res.json({ sucesso: true, xpGanho: desafio.xp, xpTotal: aluno.xp, nivelAtual: aluno.nivel });
});

app.get('/api/professor/turma/:id', requireAuth, requireTipo('professor'), (req, res) => {
    const turmaId = parseInt(req.params.id, 10);
    const dados = lerDados();
    const turma = dados.turmas.find((t) => t.id === turmaId);

    if (!turma) {
        return res.status(404).json({ erro: 'Turma não encontrada' });
    }

    const alunos = dados.usuarios.filter((u) => turma.alunos.includes(u.id));
    res.json({
        turma,
        alunos: alunos.map((a) => ({ id: a.id, nome: a.nome, xp: a.xp || 0, nivel: a.nivel || 1 }))
    });
});

app.get('/api/medalhas', requireAuth, (req, res) => {
    const dados = lerDados();
    res.json(dados.medalhas || []);
});

app.get('/api/aluno/:id/medalhas', requireAuth, (req, res) => {
    const alunoId = parseInt(req.params.id, 10);
    const dados = lerDados();
    const aluno = dados.usuarios.find((u) => u.id === alunoId);

    if (!aluno) {
        return res.status(404).json({ erro: 'Aluno não encontrado' });
    }

    if (req.session.user.tipo !== 'professor' && req.session.user.id !== alunoId) {
        return res.status(403).json({ erro: 'Acesso negado' });
    }

    const todasMedalhas = dados.medalhas || [];
    const medalhasDoAluno = aluno.medalhas || [];

    res.json({
        conquistadas: todasMedalhas.filter((m) => medalhasDoAluno.includes(m.id)),
        disponiveis: todasMedalhas.filter((m) => !medalhasDoAluno.includes(m.id))
    });
});

app.get('/api/ranking/:turmaId', requireAuth, requireTipo('professor'), (req, res) => {
    const turmaId = parseInt(req.params.turmaId, 10);
    const dados = lerDados();
    const turma = dados.turmas.find((t) => t.id === turmaId);

    if (!turma) {
        return res.status(404).json({ erro: 'Turma não encontrada' });
    }

    const ranking = dados.usuarios
        .filter((u) => turma.alunos.includes(u.id))
        .map((a) => ({ id: a.id, nome: a.nome, xp: a.xp || 0, nivel: a.nivel || 1 }))
        .sort((a, b) => b.xp - a.xp);

    res.json(ranking);
});

app.listen(PORT, () => {
    console.log('\n========================================');
    console.log('  ComputaPlay rodando!');
    console.log(`  Acesse: http://localhost:${PORT}`);
    console.log('========================================\n');
});
