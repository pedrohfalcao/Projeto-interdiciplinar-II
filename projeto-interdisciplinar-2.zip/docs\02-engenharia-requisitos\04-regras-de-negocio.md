# 2.4 REGRAS DE NEGÓCIO

As regras de negócio definem as políticas, restrições e lógicas que governam o funcionamento do sistema.

---

## RN01 - Progressão Sequencial de Desafios
**Descrição**: Alunos devem completar desafios em ordem sequencial. Desafios avançados só são desbloqueados após conclusão dos anteriores.

**Justificativa**: Garantir aprendizagem progressiva e evitar frustração por tentar desafios muito difíceis prematuramente.

**Exceções**:
- Professor pode desbloquear desafios específicos manualmente para alunos avançados
- Desafios revisitados (já concluídos) podem ser refeitos a qualquer momento

**Impacto**: RF03, RF07

---

## RN02 - Cálculo de XP por Desafio
**Descrição**: XP concedido varia conforme:
- **Dificuldade base**: Fácil (10 XP), Médio (25 XP), Difícil (50 XP), Expert (100 XP)
- **Bônus de eficiência**: Até +20% por usar menos blocos que solução padrão
- **Penalidade por dicas**: -5 XP por cada dica utilizada (mínimo 50% do XP base)
- **Bônus de velocidade**: +10 XP se concluir no primeiro terço do tempo médio

**Justificativa**: Incentivar soluções eficientes e pensamento crítico, mas não penalizar excessivamente quem precisa de ajuda.

**Fórmula**:
```
XP_final = XP_base × (1 + bonus_eficiencia) + bonus_velocidade - penalidade_dicas
XP_final = max(XP_final, XP_base × 0.5)
```

**Impacto**: RF07

---

## RN03 - Requisitos para Subida de Nível
**Descrição**: Progressão de níveis segue escala exponencial:
- Nível 1→2: 100 XP
- Nível 2→3: 150 XP
- Nível N→N+1: 100 × (1.15)^(N-1) XP (arredondado)
- Nível máximo: 50

**Justificativa**: Manter desafio crescente sem tornar progressão impossível. Níveis iniciais rápidos para engajamento imediato.

**Impacto**: RF09

---

## RN04 - Critérios de Medalhas
**Descrição**: Medalhas são concedidas por conquistas específicas em categorias:

### Progresso
- **Primeira Vitória**: Completar primeiro desafio
- **Desbravador**: Completar 10 desafios
- **Maratonista**: Completar 10 desafios em um único dia
- **Mestre**: Completar todos os desafios de um ano escolar

### Maestria
- **Mestre do Loop**: Usar loops em 5 desafios diferentes
- **Lógico**: Usar condicionais corretamente em 5 desafios
- **Eficiente**: Obter bônus de eficiência em 10 desafios
- **Depurador**: Corrigir um erro após 5+ tentativas

### Colaboração
- **Ajudante**: Ajudar 3 colegas
- **Mentor**: Ajudar 10 colegas
- **Trabalho em Equipe**: Completar 3 desafios colaborativos

### Especiais
- **Persistente**: Completar desafio após 10+ tentativas
- **Cultural**: Completar todos os desafios com temática regional
- **Explorador**: Acessar todas as seções da plataforma

**Justificativa**: Diversificar motivações e reconhecer diferentes tipos de esforços.

**Impacto**: RF08

---

## RN05 - Composição do Ranking Colaborativo
**Descrição**: Pontuação do ranking é composta por:
- **60%**: XP individual acumulado
- **30%**: Pontos de colaboração (ajudar colegas: 10 pts/ajuda)
- **10%**: Medalhas especiais de cidadania (não competitivas)

**Justificativa**: Valorizar cooperação além de desempenho individual, reduzindo competitividade excessiva.

**Cálculo**:
```
Pontuacao_Ranking = (XP × 0.6) + (Ajudas × 10 × 0.3) + (Medalhas_Cidadania × 50 × 0.1)
```

**Impacto**: RF10

---

## RN06 - Validade do Código de Turma
**Descrição**:
- Códigos de turma são alfanuméricos com 6 caracteres (ex: A3F7K2)
- Válidos por tempo indeterminado enquanto turma estiver ativa
- Podem ser regenerados pelo professor a qualquer momento
- Códigos antigos são invalidados após regeneração

**Justificativa**: Facilitar acesso de alunos e permitir controle do professor sobre inscrições.

**Impacto**: RF15, RF16

---

## RN07 - Privacidade de Dados de Alunos
**Descrição**:
- Professores só acessam dados de alunos de suas próprias turmas
- Alunos só visualizam próprio progresso completo
- No ranking, alunos nas 5 últimas posições aparecem anônimos
- Dados pessoais (nome completo, e-mail) não são exibidos em rankings públicos
- Relatórios exportados não contêm dados pessoais sensíveis sem consentimento

**Justificativa**: Conformidade com LGPD e proteção da privacidade de menores.

**Impacto**: RF10, RF17, RF19, RNF14

---

## RN08 - Sistema de Dicas Progressivas
**Descrição**: Dicas são reveladas em 3 níveis de especificidade:
1. **Dica Conceitual**: Relembra o conceito necessário (ex: "Você precisará usar um loop")
2. **Dica Estratégica**: Sugere abordagem (ex: "Tente repetir o movimento 4 vezes")
3. **Dica Quase-Solução**: Mostra estrutura sem código completo (ex: "Use um loop 'para' com contador até 4")

Cada dica tem cooldown de 30 segundos entre revelações.

**Justificativa**: Evitar dependência de dicas e estimular raciocínio autônomo.

**Impacto**: RF06

---

## RN09 - Limite de Tentativas e Timeout
**Descrição**:
- Não há limite de tentativas por desafio
- Execução de código é interrompida após 2 segundos (detecção de loop infinito)
- Alunos podem pausar/retomar execução durante animação

**Justificativa**: Ambiente seguro para experimentação sem consequências negativas.

**Impacto**: RF05, RF06

---

## RN10 - Requisitos de Senha
**Descrição**:
- Mínimo de 6 caracteres
- Pelo menos 1 letra e 1 número (recomendado, não obrigatório para alunos)
- Senhas armazenadas com hash bcrypt (cost factor 12)
- Opção de recuperação via e-mail do professor/responsável

**Justificativa**: Balancear segurança com usabilidade para faixa etária (11-15 anos).

**Impacto**: RF01, RNF15

---

## RN11 - Alinhamento com BNCC
**Descrição**: Cada desafio deve estar mapeado para pelo menos uma habilidade da BNCC:
- **Matemática**: EF06MA01 a EF09MA23 (raciocínio lógico, sequências, padrões)
- **Ciências**: EF06CI01 a EF09CI16 (método científico, investigação)
- **Competências Gerais**: 4 (Comunicação), 5 (Cultura Digital)

Tags obrigatórias nos desafios:
- Competência BNCC
- Pilar do Pensamento Computacional (Decomposição, Padrões, Abstração, Algoritmos)
- Nível de dificuldade
- Ano escolar recomendado

**Justificativa**: Garantir que plataforma atenda exigências curriculares nacionais.

**Impacto**: RF24, RNF30

---

## RN12 - Moderação de Conteúdo em Chat
**Descrição**: Em funcionalidades de chat (ajuda entre colegas):
- Filtro automático de palavras inapropriadas
- Mensagens limitadas a 200 caracteres
- Impossibilidade de compartilhar links externos
- Professor pode visualizar histórico de chats de sua turma
- Sistema registra logs para moderação

**Justificativa**: Proteger menores de idade e manter ambiente educacional seguro.

**Impacto**: RF14, RF23

---

## RN13 - Atribuição de Desafios Remediais
**Descrição**: Sistema identifica automaticamente alunos com dificuldades quando:
- 3+ tentativas erradas consecutivas em 3 desafios seguidos
- Tempo médio 50% acima da média da turma em 5+ desafios
- Nenhum desafio concluído em 7 dias consecutivos (aluno ativo)

Ações automáticas:
- Alerta ao professor no dashboard
- Sugestão de desafios remediais mais simples sobre o mesmo conceito
- Oferta de atividades desplugadas complementares

**Justificativa**: Intervenção precoce para evitar desistência e lacunas de aprendizagem.

**Impacto**: RF18, RF20, RF22

---

## RN14 - Personalização de Avatar
**Descrição**:
- Opções iniciais gratuitas: 5 tons de pele, 8 estilos de cabelo, 6 roupas básicas
- Novos itens desbloqueados por níveis:
  - Nível 5: 3 novos acessórios
  - Nível 10: 5 novas roupas
  - Nível 20: Itens temáticos especiais
- Medalhas especiais concedem itens exclusivos
- Todos os itens devem ser inclusivos e culturalmente representativos

**Justificativa**: Motivação adicional para progressão e representatividade.

**Impacto**: RF02

---

## RN15 - Exportação de Dados (LGPD)
**Descrição**: Qualquer usuário pode solicitar:
- Exportação completa de seus dados em formato legível (JSON/PDF)
- Exclusão permanente de conta e dados associados (direito ao esquecimento)
- Correção de dados pessoais incorretos

Prazos:
- Exportação: Até 48h úteis
- Exclusão: Até 7 dias úteis (com confirmação dupla)

**Justificativa**: Conformidade com LGPD (Lei 13.709/2018).

**Impacto**: RNF14, RNF27

---

## RN16 - Limite de Alunos por Turma
**Descrição**:
- Máximo de 50 alunos por turma (limite técnico)
- Recomendação: 30-35 alunos (pedagógico)
- Professor pode criar múltiplas turmas sem limite

**Justificativa**: Garantir performance do sistema e qualidade pedagógica do acompanhamento.

**Impacto**: RF15

---

## RN17 - Desafios Colaborativos
**Descrição**:
- Grupos de 2-4 alunos formados pelo professor
- Cada aluno contribui com parte do código (divisão de tarefas)
- Código sincronizado em tempo real (WebSocket)
- Todos recebem mesmo XP se bem-sucedidos
- Se falhar, podem tentar novamente em conjunto

**Justificativa**: Desenvolver habilidades de trabalho em equipe e comunicação.

**Impacto**: RF11

---

## RN18 - Conteúdo Culturalmente Contextualizado
**Descrição**: Pelo menos 50% dos desafios devem incluir elementos da cultura paraibana/nordestina:
- Personagens com nomes regionais
- Cenários: Praia de Tambaba, Pedra da Boca, Centro Histórico de João Pessoa
- Eventos: São João, carnaval de rua, festas populares
- Referências: Literatura de cordel, artesanato, culinária típica

Outros 50% podem ter temática universal/tecnológica.

**Justificativa**: Aumentar identificação e engajamento dos alunos.

**Impacto**: RF13, RNF29

---

## RN19 - Acessibilidade Obrigatória desde o Design
**Descrição**: Todo novo recurso deve:
- Passar por checklist WCAG 2.1 AA antes de implementação
- Ser testado com leitor de tela
- Ter navegação via teclado funcional
- Manter contraste mínimo de 4.5:1
- Incluir alternativas textuais para conteúdo visual

Recursos não acessíveis são bloqueados em Code Review.

**Justificativa**: Garantir inclusão desde a concepção, não como adaptação posterior.

**Impacto**: RF26, RF27, RF28, RNF08, RNF09, RNF31

---

## RN20 - Tempo Máximo de Sessão
**Descrição**:
- Sessão de aluno expira após 2 horas de inatividade
- Sessão de professor expira após 4 horas de inatividade
- Progresso em desafio em andamento é salvo automaticamente a cada 30 segundos

**Justificativa**: Segurança em ambientes compartilhados (laboratórios escolares).

**Impacto**: RNF15, RNF17

---

## Matriz de Rastreabilidade: Regras de Negócio x Requisitos

| Regra de Negócio | Requisitos Relacionados | Stakeholder Principal |
|------------------|------------------------|----------------------|
| RN01 | RF03, RF07 | Aluno, Professor |
| RN02 | RF07 | Aluno |
| RN03 | RF09 | Aluno |
| RN04 | RF08 | Aluno |
| RN05 | RF10 | Aluno, Professor |
| RN06 | RF15, RF16 | Professor |
| RN07 | RF10, RF17, RF19, RNF14 | Todos |
| RN08 | RF06 | Aluno |
| RN09 | RF05, RF06 | Aluno |
| RN10 | RF01, RNF15 | Todos |
| RN11 | RF24, RNF30 | Professor, Gestor |
| RN12 | RF14, RF23 | Aluno, Professor |
| RN13 | RF18, RF20, RF22 | Professor |
| RN14 | RF02 | Aluno |
| RN15 | RNF14, RNF27 | Todos |
| RN16 | RF15 | Professor |
| RN17 | RF11 | Aluno |
| RN18 | RF13, RNF29 | Aluno |
| RN19 | RF26-30, RNF08-09, RNF31 | Aluno com deficiência |
| RN20 | RNF15, RNF17 | Todos |

---

## Priorização de Regras de Negócio

### Críticas (Implementação Obrigatória - MVP)
RN01, RN02, RN06, RN07, RN09, RN10, RN11, RN19, RN20

### Importantes (Implementação Prioritária)
RN03, RN04, RN08, RN13, RN15, RN18

### Desejáveis (Implementação Posterior)
RN05, RN12, RN14, RN16, RN17
