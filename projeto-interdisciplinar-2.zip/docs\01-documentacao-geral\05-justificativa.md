# 1.5 JUSTIFICATIVA E RELEVÂNCIA DA SOLUÇÃO

## Importância do Pensamento Computacional na Educação Contemporânea

O pensamento computacional transcende o domínio da ciência da computação, constituindo-se como uma competência fundamental para resolução de problemas complexos em todas as áreas do conhecimento. Segundo Wing (2006), trata-se de uma habilidade universal que deveria ser incorporada à capacidade analítica de todas as crianças.

No contexto da Quarta Revolução Industrial, caracterizada pela automação, inteligência artificial e transformação digital, preparar os estudantes para compreenderem e participarem ativamente dessa sociedade tecnológica não é mais opcional, mas essencial.

## Demandas da BNCC e Políticas Educacionais

A Base Nacional Comum Curricular (BNCC), homologada em 2018, estabelece explicitamente no âmbito da competência geral 5:

> "Compreender, utilizar e criar tecnologias digitais de informação e comunicação de forma crítica, significativa, reflexiva e ética nas diversas práticas sociais (incluindo as escolares) para se comunicar, acessar e disseminar informações, produzir conhecimentos, resolver problemas e exercer protagonismo e autoria na vida pessoal e coletiva."

Especificamente na área de Matemática, a BNCC menciona o pensamento computacional como uma das competências a serem desenvolvidas ao longo do Ensino Fundamental.

### Lacuna entre Política e Prática

Apesar das diretrizes nacionais, pesquisas recentes demonstram que:
- Apenas 23% das escolas públicas brasileiras possuem laboratórios de informática em condições adequadas de uso (Censo Escolar 2022)
- Menos de 15% dos professores de Ensino Fundamental receberam formação em pensamento computacional ou programação (CETIC Educação 2021)
- A maioria das ferramentas educacionais disponíveis não são acessíveis a alunos com deficiências

**A plataforma ComputaPlay surge para preencher essa lacuna crítica.**

## Relevância Social e Inclusão

### 1. Democratização do Acesso à Educação em Tecnologia

A proposta de uma plataforma gratuita, web-based e de baixo custo rompe barreiras econômicas que impedem escolas públicas de adotarem soluções comerciais caras. Ao funcionar em navegadores e dispositivos simples, amplia-se drasticamente o alcance da ferramenta.

### 2. Inclusão de Pessoas com Deficiência

No Brasil, segundo o Censo de 2010 (IBGE), aproximadamente 24% da população possui algum tipo de deficiência. Na educação, alunos com deficiências frequentemente enfrentam barreiras tecnológicas adicionais:

- **Deficiência Visual**: Poucas plataformas educacionais são compatíveis com leitores de tela
- **Deficiência Auditiva**: Conteúdos audiovisuais raramente possuem legendas ou interpretação em Libras
- **Deficiência Cognitiva**: Interfaces complexas dificultam a compreensão e navegação

O ComputaPlay foi projetado desde a concepção com foco em acessibilidade universal (WCAG 2.1), garantindo que todos os alunos, independentemente de suas limitações, possam desenvolver o pensamento computacional.

### 3. Contextualização Regional

Ao incorporar elementos culturais paraibanos na narrativa e nos desafios (festas juninas, literatura de cordel, personalidades históricas, ecossistemas locais), a plataforma:
- Valoriza a identidade cultural dos estudantes
- Aumenta o engajamento através da identificação com o conteúdo
- Promove o senso de pertencimento
- Combate a perspectiva de que tecnologia é algo distante ou estrangeiro

## Impacto Pedagógico: Gamificação como Estratégia

A gamificação aplicada à educação, quando bem projetada, demonstrou resultados significativos:

- **Aumento do Engajamento**: Elementos como narrativas, desafios e recompensas mantêm os alunos motivados (Deterding et al., 2011)
- **Aprendizagem Ativa**: Alunos assumem papel de protagonistas na construção do conhecimento
- **Feedback Imediato**: Sistemas de pontuação e medalhas fornecem retorno instantâneo sobre o progresso
- **Redução da Ansiedade**: Ambiente lúdico diminui o medo de errar, essencial para aprendizagem de lógica

### Gamificação Colaborativa vs. Competitiva

O ComputaPlay adota uma abordagem balanceada:
- **Rankings colaborativos**: Valorizam cooperação entre alunos
- **Desafios em equipe**: Estimulam trabalho coletivo
- **Medalhas de ajuda mútua**: Reconhecem alunos que auxiliam colegas

Essa estratégia evita os problemas de gamificação puramente competitiva, que pode desmotivar alunos com mais dificuldades.

## Capacitação Indireta de Professores

Um dos diferenciais da plataforma é empoderar professores sem formação técnica. Ao fornecer:
- Interface intuitiva de gestão
- Planos de aula prontos
- Atividades desplugadas complementares
- Dashboard de acompanhamento automático

O ComputaPlay funciona como uma ferramenta de formação continuada implícita, permitindo que professores de diferentes áreas (Matemática, Português, Ciências) incorporem o pensamento computacional em suas disciplinas.

## Relevância Econômica e Sustentabilidade

### Custo-Benefício para Redes Públicas

Plataformas comerciais de ensino de programação custam entre R$ 50 a R$ 200 por aluno/ano. Para uma escola com 500 alunos, isso representa R$ 25.000 a R$ 100.000 anuais - valores inviáveis para a maioria das secretarias de educação.

O ComputaPlay, sendo open-source e web-based:
- **Custo Zero de Licenciamento**: Escolas podem adotar sem investimento inicial
- **Baixo Custo de Manutenção**: Hospedagem em nuvem escalável
- **Economia de Hardware**: Funciona em equipamentos existentes

### Escalabilidade e Alcance

Por ser uma solução web, a plataforma pode:
- Atender simultaneamente milhares de alunos
- Ser implantada rapidamente em múltiplas escolas
- Receber atualizações centralizadas sem necessidade de instalação local
- Gerar dados para pesquisas sobre aprendizagem em larga escala

## Contribuição Científica e Tecnológica

O projeto integra múltiplas áreas do conhecimento em Computação:

- **Interação Humano-Computador (IHC)**: Design centrado no usuário, acessibilidade
- **Engenharia de Software**: Metodologias ágeis, arquitetura de sistemas
- **Banco de Dados**: Modelagem, otimização de consultas
- **Desenvolvimento Web**: Front-end responsivo, back-end escalável
- **Game Design**: Mecânicas de gamificação, narrativa interativa
- **Acessibilidade Digital**: Implementação de padrões WCAG

Além disso, a documentação e código aberto do projeto podem servir como base para:
- Trabalhos de conclusão de curso
- Dissertações e teses
- Artigos científicos sobre educação e tecnologia
- Modelo para desenvolvimento de outras plataformas educacionais

## Alinhamento com os Objetivos de Desenvolvimento Sustentável (ODS)

O projeto contribui diretamente para os seguintes ODS da ONU:

- **ODS 4 - Educação de Qualidade**: Assegurar educação inclusiva e equitativa de qualidade
- **ODS 10 - Redução das Desigualdades**: Reduzir desigualdades de acesso à tecnologia educacional
- **ODS 9 - Indústria, Inovação e Infraestrutura**: Promover inovação tecnológica na educação

## Conclusão

O ComputaPlay não é apenas uma ferramenta tecnológica, mas um instrumento de transformação social que:
- Democratiza o acesso ao ensino de pensamento computacional
- Promove inclusão de alunos com deficiências
- Capacita professores da rede pública
- Valoriza a cultura regional
- Atende às exigências da BNCC
- Oferece uma solução sustentável e escalável

Em um contexto de crescente importância das competências digitais, desenvolver o pensamento computacional desde o Ensino Fundamental é investir no futuro dos estudantes, preparando-os para serem cidadãos críticos, criativos e protagonistas na sociedade digital.
