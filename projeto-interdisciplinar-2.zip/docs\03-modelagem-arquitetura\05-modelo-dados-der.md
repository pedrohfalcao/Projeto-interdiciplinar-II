# 3.5 MODELO CONCEITUAL DE DADOS (DER)

## Diagrama Entidade-Relacionamento

### Entidades Principais

#### 1. USUARIO
- **PK**: id_usuario (UUID)
- nome (VARCHAR 100) NOT NULL
- email (VARCHAR 100) UNIQUE NOT NULL
- senha_hash (VARCHAR 255) NOT NULL
- tipo_usuario (ENUM: aluno, professor, admin) NOT NULL
- data_criacao (TIMESTAMP) DEFAULT NOW()
- ultimo_acesso (TIMESTAMP)
- ativo (BOOLEAN) DEFAULT TRUE

#### 2. PREFERENCIAS_ACESSIBILIDADE
- **PK**: id_preferencias (UUID)
- **FK**: id_usuario → USUARIO
- tamanho_fonte (ENUM: P, M, G, XG) DEFAULT M
- tema (ENUM: claro, escuro, alto_contraste) DEFAULT claro
- leitor_tela_ativo (BOOLEAN) DEFAULT FALSE
- navegacao_teclado (BOOLEAN) DEFAULT FALSE
- legendas_ativas (BOOLEAN) DEFAULT FALSE

#### 3. ALUNO (Especialização de USUARIO)
- **PK**: id_aluno (UUID)
- **FK**: id_usuario → USUARIO
- **FK**: id_turma → TURMA
- xp_total (INTEGER) DEFAULT 0
- nivel_atual (INTEGER) DEFAULT 1
- data_nascimento (DATE)

#### 4. AVATAR
- **PK**: id_avatar (UUID)
- **FK**: id_aluno → ALUNO (1:1)
- tom_pele (VARCHAR 50)
- cabelo (VARCHAR 50)
- roupa (VARCHAR 50)
- acessorios (JSON)
- itens_desbloqueados (JSON)

#### 5. PROFESSOR (Especialização de USUARIO)
- **PK**: id_professor (UUID)
- **FK**: id_usuario → USUARIO
- instituicao (VARCHAR 150)
- documento_identificacao (VARCHAR 50)
- data_validacao (TIMESTAMP)

#### 6. TURMA
- **PK**: id_turma (UUID)
- **FK**: id_professor → PROFESSOR
- nome (VARCHAR 100) NOT NULL
- ano_escolar (INTEGER) CHECK (ano_escolar BETWEEN 6 AND 9)
- escola (VARCHAR 150)
- codigo_acesso (CHAR 6) UNIQUE NOT NULL
- data_criacao (TIMESTAMP) DEFAULT NOW()
- ativa (BOOLEAN) DEFAULT TRUE
- limite_alunos (INTEGER) DEFAULT 50

#### 7. DESAFIO
- **PK**: id_desafio (UUID)
- titulo (VARCHAR 150) NOT NULL
- descricao (TEXT) NOT NULL
- dificuldade (ENUM: facil, medio, dificil, expert) NOT NULL
- xp_base (INTEGER) NOT NULL
- ano_escolar_recomendado (INTEGER) CHECK (BETWEEN 6 AND 9)
- pilar_pensamento (ENUM: decomposicao, padroes, abstracao, algoritmos)
- tema_cultural (VARCHAR 100)
- ordem_sequencia (INTEGER)
- blocos_disponiveis (JSON)
- solucao_esperada (JSON)
- tempo_medio_resolucao (INTEGER) -- em segundos
- ativo (BOOLEAN) DEFAULT TRUE

#### 8. COMPETENCIA_BNCC
- **PK**: id_competencia (UUID)
- codigo_bncc (VARCHAR 20) UNIQUE NOT NULL -- ex: EF06MA01
- descricao (TEXT) NOT NULL
- area_conhecimento (ENUM: matematica, ciencias, lingua_portuguesa, geral)
- ano_escolar (INTEGER)

#### 9. DESAFIO_COMPETENCIA (Tabela Associativa)
- **PK**: id (UUID)
- **FK**: id_desafio → DESAFIO
- **FK**: id_competencia → COMPETENCIA_BNCC

#### 10. DICA
- **PK**: id_dica (UUID)
- **FK**: id_desafio → DESAFIO
- nivel (INTEGER) CHECK (nivel BETWEEN 1 AND 3)
- texto (TEXT) NOT NULL
- ordem (INTEGER)

#### 11. PROGRESSO_DESAFIO
- **PK**: id_progresso (UUID)
- **FK**: id_aluno → ALUNO
- **FK**: id_desafio → DESAFIO
- status (ENUM: nao_iniciado, em_progresso, concluido) DEFAULT nao_iniciado
- tentativas (INTEGER) DEFAULT 0
- tempo_gasto (INTEGER) DEFAULT 0 -- segundos
- xp_ganho (INTEGER) DEFAULT 0
- codigo_final (JSON)
- dicas_usadas (INTEGER) DEFAULT 0
- data_inicio (TIMESTAMP)
- data_conclusao (TIMESTAMP)
- eficiencia_solucao (FLOAT) -- 0.0 a 1.0

#### 12. MEDALHA
- **PK**: id_medalha (UUID)
- nome (VARCHAR 100) NOT NULL
- descricao (TEXT) NOT NULL
- categoria (ENUM: progresso, maestria, colaboracao, especial)
- criterio (JSON) NOT NULL -- condições para desbloquear
- raridade (ENUM: bronze, prata, ouro, especial)
- icone_url (VARCHAR 255)
- pontos_ranking (INTEGER) DEFAULT 50

#### 13. ALUNO_MEDALHA (Tabela Associativa)
- **PK**: id (UUID)
- **FK**: id_aluno → ALUNO
- **FK**: id_medalha → MEDALHA
- data_conquista (TIMESTAMP) DEFAULT NOW()

#### 14. DESAFIO_COLABORATIVO
- **PK**: id_colaborativo (UUID)
- **FK**: id_desafio → DESAFIO
- **FK**: id_turma → TURMA
- nome_grupo (VARCHAR 100)
- data_criacao (TIMESTAMP)
- prazo (TIMESTAMP)
- status (ENUM: em_andamento, concluido, cancelado)

#### 15. ALUNO_DESAFIO_COLABORATIVO (Tabela Associativa)
- **PK**: id (UUID)
- **FK**: id_colaborativo → DESAFIO_COLABORATIVO
- **FK**: id_aluno → ALUNO
- contribuicao (JSON) -- parte do código contribuída
- data_participacao (TIMESTAMP)

#### 16. AJUDA_ENTRE_ALUNOS
- **PK**: id_ajuda (UUID)
- **FK**: id_solicitante → ALUNO
- **FK**: id_ajudante → ALUNO
- **FK**: id_desafio → DESAFIO
- data_solicitacao (TIMESTAMP)
- data_conclusao (TIMESTAMP)
- status (ENUM: pendente, aceito, recusado, concluido)
- chat_log (JSON)

#### 17. RANKING
- **PK**: id_ranking (UUID)
- **FK**: id_turma → TURMA
- periodo_inicio (DATE)
- periodo_fim (DATE)
- tipo (ENUM: semanal, mensal, geral)
- data_atualizacao (TIMESTAMP)

#### 18. POSICAO_RANKING
- **PK**: id_posicao (UUID)
- **FK**: id_ranking → RANKING
- **FK**: id_aluno → ALUNO
- posicao (INTEGER)
- pontuacao_total (FLOAT)
- xp_contribuicao (INTEGER)
- colaboracao_contribuicao (INTEGER)

#### 19. ALERTA
- **PK**: id_alerta (UUID)
- **FK**: id_aluno → ALUNO
- **FK**: id_professor → PROFESSOR
- tipo (ENUM: atencao, urgente)
- descricao (TEXT)
- conceito_dificuldade (VARCHAR 100)
- sugestoes (JSON)
- data_geracao (TIMESTAMP) DEFAULT NOW()
- visualizado (BOOLEAN) DEFAULT FALSE
- data_visualizacao (TIMESTAMP)

#### 20. PLANO_AULA
- **PK**: id_plano (UUID)
- titulo (VARCHAR 150) NOT NULL
- ano_escolar (INTEGER)
- conceito (VARCHAR 100)
- objetivos (JSON)
- tempo_estimado (INTEGER) -- minutos
- materiais (JSON)
- passo_passo (JSON)
- competencias_bncc (JSON)
- criado_por (ENUM: sistema, professor)
- **FK**: id_professor_autor → PROFESSOR (nullable)

#### 21. ATIVIDADE_DESPLUGADA
- **PK**: id_atividade (UUID)
- titulo (VARCHAR 150) NOT NULL
- conceito (VARCHAR 100)
- duracao (INTEGER) -- minutos
- materiais_necessarios (JSON)
- instrucoes (TEXT)
- avaliacao_sugerida (TEXT)
- ano_escolar (INTEGER)
- arquivo_pdf (VARCHAR 255) -- URL

#### 22. LOG_SISTEMA
- **PK**: id_log (UUID)
- **FK**: id_usuario → USUARIO (nullable)
- tipo_evento (ENUM: login, logout, erro, criacao, alteracao, exclusao)
- descricao (TEXT)
- ip_origem (VARCHAR 45)
- user_agent (TEXT)
- timestamp (TIMESTAMP) DEFAULT NOW()

---

## Relacionamentos

### 1:1 (Um para Um)
- USUARIO ↔ PREFERENCIAS_ACESSIBILIDADE
- ALUNO ↔ AVATAR

### 1:N (Um para Muitos)
- USUARIO (1) → ALUNO (N) -- especialização
- USUARIO (1) → PROFESSOR (N) -- especialização
- PROFESSOR (1) → TURMA (N)
- TURMA (1) → ALUNO (N)
- DESAFIO (1) → DICA (N)
- DESAFIO (1) → PROGRESSO_DESAFIO (N)
- ALUNO (1) → PROGRESSO_DESAFIO (N)
- TURMA (1) → RANKING (N)
- RANKING (1) → POSICAO_RANKING (N)
- ALUNO (1) → ALERTA (N)
- PROFESSOR (1) → ALERTA (N)

### N:M (Muitos para Muitos)
- ALUNO ↔ MEDALHA (via ALUNO_MEDALHA)
- DESAFIO ↔ COMPETENCIA_BNCC (via DESAFIO_COMPETENCIA)
- ALUNO ↔ DESAFIO_COLABORATIVO (via ALUNO_DESAFIO_COLABORATIVO)

---

## Índices Recomendados

```sql
-- Performance em queries frequentes
CREATE INDEX idx_aluno_turma ON ALUNO(id_turma);
CREATE INDEX idx_progresso_aluno ON PROGRESSO_DESAFIO(id_aluno);
CREATE INDEX idx_progresso_desafio ON PROGRESSO_DESAFIO(id_desafio);
CREATE INDEX idx_progresso_status ON PROGRESSO_DESAFIO(status);
CREATE INDEX idx_turma_ativa ON TURMA(ativa);
CREATE INDEX idx_desafio_ativo ON DESAFIO(ativo);
CREATE INDEX idx_alerta_professor ON ALERTA(id_professor, visualizado);
CREATE INDEX idx_ranking_turma ON RANKING(id_turma, tipo);
CREATE INDEX idx_log_timestamp ON LOG_SISTEMA(timestamp);
```

---

## Constraints (Restrições)

```sql
-- Garantir integridade
ALTER TABLE TURMA ADD CONSTRAINT chk_ano_escolar
    CHECK (ano_escolar BETWEEN 6 AND 9);

ALTER TABLE TURMA ADD CONSTRAINT chk_codigo_length
    CHECK (LENGTH(codigo_acesso) = 6);

ALTER TABLE PROGRESSO_DESAFIO ADD CONSTRAINT chk_tentativas
    CHECK (tentativas >= 0);

ALTER TABLE PROGRESSO_DESAFIO ADD CONSTRAINT chk_eficiencia
    CHECK (eficiencia_solucao BETWEEN 0.0 AND 1.0);

ALTER TABLE DICA ADD CONSTRAINT chk_nivel_dica
    CHECK (nivel BETWEEN 1 AND 3);

-- Garantir datas lógicas
ALTER TABLE PROGRESSO_DESAFIO ADD CONSTRAINT chk_datas
    CHECK (data_conclusao IS NULL OR data_conclusao >= data_inicio);

-- Limitar alunos por turma
-- Implementado via trigger
```

---

## Triggers Importantes

```sql
-- Atualizar ultimo_acesso automaticamente
CREATE TRIGGER trg_update_ultimo_acesso
AFTER UPDATE ON USUARIO
FOR EACH ROW
EXECUTE FUNCTION atualizar_ultimo_acesso();

-- Verificar limite de alunos na turma
CREATE TRIGGER trg_check_limite_turma
BEFORE INSERT ON ALUNO
FOR EACH ROW
EXECUTE FUNCTION verificar_limite_alunos();

-- Atualizar nível do aluno automaticamente
CREATE TRIGGER trg_update_nivel
AFTER UPDATE OF xp_total ON ALUNO
FOR EACH ROW
EXECUTE FUNCTION calcular_nivel();
```

---

## Diagrama Visual (Descrição para Desenho)

```
┌──────────────┐         ┌──────────────┐
│   USUARIO    │─────────│ PREFERENCIAS │
│              │   1:1   │ ACESSIBILID  │
└──────┬───────┘         └──────────────┘
       │
       ├──────┐
       │      │
┌──────▼────┐ └──────────┐
│   ALUNO   │            │
│           │            │
│  - xp     │◄─────┐     │
│  - nivel  │ 1:1  │     │
└─────┬─────┘      │     │
      │        ┌───▼───┐ │
      │        │AVATAR │ │
      │        └───────┘ │
      │                  │
      │              ┌───▼──────┐
      │              │PROFESSOR │
      │              └─────┬────┘
      │                    │ 1:N
      │                ┌───▼────┐
      │                │ TURMA  │
      │                └───┬────┘
      │                    │
      └────────────────────┘ N:1

┌─────────┐      N:M      ┌──────────┐
│ ALUNO   │◄──────────────►│ MEDALHA  │
└────┬────┘   ALUNO_       └──────────┘
     │        MEDALHA
     │
     │ 1:N
┌────▼───────────┐      1:N    ┌──────────┐
│   PROGRESSO    │◄─────────────│ DESAFIO  │
│   DESAFIO      │              └────┬─────┘
└────────────────┘                   │
                                     │ 1:N
                                ┌────▼─────┐
                                │   DICA   │
                                └──────────┘
```

## Implementação

O modelo será implementado utilizando ferramentas de modelagem de banco de dados compatíveis com a notação DER padrão.

## Entregável

- **Arquivo**: modelo-entidade-relacionamento.png (ou .pdf)
- **Local**: `/diagramas/modelo-entidade-relacionamento.png`
- **Resolução mínima**: 2560x1440px
