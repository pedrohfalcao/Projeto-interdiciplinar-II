# 4.3 DIRETRIZES DE ACESSIBILIDADE (WCAG 2.1)

## Compromisso com Acessibilidade

A plataforma ComputaPlay foi projetada desde sua concepção para ser **totalmente acessível**, atendendo ao nível **AA** das WCAG 2.1 (Web Content Accessibility Guidelines), garantindo que alunos com diferentes tipos de deficiências possam utilizar todas as funcionalidades.

---

## Princípios WCAG Implementados

### 1. PERCEPTÍVEL
Informação e componentes da interface devem ser apresentáveis aos usuários de formas que eles possam perceber.

### 2. OPERÁVEL
Componentes de interface e navegação devem ser operáveis.

### 3. COMPREENSÍVEL
Informação e operação da interface devem ser compreensíveis.

### 4. ROBUSTO
Conteúdo deve ser robusto o suficiente para ser interpretado por diversas tecnologias assistivas.

---

## Diretrizes Detalhadas por Categoria

### 1. CONTRASTE E CORES

#### 1.1 Contraste Mínimo (WCAG 1.4.3 - Nível AA)
- **Texto normal** (< 18px): Contraste mínimo 4.5:1
- **Texto grande** (≥ 18px ou 14px bold): Contraste mínimo 3:1
- **Elementos de UI**: Contraste mínimo 3:1

**Implementação**:
```css
/* Exemplos validados */
--cor-texto-principal: #1A1A1A; /* Sobre fundo branco: 16.5:1 ✓ */
--cor-link: #0066CC; /* Sobre fundo branco: 8.2:1 ✓ */
--cor-botao-primario-bg: #4A90E2;
--cor-botao-primario-texto: #FFFFFF; /* Contraste: 4.6:1 ✓ */
```

**Ferramenta de verificação**: [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/)

#### 1.2 Uso de Cor (WCAG 1.4.1)
**Nunca usar apenas cor para transmitir informação**

❌ **Incorreto**:
```
Status: [Verde] OK  [Vermelho] Erro
```

✅ **Correto**:
```
Status: [✓ Verde] OK  [✗ Vermelho] Erro
```

#### 1.3 Temas de Alto Contraste
- **Tema Claro** (padrão): Texto escuro sobre fundo claro
- **Tema Escuro**: Texto claro sobre fundo escuro
- **Alto Contraste**: Contraste 7:1 ou superior

---

### ⌨️ 2. NAVEGAÇÃO POR TECLADO

#### 2.1 Acessibilidade via Teclado (WCAG 2.1.1)
**Todas as funcionalidades devem ser acessíveis via teclado**

**Teclas implementadas**:
- `Tab`: Navegar para próximo elemento
- `Shift + Tab`: Navegar para elemento anterior
- `Enter`: Ativar botão/link
- `Espaço`: Ativar checkbox/toggle
- `Setas`: Navegar em menus/listas
- `Esc`: Fechar modal/menu

#### 2.2 Foco Visível (WCAG 2.4.7)
**Indicador visual claro de qual elemento está em foco**

```css
*:focus {
  outline: 2px solid #4A90E2;
  outline-offset: 2px;
}

button:focus {
  box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.5);
}
```

#### 2.3 Ordem de Foco (WCAG 2.4.3)
**Sequência lógica de tabulação**
- Da esquerda para direita
- De cima para baixo
- Conteúdo principal antes de sidebars
- Não pular etapas críticas

---

### 3. COMPATIBILIDADE COM LEITORES DE TELA

#### 3.1 Texto Alternativo (WCAG 1.1.1)
**Todas as imagens com alt text descritivo**

```html
<!-- Imagens informativas -->
<img src="medalha-primeira-vitoria.png"
     alt="Medalha Primeira Vitória: estrela dourada com fundo azul">

<!-- Imagens decorativas -->
<img src="decoracao.png" alt="">

<!-- Ícones funcionais -->
<button>
  <img src="icone-ajuda.png" alt="Solicitar ajuda">
</button>
```

#### 3.2 Landmarks e Estrutura Semântica

```html
<header role="banner">
  <nav aria-label="Menu principal">...</nav>
</header>

<main role="main">
  <section aria-labelledby="titulo-desafios">
    <h2 id="titulo-desafios">Meus Desafios</h2>
    ...
  </section>
</main>

<aside role="complementary" aria-label="Progresso">
  ...
</aside>

<footer role="contentinfo">
  ...
</footer>
```

#### 3.3 ARIA Labels e Roles

```html
<!-- Botões sem texto visível -->
<button aria-label="Fechar modal">
  <span aria-hidden="true">✕</span>
</button>

<!-- Estados dinâmicos -->
<div role="alert" aria-live="polite">
  Desafio concluído com sucesso!
</div>

<!-- Expansíveis -->
<button aria-expanded="false" aria-controls="menu-opcoes">
  Opções
</button>
<div id="menu-opcoes" aria-hidden="true">
  ...
</div>

<!-- Progresso -->
<div role="progressbar"
     aria-valuenow="65"
     aria-valuemin="0"
     aria-valuemax="100"
     aria-label="Progresso no desafio">
  65%
</div>
```

#### 3.4 Anúncios Dinâmicos

```html
<!-- Notificações não urgentes -->
<div aria-live="polite" aria-atomic="true">
  Novo aluno entrou na turma
</div>

<!-- Alertas urgentes -->
<div aria-live="assertive" role="alert">
  Erro ao salvar progresso
</div>
```

---

### 4. EDITOR DE BLOCOS ACESSÍVEL

#### 4.1 Descrição Textual de Blocos

**Cada bloco visual tem equivalente textual**

```html
<div class="bloco-loop"
     role="button"
     tabindex="0"
     aria-label="Bloco Repetir: Executa ações internas 4 vezes">

  <div aria-hidden="true">
    <!-- Representação visual -->
    Repetir 4 vezes
  </div>

  <div class="sr-only">
    Início do bloco Repetir 4 vezes.
    Contém 2 blocos internos: Mover Direita, Mover Cima.
    Fim do bloco Repetir.
  </div>
</div>
```

#### 4.2 Navegação no Código

**Teclas especiais para navegar entre blocos**:
- `Seta Cima/Baixo`: Navegar entre blocos do código
- `Seta Direita`: Entrar em bloco aninhado
- `Seta Esquerda`: Sair de bloco aninhado
- `Delete`: Remover bloco em foco
- `Ctrl + Z`: Desfazer
- `Ctrl + Y`: Refazer

#### 4.3 Feedback Sonoro (Opcional)

```javascript
// Sons curtos para ações
const sons = {
  blocoAdicionado: new Audio('sons/bloco-add.mp3'),
  blocoRemovido: new Audio('sons/bloco-remove.mp3'),
  execucaoSucesso: new Audio('sons/sucesso.mp3'),
  execucaoErro: new Audio('sons/erro.mp3')
};

// Permitir usuário desativar
if (preferenciasUsuario.feedbackSonoro) {
  sons.blocoAdicionado.play();
}
```

---

### 5. FORMULÁRIOS E INPUTS

#### 5.1 Labels Associadas (WCAG 1.3.1, 3.3.2)

```html
<!-- Explícita -->
<label for="nome-aluno">Nome Completo:</label>
<input type="text" id="nome-aluno" name="nome" required>

<!-- Implícita -->
<label>
  E-mail:
  <input type="email" name="email" required>
</label>
```

#### 5.2 Mensagens de Erro (WCAG 3.3.1, 3.3.3)

```html
<form>
  <label for="senha">Senha:</label>
  <input type="password"
         id="senha"
         name="senha"
         aria-describedby="senha-requisitos senha-erro"
         aria-invalid="true">

  <p id="senha-requisitos">Mínimo 6 caracteres</p>

  <p id="senha-erro" role="alert" class="erro">
    A senha deve ter pelo menos 6 caracteres
  </p>
</form>
```

#### 5.3 Autocomplete (WCAG 1.3.5)

```html
<input type="text"
       name="nome"
       autocomplete="name">

<input type="email"
       name="email"
       autocomplete="email">
```

---

### 6. CONTEÚDO MULTIMÍDIA

#### 6.1 Legendas (WCAG 1.2.2)

```html
<video controls>
  <source src="tutorial.mp4" type="video/mp4">
  <track kind="captions"
         src="tutorial-pt-br.vtt"
         srclang="pt-BR"
         label="Português (Brasil)"
         default>
</video>
```

#### 6.2 Transcrição (WCAG 1.2.8)

```html
<video controls>
  <source src="introducao.mp4">
</video>

<details>
  <summary>Ver transcrição completa</summary>
  <p>
    [00:00] Olá! Bem-vindo ao ComputaPlay...
    [00:15] Neste vídeo você aprenderá...
  </p>
</details>
```

#### 6.3 Controle de Áudio Automático (WCAG 1.4.2)

- **Nunca** reproduzir áudio automaticamente por mais de 3 segundos
- Fornecer controle de pausa/stop
- Permitir ajuste de volume independente

---

### 7. RESPONSIVIDADE E ZOOM

#### 7.1 Zoom até 200% (WCAG 1.4.4)
- Conteúdo deve permanecer legível e funcional até 200% de zoom
- Sem scroll horizontal desnecessário
- Sem perda de funcionalidades

#### 7.2 Reflow (WCAG 1.4.10)
- Conteúdo se reorganiza em viewport de 320px de largura
- Sem scroll bidimensional

```css
/* Design responsivo */
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
}

@media (max-width: 768px) {
  .grid-3-colunas {
    grid-template-columns: 1fr;
  }
}
```

---

### ⏱️ 8. TEMPO E ANIMAÇÕES

#### 8.1 Tempo Ajustável (WCAG 2.2.1)
- Não impor limites de tempo estritos
- Permitir pausar, estender ou desativar timers

#### 8.2 Pausar Animações (WCAG 2.2.2, 2.3.3)

```css
/* Respeitar preferência do sistema */
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

```html
<!-- Controle de animação -->
<button onclick="toggleAnimacoes()">
  Pausar Animações
</button>
```

---

### 🧩 9. TAMANHO DE ALVOS DE TOQUE

#### 9.1 Target Size (WCAG 2.5.5 - Nível AAA)
**Tamanho mínimo: 44x44px para elementos interativos**

```css
button,
a,
input[type="checkbox"],
input[type="radio"] {
  min-width: 44px;
  min-height: 44px;
}

/* Aumentar área clicável sem aumentar visual */
.botao-pequeno {
  position: relative;
}

.botao-pequeno::after {
  content: '';
  position: absolute;
  top: -12px;
  left: -12px;
  right: -12px;
  bottom: -12px;
}
```

---

## Checklist de Conformidade WCAG 2.1 AA

### Nível A (Obrigatório)

- [ ] **1.1.1** Conteúdo não textual tem alternativa textual
- [ ] **1.3.1** Informação e estrutura podem ser determinadas programaticamente
- [ ] **1.4.1** Cor não é único meio de transmitir informação
- [ ] **2.1.1** Toda funcionalidade via teclado
- [ ] **2.4.1** Mecanismo para pular blocos repetidos
- [ ] **2.4.2** Páginas têm títulos descritivos
- [ ] **3.1.1** Idioma da página definido
- [ ] **3.2.1** Foco não causa mudanças inesperadas de contexto
- [ ] **3.3.1** Erros identificados e descritos em texto
- [ ] **4.1.1** HTML válido (sem erros de parsing)
- [ ] **4.1.2** Nome, função e valor de elementos são determinados programaticamente

### Nível AA (Obrigatório neste projeto)

- [ ] **1.4.3** Contraste mínimo de 4.5:1 (texto) e 3:1 (UI)
- [ ] **1.4.5** Texto como imagem só se essencial
- [ ] **2.4.5** Mais de uma forma de encontrar páginas
- [ ] **2.4.6** Headings e labels são descritivos
- [ ] **2.4.7** Foco visível
- [ ] **3.1.2** Idioma de partes específicas identificado
- [ ] **3.2.3** Navegação consistente
- [ ] **3.2.4** Identificação consistente de componentes
- [ ] **3.3.3** Sugestões de correção de erros
- [ ] **3.3.4** Prevenção de erros (legais, financeiros, dados)

---

## Testes de Acessibilidade

### Ferramentas Automatizadas
1. **axe DevTools** (extensão Chrome/Firefox)
2. **WAVE** (Web Accessibility Evaluation Tool)
3. **Lighthouse** (Chrome DevTools)
4. **Pa11y** (linha de comando)

### Testes Manuais
1. **Navegação por teclado**: Testar todos os fluxos apenas com Tab/Enter
2. **Leitor de tela**: NVDA (Windows), VoiceOver (Mac), TalkBack (Android)
3. **Zoom**: Testar até 200% de zoom
4. **Contraste**: Validar todas as combinações de cores
5. **Desativar CSS**: Verificar se conteúdo continua compreensível

### Testes com Usuários Reais
- Sessões com alunos com deficiência visual
- Sessões com alunos com deficiência auditiva
- Sessões com alunos com deficiência motora
- Sessões com alunos com dislexia/TDAH

---

## Documentação de Acessibilidade

### Para Desenvolvedores
- Guia de componentes acessíveis
- Exemplos de código ARIA
- Checklist em cada Pull Request

### Para Usuários
- Página "Recursos de Acessibilidade" explicando:
  - Como ativar leitor de tela
  - Atalhos de teclado disponíveis
  - Como personalizar aparência
  - Como reportar problemas de acessibilidade

---

## Compromisso Contínuo

A acessibilidade não é uma funcionalidade a ser "adicionada" posteriormente, mas um princípio fundamental que permeia todas as decisões de design e desenvolvimento do ComputaPlay.

**Meta**: 100% de conformidade WCAG 2.1 Nível AA, validada por:
- Auditoria automatizada sem erros críticos
- Testes manuais aprovados
- Feedback positivo de usuários com deficiências
