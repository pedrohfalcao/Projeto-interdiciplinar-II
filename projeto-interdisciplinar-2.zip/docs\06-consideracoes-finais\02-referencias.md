# 6.3 REFERÊNCIAS BIBLIOGRÁFICAS

## Documentos Oficiais

BRASIL. **Base Nacional Comum Curricular (BNCC)**. Ministério da Educação, 2018. Disponível em: http://basenacionalcomum.mec.gov.br/. Acesso em: 15 set. 2024.

BRASIL. **Lei nº 13.709, de 14 de agosto de 2018**. Lei Geral de Proteção de Dados Pessoais (LGPD). Brasília, DF: Presidência da República, 2018.

BRASIL. **Lei nº 13.146, de 6 de julho de 2015**. Lei Brasileira de Inclusão da Pessoa com Deficiência (Estatuto da Pessoa com Deficiência). Brasília, DF: Presidência da República, 2015.

---

## Pensamento Computacional

WING, Jeannette M. **Computational Thinking**. Communications of the ACM, v. 49, n. 3, p. 33-35, 2006. DOI: 10.1145/1118178.1118215

BRACKMANN, Christian Puhlmann. **Desenvolvimento do pensamento computacional através de atividades desplugadas na educação básica**. Tese (Doutorado) - Universidade Federal do Rio Grande do Sul, Porto Alegre, 2017.

VALENTE, José Armando. **Integração do Pensamento Computacional no Currículo da Educação Básica: diferentes estratégias usadas e questões de formação de professores e avaliação do aluno**. Revista e-Curriculum, São Paulo, v. 14, n. 3, p. 864-897, jul./set. 2016.

PAPERT, Seymour. **Mindstorms: Children, Computers, and Powerful Ideas**. New York: Basic Books, 1980.

---

## Gamificação na Educação

DETERDING, Sebastian et al. **From game design elements to gamefulness: defining gamification**. In: Proceedings of the 15th International Academic MindTrek Conference: Envisioning Future Media Environments. ACM, 2011. p. 9-15.

KAPP, Karl M. **The Gamification of Learning and Instruction: Game-based Methods and Strategies for Training and Education**. San Francisco: Pfeiffer, 2012.

ALVES, Flora. **Gamification: como criar experiências de aprendizagem engajadoras - Um guia completo**. 2. ed. São Paulo: DVS Editora, 2015.

FARDO, Marcelo Luis. **A gamificação aplicada em ambientes de aprendizagem**. RENOTE - Revista Novas Tecnologias na Educação, v. 11, n. 1, 2013.

---

## Acessibilidade e Educação Inclusiva

W3C. **Web Content Accessibility Guidelines (WCAG) 2.1**. W3C Recommendation, 2018. Disponível em: https://www.w3.org/TR/WCAG21/. Acesso em: 22 set. 2024.

MANTOAN, Maria Teresa Eglér. **Inclusão escolar: o que é? Por quê? Como fazer?** São Paulo: Moderna, 2003.

SASSAKI, Romeu Kazumi. **Inclusão: acessibilidade no lazer, trabalho e educação**. Revista Nacional de Reabilitação (Reabil), São Paulo, ano XII, p. 10-16, mar./abr. 2009.

NIELSEN, Jakob. **Usability for People with Disabilities**. Nielsen Norman Group, 2001. Disponível em: https://www.nngroup.com/articles/usability-for-people-with-disabilities/. Acesso em: 08 out. 2024.

---

## Interação Humano-Computador

PREECE, Jennifer; ROGERS, Yvonne; SHARP, Helen. **Design de Interação: além da interação humano-computador**. 3. ed. Porto Alegre: Bookman, 2013.

NORMAN, Donald A. **The Design of Everyday Things: Revised and Expanded Edition**. New York: Basic Books, 2013.

BARBOSA, Simone Diniz Junqueira; SILVA, Bruno Santana da. **Interação Humano-Computador**. Rio de Janeiro: Elsevier, 2010.

---

## Programação em Blocos e Ferramentas Visuais

RESNICK, Mitchel et al. **Scratch: Programming for All**. Communications of the ACM, v. 52, n. 11, p. 60-67, 2009.

FRASER, Neil. **Blockly: A Visual Programming Editor**. Google Developers Blog, 2012. Disponível em: https://developers.google.com/blockly. Acesso em: 18 set. 2024.

MALONEY, John et al. **The Scratch Programming Language and Environment**. ACM Transactions on Computing Education, v. 10, n. 4, Article 16, 2010.

---

## Engenharia de Software

SOMMERVILLE, Ian. **Engenharia de Software**. 10. ed. São Paulo: Pearson, 2019.

PRESSMAN, Roger S.; MAXIM, Bruce R. **Engenharia de Software: Uma Abordagem Profissional**. 8. ed. Porto Alegre: AMGH, 2016.

FOWLER, Martin. **UML Distilled: A Brief Guide to the Standard Object Modeling Language**. 3rd ed. Boston: Addison-Wesley, 2003.

GAMMA, Erich et al. **Design Patterns: Elements of Reusable Object-Oriented Software**. Boston: Addison-Wesley, 1994.

---

## Desenvolvimento Web

FLANAGAN, David. **JavaScript: The Definitive Guide**. 7th ed. O'Reilly Media, 2020.

BANKS, Alex; PORCELLO, Eve. **Learning React: Modern Patterns for Developing React Apps**. 2nd ed. O'Reilly Media, 2020.

BROWN, Ethan. **Web Development with Node and Express**. 2nd ed. O'Reilly Media, 2019.

MOZILLA DEVELOPER NETWORK. **Web Accessibility**. Disponível em: https://developer.mozilla.org/en-US/docs/Web/Accessibility. Acesso em: 12 out. 2024.

---

## Banco de Dados

ELMASRI, Ramez; NAVATHE, Shamkant B. **Sistemas de Banco de Dados**. 7. ed. São Paulo: Pearson, 2019.

DATE, C. J. **Introdução a Sistemas de Bancos de Dados**. 8. ed. Rio de Janeiro: Campus, 2004.

POSTGRESQL GLOBAL DEVELOPMENT GROUP. **PostgreSQL Documentation**. Version 14. Disponível em: https://www.postgresql.org/docs/14/. Acesso em: 28 set. 2024.

---

## Educação e Tecnologia

MORAN, José; MASETTO, Marcos; BEHRENS, Marilda. **Novas tecnologias e mediação pedagógica**. 21. ed. Campinas: Papirus, 2013.

KENSKI, Vani Moreira. **Educação e Tecnologias: o novo ritmo da informação**. 8. ed. Campinas: Papirus, 2012.

LEVY, Pierre. **Cibercultura**. São Paulo: Editora 34, 1999.

PRENSKY, Marc. **Digital Natives, Digital Immigrants**. On the Horizon, MCB University Press, v. 9, n. 5, 2001.

---

## Estatísticas e Pesquisas

IBGE. **Censo Demográfico 2010: Características gerais da população, religião e pessoas com deficiência**. Rio de Janeiro: IBGE, 2012.

CETIC.BR. **TIC Educação 2021: Pesquisa sobre o uso das tecnologias de informação e comunicação nas escolas brasileiras**. São Paulo: Comitê Gestor da Internet no Brasil, 2022.

INEP. **Censo Escolar 2022**. Brasília: Instituto Nacional de Estudos e Pesquisas Educacionais Anísio Teixeira, 2023.

---

## Frameworks e Bibliotecas (Documentação Técnica)

REACT. **React Documentation**. Facebook Inc., 2024. Disponível em: https://react.dev/. Acesso em: 05 nov. 2024.

EXPRESS.JS. **Express.js Documentation**. OpenJS Foundation, 2024. Disponível em: https://expressjs.com/. Acesso em: 10 nov. 2024.

PRISMA. **Prisma Documentation**. Prisma Data, Inc., 2024. Disponível em: https://www.prisma.io/docs. Acesso em: 14 out. 2024.

TAILWIND CSS. **Tailwind CSS Documentation**. Tailwind Labs Inc., 2024. Disponível em: https://tailwindcss.com/docs. Acesso em: 20 out. 2024.

SOCKET.IO. **Socket.IO Documentation**. 2024. Disponível em: https://socket.io/docs/. Acesso em: 03 out. 2024.

---

## Testes e Qualidade de Software

BECK, Kent. **Test Driven Development: By Example**. Boston: Addison-Wesley, 2002.

JEST. **Jest Documentation**. Meta Platforms, Inc., 2024. Disponível em: https://jestjs.io/. Acesso em: 25 out. 2024.

TESTING LIBRARY. **React Testing Library**. 2024. Disponível em: https://testing-library.com/react. Acesso em: 18 nov. 2024.

---

## Acessibilidade Web (Recursos Técnicos)

WEBAIM. **WebAIM: Web Accessibility In Mind**. Disponível em: https://webaim.org/. Acesso em: 07 nov. 2024.

DEQUE SYSTEMS. **axe Accessibility Testing Tools**. Disponível em: https://www.deque.com/axe/. Acesso em: 02 set. 2024.

A11Y PROJECT. **The A11Y Project: A community-driven effort to make digital accessibility easier**. Disponível em: https://www.a11yproject.com/. Acesso em: 11 set. 2024.

---

## Design e Prototipação

FIGMA. **Figma: The Collaborative Interface Design Tool**. Disponível em: https://www.figma.com/. Acesso em: 29 out. 2024.

GARRETT, Jesse James. **The Elements of User Experience: User-Centered Design for the Web and Beyond**. 2nd ed. Berkeley: New Riders, 2010.

KRUG, Steve. **Don't Make Me Think, Revisited: A Common Sense Approach to Web Usability**. 3rd ed. Berkeley: New Riders, 2014.

---

## Metodologias Ágeis

SCHWABER, Ken; SUTHERLAND, Jeff. **The Scrum Guide**. 2020. Disponível em: https://scrumguides.org/. Acesso em: 23 nov. 2024.

BECK, Kent et al. **Manifesto for Agile Software Development**. 2001. Disponível em: https://agilemanifesto.org/. Acesso em: 16 nov. 2024.

---

## Contextualização Regional (Paraíba)

PARAÍBA. Secretaria de Estado da Educação e da Ciência e Tecnologia. **Referencial Curricular da Paraíba**. João Pessoa: SEE-PB, 2018.

ALMEIDA, Horácio de. **História da Paraíba**. 2. ed. João Pessoa: Editora Universitária/UFPB, 1997.

---

## Artigos e Estudos de Caso

RODRIGUEZ-PEREZ, Neftali et al. **Computational Thinking and Student Engagement: A Review of the Literature**. Journal of Educational Computing Research, v. 58, n. 7, p. 1232-1260, 2020.

GROVER, Shuchi; PEA, Roy. **Computational Thinking in K-12: A Review of the State of the Field**. Educational Researcher, v. 42, n. 1, p. 38-43, 2013.

LODI, Michael; MARTINI, Simone. **Computational Thinking, Between Papert and Wing**. Science & Education, v. 30, p. 883-908, 2021.

---

## Normas e Padrões

ABNT. **NBR 9050:2020 - Acessibilidade a edificações, mobiliário, espaços e equipamentos urbanos**. Rio de Janeiro: ABNT, 2020.

ISO/IEC. **ISO/IEC 25010:2011 - Systems and software engineering — Systems and software Quality Requirements and Evaluation (SQuaRE)**. Geneva: ISO, 2011.

