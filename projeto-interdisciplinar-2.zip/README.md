# COMPUTAPLAY
## Gamificação e Acessibilidade no Ensino de Pensamento Computacional para Alunos do Ensino Fundamental II

![Status](https://img.shields.io/badge/Status-Documentação%20Completa-success)
![Versão](https://img.shields.io/badge/Versão-1.0-blue)
![BNCC](https://img.shields.io/badge/BNCC-Alinhado-green)
![WCAG](https://img.shields.io/badge/WCAG-2.1%20AA-purple)

---

## Índice

- [Sobre o Projeto](#sobre-o-projeto)
- [Problema e Solução](#problema-e-solução)
- [Funcionalidades Principais](#funcionalidades-principais)
- [Diferenciais](#diferenciais)
- [Estrutura da Documentação](#estrutura-da-documentação)
- [Tecnologias Previstas](#tecnologias-previstas)
- [Como Navegar Este Projeto](#como-navegar-este-projeto)
- [Equipe](#equipe)
- [Licença](#licença)
- [Contato](#contato)

---

## Sobre o Projeto

**ComputaPlay** é uma plataforma educacional web gamificada, acessível e de baixo custo, desenvolvida para ensinar os pilares do pensamento computacional (decomposição, reconhecimento de padrões, abstração e algoritmos) a alunos do 6º ao 9º ano do Ensino Fundamental II da rede pública de ensino.

### Contexto

A Base Nacional Comum Curricular (BNCC) prevê o desenvolvimento do pensamento computacional desde os anos iniciais. No entanto, muitas escolas públicas, especialmente em regiões como João Pessoa - PB, carecem de:
- Recursos e laboratórios adequados
- Professores com formação específica em programação
- Ferramentas educacionais acessíveis e inclusivas

### Objetivos

1. Criar uma plataforma **web responsiva** que funcione em dispositivos de baixo custo
2. Implementar **mecânicas de gamificação** engajadoras (XP, medalhas, narrativas)
3. Desenvolver **editor de lógica visual** (programação em blocos)
4. Garantir **acessibilidade total** (WCAG 2.1 Nível AA)
5. Fornecer **módulo do professor** com dashboard e relatórios
6. Alinhar **100% com a BNCC**

---

## Problema e Solução

### Problema Central

Como criar uma plataforma educacional web, de baixo custo e alta acessibilidade, que utilize a gamificação para ensinar os pilares do pensamento computacional a alunos do 6º ao 9º ano, permitindo que professores sem conhecimento prévio em programação possam aplicá-la em sala de aula?

### Nossa Solução

**ComputaPlay** combina:
- **Interface visual intuitiva** com programação em blocos
- **Gamificação contextualizada** com elementos da cultura paraibana
- **Acessibilidade universal** desde a concepção (não como adaptação)
- **Recursos pedagógicos prontos** para professores (planos de aula, atividades desplugadas)
- **Análise automatizada** de dificuldades dos alunos com alertas para professores
- **Gratuidade** e código aberto

---

## Funcionalidades Principais

### Para Alunos

- **Trilha de Aprendizagem**: Desafios progressivos com narrativa envolvente
- **Editor de Blocos**: Interface drag-and-drop para criar algoritmos visualmente
- **Sistema de XP e Níveis**: Progressão gamificada com recompensas
- **Medalhas**: Conquistas por diferentes tipos de realizações
- **Avatar Customizável**: Personalização com itens desbloqueáveis
- **Ranking Colaborativo**: Valoriza cooperação além de competição
- **Ajuda entre Colegas**: Sistema de mentoria peer-to-peer
- **Acessibilidade**: Navegação por teclado, leitores de tela, alto contraste

### Para Professores

- **Dashboard de Turmas**: Visão geral do progresso de todos os alunos
- **Identificação Automática de Dificuldades**: Alertas sobre alunos que precisam de atenção
- **Relatórios Exportáveis**: PDF e CSV com métricas detalhadas
- **Planos de Aula Prontos**: Alinhados à BNCC, editáveis
- **Atividades Desplugadas**: Banco de atividades sem computador
- **Criação de Turmas Simples**: Código de acesso automático

### Para Administradores

- **Gestão de Conteúdo**: CRUD de desafios, planos de aula
- **Mapeamento BNCC**: Tags de competências em cada desafio
- **Logs e Auditoria**: Monitoramento de uso e erros
- **Moderação**: Controle de conteúdo gerado por usuários

---

## Diferenciais

| Aspecto | Outras Plataformas | ComputaPlay |
|---------|-------------------|-------------|
| **Custo** | R$ 50-200/aluno/ano | **Gratuito** |
| **Acessibilidade** | Parcial ou inexistente | **WCAG 2.1 AA** |
| **Requisitos** | Computadores potentes | **2GB RAM, navegador** |
| **Formação Docente** | Exige conhecimento prévio | **Não exige programação** |
| **Contextualização** | Conteúdo genérico | **Cultura paraibana/nordestina** |
| **Offline** | Apenas online | **PWA com modo offline** |
| **Código** | Proprietário | **Open-source** |

---

## Estrutura da Documentação

Este projeto está **100% documentado** conforme requisitos acadêmicos:

```
projeto/
├── README.md (este arquivo)
├── docs/
│   ├── 01-documentacao-geral/
│   │   ├── 01-capa-identificacao.md
│   │   ├── 02-sumario.md
│   │   ├── 03-descricao-problema.md
│   │   ├── 04-objetivos.md
│   │   ├── 05-justificativa.md
│   │   └── 06-publico-alvo.md
│   ├── 02-engenharia-requisitos/
│   │   ├── 01-requisitos-funcionais-nao-funcionais.md
│   │   ├── 02-historias-de-usuario.md
│   │   ├── 03-casos-de-uso.md
│   │   └── 04-regras-de-negocio.md
│   ├── 03-modelagem-arquitetura/
│   │   ├── 01-diagrama-casos-de-uso.md
│   │   ├── 02-diagrama-classes.md
│   │   ├── 03-fluxograma-bpmn.md
│   │   ├── 04-diagrama-sequencia.md
│   │   └── 05-modelo-dados-der.md
│   ├── 04-interface-prototipacao/
│   │   ├── 01-wireframes.md
│   │   ├── 02-prototipo-navegavel.md
│   │   └── 03-diretrizes-acessibilidade.md
│   ├── 05-design-solucao/
│   │   ├── 01-arquitetura-sistema.md
│   │   └── 02-modulos-funcionalidades.md
│   └── 06-consideracoes-finais/
│       ├── 01-limitacoes-melhorias.md
│       └── 02-referencias.md
├── Diagramas/ (9 arquivos SVG - 1.1 MB)
├── wireframes/ (pasta preparada para wireframes em Figma/XD)
└── src/ (código-fonte - a ser desenvolvido)
```

---

## Tecnologias Previstas

### Front-end
- **React.js 18+**: Framework principal
- **Redux Toolkit**: Gerenciamento de estado
- **Blockly**: Editor de programação em blocos
- **Tailwind CSS**: Estilização responsiva
- **Chart.js**: Gráficos e visualizações
- **Framer Motion**: Animações

### Back-end
- **Node.js 18 LTS**: Runtime
- **Express.js**: Framework web
- **Prisma**: ORM
- **Socket.io**: Comunicação em tempo real
- **JWT**: Autenticação
- **bcrypt**: Hash de senhas

### Banco de Dados
- **PostgreSQL 14+**: Banco relacional principal
- **Redis**: Cache e sessões

### Infraestrutura
- **AWS / Heroku / DigitalOcean**: Hospedagem
- **GitHub Actions**: CI/CD
- **Sentry**: Monitoramento de erros

### Ferramentas de Desenvolvimento
- **Figma**: Design e prototipação
- **Jest + Testing Library**: Testes
- **ESLint + Prettier**: Qualidade de código
- **PlantUML / Lucidchart**: Diagramas UML

---

## Como Navegar Este Projeto

### Para Professores e Pedagogos
1. Leia [`03-descricao-problema.md`](docs/01-documentacao-geral/03-descricao-problema.md) para entender o contexto
2. Veja [`06-publico-alvo.md`](docs/01-documentacao-geral/06-publico-alvo.md) para conhecer as personas
3. Explore [`02-historias-de-usuario.md`](docs/02-engenharia-requisitos/02-historias-de-usuario.md) para entender funcionalidades

### Para Desenvolvedores
1. Comece por [`01-arquitetura-sistema.md`](docs/05-design-solucao/01-arquitetura-sistema.md) para visão técnica
2. Veja [`02-diagrama-classes.md`](docs/03-modelagem-arquitetura/02-diagrama-classes.md) para estrutura de dados
3. Consulte [`01-requisitos-funcionais-nao-funcionais.md`](docs/02-engenharia-requisitos/01-requisitos-funcionais-nao-funcionais.md) para especificações

### Para Designers
1. Analise [`01-wireframes.md`](docs/04-interface-prototipacao/01-wireframes.md) para esqueletos das telas
2. Leia [`03-diretrizes-acessibilidade.md`](docs/04-interface-prototipacao/03-diretrizes-acessibilidade.md) atentamente
3. Explore [`02-prototipo-navegavel.md`](docs/04-interface-prototipacao/02-prototipo-navegavel.md)

### Para Gestores e Tomadores de Decisão
1. Leia [`05-justificativa.md`](docs/01-documentacao-geral/05-justificativa.md) para entender relevância
2. Veja [`01-limitacoes-melhorias.md`](docs/06-consideracoes-finais/01-limitacoes-melhorias.md) para riscos e roadmap

---

## Requisitos de Entrega

Este projeto atende **100%** aos requisitos especificados:

### ✅ Documentação Geral
- [x] Capa e identificação do grupo
- [x] Sumário
- [x] Descrição da situação-problema
- [x] Objetivos (geral e específicos)
- [x] Justificativa e relevância
- [x] Público-alvo e perfis de usuários

### ✅ Engenharia de Requisitos
- [x] Requisitos funcionais e não funcionais
- [x] Histórias de usuário
- [x] Casos de uso
- [x] Regras de negócio

### ✅ Modelagem e Arquitetura
- [x] Diagrama de Casos de Uso
- [x] Diagrama de Classes
- [x] Fluxogramas e BPMN
- [x] Diagrama de Sequência
- [x] Modelo Conceitual de Dados (DER)

### ✅ Interface e Prototipação
- [x] Wireframes das telas principais
- [x] Protótipo navegável (descrição para Figma)
- [x] Diretrizes de acessibilidade (WCAG)

### ✅ Design da Solução
- [x] Arquitetura do sistema
- [x] Tecnologias previstas
- [x] Descrição dos módulos e funcionalidades

### ✅ Considerações Finais
- [x] Limitações do protótipo
- [x] Possíveis evoluções futuras
- [x] Referências bibliográficas

---

## Próximos Passos

### Fase 1: Validação (1-2 semanas)
- [ ] Apresentar documentação para stakeholders
- [ ] Coletar feedback de professores e alunos
- [ ] Ajustar requisitos conforme necessário

### Fase 2: Prototipação Visual (2-4 semanas)
- [ ] Criar wireframes interativos no Figma
- [ ] Desenvolver design system completo
- [ ] Realizar testes de usabilidade

### Fase 3: Desenvolvimento MVP (3-4 meses)
- [ ] Setup de ambiente e repositórios
- [ ] Desenvolvimento de módulos essenciais
- [ ] Testes e QA contínuos

### Fase 4: Piloto (2-3 meses)
- [ ] Implantação em 3-5 escolas
- [ ] Coleta de métricas de uso
- [ ] Iterações baseadas em feedback

### Fase 5: Lançamento (1-2 meses)
- [ ] Escala para 10+ escolas
- [ ] Formação em massa de professores
- [ ] Disponibilização pública

---

## Equipe

| Nome | E-mail |
|------|--------|
| Luiz Henrique da Silva Araujo | luiz.araujo04@cs.unipe.edu.br |
| Kaua Douglas Pereira Moura | kaua.moura@cs.unipe.edu.br |
| Pedro Henrique Falcao | pedro.falcao@cs.unipe.edu.br |

**Orientador**: Prof. Ricardo Dantas Silva
**Disciplina**: Projeto Interdisciplinar I
**Instituição**: UNIPÊ - Ciência da Computação

---

## Licença

Este projeto está licenciado sob a licença **MIT** - veja o arquivo [LICENSE](LICENSE) para detalhes.

Desenvolvido com o objetivo de democratizar o acesso à educação em pensamento computacional, o ComputaPlay é **open-source** e pode ser utilizado, modificado e distribuído livremente por instituições educacionais.

---

## Contato

Para dúvidas, sugestões ou parcerias:

- **E-mail do Projeto**: computaplay@exemplo.com
- **GitHub**: [github.com/usuario/computaplay](https://github.com/usuario/computaplay)
- **Site**: [www.computaplay.com.br](https://www.computaplay.com.br) (em construção)

---

## Agradecimentos

Agradecemos a todos os professores, alunos e profissionais da educação que contribuíram com ideias, feedback e validação durante a concepção deste projeto.

Agradecimentos especiais:
- Comunidade open-source pelas ferramentas incríveis
- Pesquisadores em pensamento computacional que inspiraram este trabalho
- Todos que acreditam no poder transformador da educação inclusiva

---

**Desenvolvido com ❤️ para a educação pública brasileira**

**João Pessoa - PB | 2025**

---

## Status do Projeto

**Documentação Completa** - Pronto para apresentação e aprovação
**Protótipo Visual** - Em planejamento
**Desenvolvimento** - Aguardando início

---

## Contribuições

Este é um projeto educacional open-source. Contribuições são bem-vindas!

### Como Contribuir
1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/NovaFuncionalidade`)
3. Commit suas mudanças (`git commit -m 'Adiciona nova funcionalidade'`)
4. Push para a branch (`git push origin feature/NovaFuncionalidade`)
5. Abra um Pull Request

---

## Estrelas e Forks

Se este projeto foi útil para você, considere dar uma ⭐ no repositório!

---

## Changelog

### [1.0.1] - 2025-11-30
#### Corrigido
- Correção de inconsistência institucional (UNIPÊ)
- Atualização de e-mails da equipe
- Correção de referências bibliográficas (datas de acesso)
- Adição de links de navegação no sumário

### [1.0.0] - 2025-11-30
#### Adicionado
- Documentação completa do projeto
- Estrutura de arquivos organizada
- README detalhado

---

**Última atualização**: 30 de novembro de 2025
