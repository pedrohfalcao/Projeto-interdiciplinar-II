# 1.4 OBJETIVOS DO PROJETO

## 1.4.1 Objetivo Geral

Desenvolver uma plataforma educacional web gamificada, acessível e de baixo custo, denominada **ComputaPlay**, para o ensino dos pilares do pensamento computacional a alunos do 6º ao 9º ano do Ensino Fundamental II da rede pública de ensino, capacitando professores sem formação específica em programação a aplicarem metodologias ativas de aprendizagem alinhadas à BNCC.

## 1.4.2 Objetivos Específicos

### 1. Desenvolvimento da Plataforma Web Responsiva
- Criar uma aplicação web que funcione em qualquer navegador moderno (Chrome, Firefox, Edge, Safari)
- Garantir compatibilidade com dispositivos de baixo custo (tablets, Chromebooks, smartphones)
- Implementar design responsivo para diferentes tamanhos de tela
- Otimizar o desempenho para funcionar em conexões de internet limitadas (modo offline parcial)

### 2. Implementação de Mecânicas de Gamificação
- Desenvolver um sistema de narrativa envolvente contextualizada na cultura paraibana
- Criar sistema de avatares customizáveis para personalização da experiência
- Implementar sistema de pontuação e recompensas (XP - Experience Points)
- Desenvolver sistema de medalhas (badges) por conquistas específicas
- Criar ranking colaborativo que valorize cooperação além da competição
- Implementar progressão de níveis com desbloqueio gradual de conteúdos

### 3. Criação do Editor de Lógica Visual (Block-based)
- Desenvolver ou adaptar interface de programação em blocos (inspirada em Scratch/Blockly)
- Implementar blocos visuais para estruturas de controle (loops, condicionais)
- Criar blocos para manipulação de variáveis e funções
- Desenvolver desafios progressivos que traduzam conceitos abstratos em problemas visuais
- Implementar sistema de feedback imediato e dicas contextuais

### 4. Garantia de Acessibilidade (WCAG 2.1 Nível AA)
- Implementar alto contraste e opções de personalização visual
- Garantir navegação completa via teclado (sem dependência de mouse)
- Desenvolver compatibilidade total com leitores de tela (NVDA, JAWS, TalkBack)
- Adicionar legendas e transcrições para conteúdos audiovisuais
- Criar alternativas textuais para elementos visuais
- Implementar sinalizador de Libras (opcional, em vídeos introdutórios)
- Desenvolver interface simplificada para alunos com deficiências cognitivas

### 5. Desenvolvimento do Módulo do Professor
- Criar área administrativa restrita com autenticação segura
- Implementar funcionalidade de criação e gestão de turmas
- Desenvolver dashboard de acompanhamento do progresso individual e coletivo
- Criar sistema de identificação automática de dificuldades recorrentes
- Fornecer banco de atividades "desplugadas" (sem computador) complementares
- Gerar relatórios exportáveis de desempenho (PDF, CSV)
- Disponibilizar planos de aula prontos e customizáveis

### 6. Alinhamento com a BNCC
- Mapear todas as competências e habilidades da BNCC relacionadas ao pensamento computacional
- Estruturar desafios e atividades que atendam aos objetivos de aprendizagem por ano escolar
- Criar sistema de tags que relacione cada atividade às competências desenvolvidas
- Desenvolver trilhas de aprendizagem progressivas (6º, 7º, 8º e 9º anos)
- Garantir interdisciplinaridade (Matemática, Ciências, Língua Portuguesa)

### 7. Validação e Testes com Público-Alvo
- Realizar testes de usabilidade com alunos do 6º ao 9º ano
- Validar a plataforma com professores da rede pública
- Testar acessibilidade com alunos com diferentes tipos de deficiências
- Coletar feedback para iterações e melhorias
- Medir indicadores de engajamento e aprendizagem

### 8. Documentação e Capacitação
- Criar documentação técnica completa do sistema
- Desenvolver manual do professor com guia passo a passo
- Produzir tutoriais em vídeo para alunos e professores
- Elaborar FAQ (perguntas frequentes) sobre uso da plataforma
- Criar material de apoio para formação continuada de professores

## Indicadores de Sucesso

- Plataforma funcional em dispositivos com no mínimo 2GB de RAM
- Conformidade com WCAG 2.1 Nível AA validada por ferramentas automatizadas
- Pelo menos 80% de satisfação em pesquisas com professores e alunos
- Redução de 50% no tempo de preparação de aulas sobre pensamento computacional
- Aumento mensurável no desempenho dos alunos em habilidades de resolução de problemas
- Adoção por pelo menos 5 escolas públicas na fase piloto
