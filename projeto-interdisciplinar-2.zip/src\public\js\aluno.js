let usuario = null;
let desafioAtual = null;
let blocosArrastados = [];

const nomeAlunoEl = document.getElementById('nomeAluno');
const nivelEl = document.getElementById('nivel');
const xpTotalEl = document.getElementById('xpTotal');
const listaDesafios = document.getElementById('listaDesafios');
const listaMedalhas = document.getElementById('listaMedalhas');
const listaRanking = document.getElementById('listaRanking');
const desafiosSection = document.getElementById('desafiosSection');
const medalhasSection = document.getElementById('medalhasSection');
const rankingSection = document.getElementById('rankingSection');
const editorSection = document.getElementById('editorSection');
const feedbackArea = document.getElementById('feedbackArea');
const areaTrabalho = document.getElementById('areaTrabalho');
const tabButtons = document.querySelectorAll('.btn-aba');

window.addEventListener('DOMContentLoaded', () => {
    initAluno();
});

async function initAluno() {
    await carregarUsuario();
    carregarDesafios();
    mostrarAba('desafios');
}

async function carregarUsuario() {
    try {
        const response = await fetch('/api/autenticado');

        if (!response.ok) {
            window.location.href = 'index.html';
            return;
        }

        const data = await response.json();
        usuario = data.usuario;
        nomeAlunoEl.textContent = usuario.nome;
        nivelEl.textContent = usuario.nivel || 1;
        xpTotalEl.textContent = usuario.xp || 0;
    } catch (err) {
        window.location.href = 'index.html';
    }
}

async function carregarDesafios() {
    try {
        const response = await fetch('/api/desafios');
        const desafios = await response.json();

        listaDesafios.innerHTML = '';

        desafios.forEach(desafio => {
            const card = document.createElement('div');
            card.className = 'desafio-card';
            card.innerHTML = `
                <div class="desafio-header">
                    <h3>${desafio.titulo}</h3>
                    <span class="badge badge-${desafio.dificuldade}">${desafio.dificuldade}</span>
                </div>
                <div class="desafio-desc">${desafio.descricao}</div>
                <div class="desafio-xp">⭐ ${desafio.xp} XP</div>
                <button type="button" class="btn-desafio" onclick="abrirDesafio(${desafio.id})">Começar Desafio</button>
            `;
            listaDesafios.appendChild(card);
        });
    } catch (err) {
        mostrarFeedback('Erro ao carregar desafios. Tente novamente.', 'erro');
    }
}

function abrirDesafio(id) {
    fetch('/api/desafios')
        .then(res => res.json())
        .then(desafios => {
            desafioAtual = desafios.find(d => d.id === id);

            if (!desafioAtual) {
                mostrarFeedback('Desafio inválido.', 'erro');
                return;
            }

            document.getElementById('tituloDesafio').textContent = desafioAtual.titulo;
            document.getElementById('descDesafio').textContent = desafioAtual.descricao;

            desafiosSection.classList.add('visually-hidden');
            editorSection.classList.remove('visually-hidden');
            configurarDragAndDrop();
        })
        .catch(() => mostrarFeedback('Erro ao carregar desafio.', 'erro'));
}

function voltarDesafios() {
    desafiosSection.classList.remove('visually-hidden');
    medalhasSection.classList.add('visually-hidden');
    rankingSection.classList.add('visually-hidden');
    editorSection.classList.add('visually-hidden');
    limparCodigo();
    mostrarAba('desafios');
}

function configurarDragAndDrop() {
    const blocos = document.querySelectorAll('.blocos-paleta .bloco');

    blocos.forEach(bloco => {
        bloco.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', bloco.textContent.trim());
            e.dataTransfer.setData('tipo', bloco.dataset.tipo);
            e.dataTransfer.setData('cor', bloco.style.background || '#667eea');
        });
    });

    areaTrabalho.addEventListener('dragover', (e) => {
        e.preventDefault();
        areaTrabalho.classList.add('hovered');
    });

    areaTrabalho.addEventListener('dragleave', () => {
        areaTrabalho.classList.remove('hovered');
    });

    areaTrabalho.addEventListener('drop', (e) => {
        e.preventDefault();
        areaTrabalho.classList.remove('hovered');

        const texto = e.dataTransfer.getData('text/plain');
        const tipo = e.dataTransfer.getData('tipo');
        const cor = e.dataTransfer.getData('cor');

        const mensagemInicial = areaTrabalho.querySelector('p');
        if (mensagemInicial) {
            mensagemInicial.remove();
        }

        const blocoNovo = document.createElement('div');
        blocoNovo.className = 'bloco bloco-trabalho';
        blocoNovo.textContent = texto;
        blocoNovo.style.background = cor;
        blocoNovo.dataset.tipo = tipo;

        const btnRemover = document.createElement('button');
        btnRemover.type = 'button';
        btnRemover.className = 'btn-remover-bloco';
        btnRemover.textContent = 'Remover';
        btnRemover.addEventListener('click', () => {
            const blocosAtuais = Array.from(areaTrabalho.querySelectorAll('.bloco-trabalho'));
            const index = blocosAtuais.indexOf(blocoNovo);
            if (index !== -1) {
                blocosArrastados.splice(index, 1);
            }
            blocoNovo.remove();
            if (!areaTrabalho.querySelector('.bloco-trabalho')) {
                areaTrabalho.innerHTML = '<p>Arraste os blocos aqui para criar seu algoritmo</p>';
            }
        });

        blocoNovo.appendChild(btnRemover);
        blocosArrastados.push({ texto, tipo });
        areaTrabalho.appendChild(blocoNovo);
    });
}

function executarCodigo() {
    if (blocosArrastados.length === 0) {
        mostrarFeedback('Adicione blocos antes de executar!', 'erro');
        return;
    }

    let valido = false;
    let mensagem = '';

    if (desafioAtual.id === 1) {
        const temMovimento = blocosArrastados.some(b => b.tipo === 'mover');
        if (temMovimento) {
            valido = true;
            mensagem = 'Parabéns! Você moveu o personagem até a estrela!';
        } else {
            mensagem = 'Use blocos de movimento para avançar.';
        }
    } else if (desafioAtual.id === 2) {
        const temLoop = blocosArrastados.some(b => b.tipo === 'loop');
        const temMovimento = blocosArrastados.some(b => b.tipo === 'mover');
        if (temLoop && temMovimento) {
            valido = true;
            mensagem = 'Excelente! Você usou loops para resolver o labirinto!';
        } else if (!temLoop) {
            mensagem = 'Dica: use um loop para repetir movimentos.';
        } else {
            mensagem = 'Combine loops com movimentos para completar o labirinto.';
        }
    } else if (desafioAtual.id === 3) {
        const temLoop = blocosArrastados.some(b => b.tipo === 'loop');
        const temCondicional = blocosArrastados.some(b => b.tipo === 'condicional');
        if (temLoop && temCondicional && blocosArrastados.length >= 3) {
            valido = true;
            mensagem = 'Fantástico! Você dominou loops e condicionais!';
        } else if (!temLoop) {
            mensagem = 'Dica: use loops para organizar a quadrilha.';
        } else if (!temCondicional) {
            mensagem = 'Dica: use condicionais para tomar decisões.';
        } else {
            mensagem = 'Adicione mais blocos para uma solução completa.';
        }
    }

    mostrarFeedback(mensagem, valido ? 'sucesso' : 'aviso');

    if (valido) {
        setTimeout(concluirDesafio, 1200);
    }
}

function mostrarFeedback(mensagem, tipo) {
    feedbackArea.textContent = mensagem;
    feedbackArea.className = `feedback-area ${tipo}`;
}

async function concluirDesafio() {
    try {
        const response = await fetch('/api/concluir-desafio', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ alunoId: usuario.id, desafioId: desafioAtual.id })
        });

        const data = await response.json();

        if (data.sucesso) {
            usuario.xp = data.xpTotal;
            usuario.nivel = data.nivelAtual;
            nivelEl.textContent = usuario.nivel;
            xpTotalEl.textContent = usuario.xp;
            mostrarFeedback('Desafio concluído! XP ganho: ' + data.xpGanho, 'sucesso');
            limparCodigo();
            voltarDesafios();
        } else {
            mostrarFeedback('Erro ao salvar progresso. Tente novamente.', 'erro');
        }
    } catch (err) {
        mostrarFeedback('Erro ao conectar com o servidor.', 'erro');
    }
}

function limparCodigo() {
    areaTrabalho.innerHTML = '<p>Arraste os blocos aqui para criar seu algoritmo</p>';
    blocosArrastados = [];
}

async function logout() {
    await fetch('/api/logout', { method: 'POST' });
    localStorage.removeItem('computaplay-usuario');
    window.location.href = 'index.html';
}

function mostrarAba(aba) {
    desafiosSection.classList.add('visually-hidden');
    medalhasSection.classList.add('visually-hidden');
    rankingSection.classList.add('visually-hidden');

    tabButtons.forEach(btn => {
        const target = btn.getAttribute('data-target');
        const section = document.getElementById(target);
        const selected = btn.getAttribute('data-tab') === aba;
        btn.classList.toggle('aba-ativa', selected);
        btn.setAttribute('aria-selected', selected ? 'true' : 'false');
        if (selected) {
            section.classList.remove('visually-hidden');
            section.setAttribute('aria-hidden', 'false');
        } else {
            section.setAttribute('aria-hidden', 'true');
        }
    });

    if (aba === 'medalhas') {
        carregarMedalhas();
    } else if (aba === 'ranking') {
        carregarRanking();
    }
}

async function carregarMedalhas() {
    try {
        const response = await fetch(`/api/aluno/${usuario.id}/medalhas`);
        const data = await response.json();
        listaMedalhas.innerHTML = '';

        if (data.conquistadas.length > 0) {
            const titulo = document.createElement('h3');
            titulo.textContent = 'Conquistadas';
            listaMedalhas.appendChild(titulo);
            data.conquistadas.forEach(m => {
                const item = document.createElement('div');
                item.className = 'medalha-item conquistada';
                item.innerHTML = `
                    <div class="medalha-icone">${m.icone}</div>
                    <div class="medalha-nome">${m.nome}</div>
                `;
                listaMedalhas.appendChild(item);
            });
        }

        if (data.disponiveis.length > 0) {
            const titulo = document.createElement('h3');
            titulo.textContent = 'Disponíveis';
            titulo.style.marginTop = '20px';
            listaMedalhas.appendChild(titulo);
            data.disponiveis.forEach(m => {
                const item = document.createElement('div');
                item.className = 'medalha-item';
                item.innerHTML = `
                    <div class="medalha-icone" style="filter: grayscale(100%);">${m.icone}</div>
                    <div class="medalha-nome">${m.nome}</div>
                    <div class="medalha-requisito">${m.requisito}</div>
                `;
                listaMedalhas.appendChild(item);
            });
        }
    } catch (err) {
        mostrarFeedback('Erro ao carregar medalhas.', 'erro');
    }
}

async function carregarRanking() {
    try {
        const response = await fetch('/api/ranking/1');
        const ranking = await response.json();
        listaRanking.innerHTML = '';

        ranking.forEach((aluno, index) => {
            const item = document.createElement('div');
            item.className = 'ranking-item';
            if (aluno.id === usuario.id) {
                item.classList.add('ranking-atual');
            }
            item.innerHTML = `
                <div class="ranking-posicao">${index + 1}º</div>
                <div class="ranking-info">
                    <div class="ranking-nome">${aluno.nome}${aluno.id === usuario.id ? ' (Você)' : ''}</div>
                    <div class="ranking-nivel">Nível ${aluno.nivel}</div>
                </div>
                <div class="ranking-xp">${aluno.xp} XP</div>
            `;
            listaRanking.appendChild(item);
        });
    } catch (err) {
        mostrarFeedback('Erro ao carregar ranking.', 'erro');
    }
}
