# 2.1 LEVANTAMENTO E ANÁLISE DE REQUISITOS

## 2.1.1 REQUISITOS FUNCIONAIS

Os requisitos funcionais descrevem as funcionalidades que o sistema deve oferecer para atender às necessidades dos usuários.

### MÓDULO DO ALUNO

#### RF01 - Cadastro e Autenticação de Aluno
**Descrição**: O sistema deve permitir que alunos se cadastrem e façam login na plataforma.
**Prioridade**: Alta
**Entradas**: Nome completo, e-mail/usuário, senha, código da turma
**Saídas**: Confirmação de cadastro, acesso ao sistema
**Regras**: Senhas devem ter no mínimo 6 caracteres; código da turma deve ser válido

#### RF02 - Criação e Customização de Avatar
**Descrição**: O sistema deve permitir que o aluno crie e personalize seu avatar.
**Prioridade**: Média
**Entradas**: Escolhas de características (cor de pele, cabelo, roupa, acessórios)
**Saídas**: Avatar personalizado salvo
**Regras**: Opções devem ser inclusivas e representativas; novas opções desbloqueadas por progresso

#### RF03 - Acesso a Trilha de Aprendizagem
**Descrição**: O sistema deve apresentar uma trilha de aprendizagem progressiva com desafios de pensamento computacional.
**Prioridade**: Alta
**Entradas**: Nível atual do aluno
**Saídas**: Lista de desafios disponíveis, bloqueados e concluídos
**Regras**: Desafios desbloqueiam sequencialmente; aluno pode revisitar desafios concluídos

#### RF04 - Editor de Lógica Visual (Blocos)
**Descrição**: O sistema deve oferecer um editor de programação em blocos para resolução de desafios.
**Prioridade**: Alta
**Entradas**: Arrastar e soltar blocos de comandos (movimento, loops, condicionais, variáveis)
**Saídas**: Código em blocos, execução visual do algoritmo
**Regras**: Blocos devem se encaixar apenas se sintaxe válida; feedback visual imediato

#### RF05 - Execução e Visualização de Algoritmos
**Descrição**: O sistema deve executar o código em blocos criado pelo aluno e mostrar resultado visual.
**Prioridade**: Alta
**Entradas**: Código em blocos
**Saídas**: Animação da execução, indicação de sucesso/falha
**Regras**: Execução deve ser passo a passo; aluno pode pausar/reiniciar

#### RF06 - Sistema de Feedback e Dicas
**Descrição**: O sistema deve fornecer feedback sobre erros e dicas contextuais quando aluno está travado.
**Prioridade**: Alta
**Entradas**: Tentativas do aluno, tempo em um desafio
**Saídas**: Mensagens de erro específicas, dicas progressivas
**Regras**: Dicas devem ser graduais (não entregar resposta); após 3 tentativas erradas, oferecer ajuda

#### RF07 - Sistema de Pontuação (XP)
**Descrição**: O sistema deve atribuir pontos de experiência (XP) por desafios concluídos.
**Prioridade**: Média
**Entradas**: Conclusão de desafios, tempo gasto, eficiência da solução
**Saídas**: XP ganho, XP total acumulado
**Regras**: XP varia conforme dificuldade; soluções otimizadas dão bônus

#### RF08 - Sistema de Medalhas (Badges)
**Descrição**: O sistema deve conceder medalhas por conquistas específicas.
**Prioridade**: Média
**Entradas**: Ações do aluno (concluir 10 desafios, ajudar colega, usar loop pela primeira vez)
**Saídas**: Medalha desbloqueada, notificação
**Regras**: Medalhas são permanentes; lista de medalhas disponíveis deve ser visível

#### RF09 - Progressão de Níveis
**Descrição**: O sistema deve implementar sistema de níveis que aumentam conforme XP acumulado.
**Prioridade**: Média
**Entradas**: XP total
**Saídas**: Nível atual, progresso para próximo nível
**Regras**: Cada nível requer mais XP que o anterior; níveis desbloqueiam novos blocos e desafios

#### RF10 - Ranking Colaborativo
**Descrição**: O sistema deve exibir ranking que valorize colaboração além de desempenho individual.
**Prioridade**: Baixa
**Entradas**: XP, medalhas de ajuda, participação em desafios em equipe
**Saídas**: Posição no ranking, pontuação colaborativa
**Regras**: Pontuação considera XP individual (60%) + colaboração (40%)

#### RF11 - Desafios em Equipe
**Descrição**: O sistema deve permitir que alunos resolvam desafios colaborativamente.
**Prioridade**: Baixa
**Entradas**: Código criado por múltiplos alunos
**Saídas**: Solução colaborativa, XP distribuído entre participantes
**Regras**: Cada aluno contribui com parte do código; todos recebem XP se bem-sucedidos

#### RF12 - Histórico de Progresso
**Descrição**: O sistema deve manter histórico completo do progresso do aluno.
**Prioridade**: Média
**Entradas**: Todas as ações do aluno
**Saídas**: Gráficos de evolução, desafios concluídos, tempo gasto
**Regras**: Dados devem ser persistentes; aluno pode visualizar seu histórico

#### RF13 - Narrativa Contextualizada
**Descrição**: O sistema deve apresentar narrativa envolvente com elementos culturais paraibanos.
**Prioridade**: Média
**Entradas**: Progressão do aluno na história
**Saídas**: Textos narrativos, personagens, missões temáticas
**Regras**: Narrativa avança conforme progresso; elementos culturais (festas juninas, cordel, etc.)

### MÓDULO DO PROFESSOR

#### RF14 - Cadastro e Autenticação de Professor
**Descrição**: O sistema deve permitir que professores se cadastrem e façam login.
**Prioridade**: Alta
**Entradas**: Nome, e-mail, senha, documento de identificação
**Saídas**: Confirmação de cadastro, acesso à área do professor
**Regras**: Cadastro pode requerer aprovação de administrador

#### RF15 - Criação e Gestão de Turmas
**Descrição**: O sistema deve permitir que professor crie turmas e gere códigos de acesso.
**Prioridade**: Alta
**Entradas**: Nome da turma, ano escolar, escola
**Saídas**: Código único da turma, lista de alunos
**Regras**: Código deve ser único e fácil de digitar; professor pode ter múltiplas turmas

#### RF16 - Convite de Alunos
**Descrição**: O sistema deve gerar código de turma que alunos usam para se inscrever.
**Prioridade**: Alta
**Entradas**: Solicitação de código
**Saídas**: Código alfanumérico de 6 caracteres
**Regras**: Código expira se não usado em 30 dias; pode ser regenerado

#### RF17 - Dashboard de Acompanhamento
**Descrição**: O sistema deve exibir painel com visão geral do desempenho da turma.
**Prioridade**: Alta
**Entradas**: Dados de progresso dos alunos
**Saídas**: Gráficos, indicadores, alertas
**Regras**: Atualização em tempo real; filtros por aluno, período, tipo de desafio

#### RF18 - Identificação de Dificuldades
**Descrição**: O sistema deve identificar automaticamente alunos com dificuldades recorrentes.
**Prioridade**: Alta
**Entradas**: Tentativas erradas, tempo gasto, desafios não concluídos
**Saídas**: Lista de alunos em risco, dificuldades específicas identificadas
**Regras**: Alertas após 3 desafios consecutivos com muitas tentativas; sugestões de intervenção

#### RF19 - Relatórios de Desempenho
**Descrição**: O sistema deve gerar relatórios exportáveis de desempenho individual e da turma.
**Prioridade**: Média
**Entradas**: Período, alunos selecionados, métricas
**Saídas**: Relatório em PDF ou CSV
**Regras**: Relatórios incluem: desafios concluídos, XP, tempo médio, medalhas, competências BNCC atingidas

#### RF20 - Banco de Atividades Desplugadas
**Descrição**: O sistema deve oferecer repositório de atividades sem computador para complementar ensino.
**Prioridade**: Média
**Entradas**: Filtros (tema, ano escolar, duração)
**Saídas**: Lista de atividades com instruções detalhadas
**Regras**: Atividades alinhadas aos conceitos ensinados online; materiais de baixo custo

#### RF21 - Planos de Aula Prontos
**Descrição**: O sistema deve fornecer planos de aula estruturados e customizáveis.
**Prioridade**: Média
**Entradas**: Ano escolar, conceito a ensinar
**Saídas**: Plano de aula completo (objetivos, atividades, avaliação)
**Regras**: Alinhados à BNCC; professor pode editar e salvar versões personalizadas

#### RF22 - Atribuição de Desafios Específicos
**Descrição**: O sistema deve permitir que professor atribua desafios extras ou remediais a alunos específicos.
**Prioridade**: Baixa
**Entradas**: Alunos selecionados, desafio escolhido, prazo
**Saídas**: Notificação para alunos, tarefa visível na trilha
**Regras**: Professor pode acompanhar conclusão; desafios atribuídos têm prioridade visual

#### RF23 - Comunicação com Alunos
**Descrição**: O sistema deve permitir envio de mensagens/avisos para alunos ou turma.
**Prioridade**: Baixa
**Entradas**: Destinatários, mensagem
**Saídas**: Notificação para alunos
**Regras**: Mensagens ficam salvas; alunos veem ao fazer login

### MÓDULO ADMINISTRATIVO

#### RF24 - Gestão de Conteúdo de Desafios
**Descrição**: Administradores devem poder criar, editar e excluir desafios.
**Prioridade**: Alta
**Entradas**: Título, descrição, blocos disponíveis, solução esperada, dificuldade
**Saídas**: Desafio publicado ou salvo como rascunho
**Regras**: Desafios devem ter tags de competências BNCC; testados antes de publicação

#### RF25 - Moderação e Suporte
**Descrição**: Administradores devem poder visualizar logs, resolver problemas e moderar conteúdo.
**Prioridade**: Média
**Entradas**: Logs do sistema, relatórios de erro
**Saídas**: Ações de moderação, suporte técnico
**Regras**: Logs devem ser anônimos (LGPD); acesso restrito

### RECURSOS DE ACESSIBILIDADE

#### RF26 - Compatibilidade com Leitores de Tela
**Descrição**: Toda a interface deve ser navegável e compreensível via leitores de tela.
**Prioridade**: Alta
**Entradas**: Comandos de leitor de tela (NVDA, JAWS, TalkBack)
**Saídas**: Leitura correta de todos os elementos
**Regras**: ARIA labels em todos os elementos interativos; ordem de foco lógica

#### RF27 - Navegação via Teclado
**Descrição**: Todas as funcionalidades devem ser acessíveis apenas com teclado.
**Prioridade**: Alta
**Entradas**: Teclas Tab, Enter, Setas, Esc
**Saídas**: Navegação completa sem mouse
**Regras**: Indicador visual de foco; atalhos documentados

#### RF28 - Personalização Visual
**Descrição**: O sistema deve permitir ajustes de contraste, tamanho de fonte e cores.
**Prioridade**: Alta
**Entradas**: Preferências do usuário
**Saídas**: Interface ajustada conforme escolhas
**Regras**: Pelo menos 3 temas (claro, escuro, alto contraste); tamanhos de fonte: pequeno, médio, grande, extra grande

#### RF29 - Legendas e Transcrições
**Descrição**: Conteúdos audiovisuais devem ter legendas e transcrições.
**Prioridade**: Média
**Entradas**: Vídeos e áudios do sistema
**Saídas**: Legendas sincronizadas, transcrições em texto
**Regras**: Legendas ocultas por padrão, ativáveis pelo usuário

#### RF30 - Feedback Multimodal
**Descrição**: Feedback deve ser fornecido em múltiplas modalidades (visual, sonoro, textual).
**Prioridade**: Média
**Entradas**: Ações do usuário
**Saídas**: Confirmações visuais, sonoras e textuais
**Regras**: Usuário pode desativar feedback sonoro; nunca depender apenas de cor para informação crítica

---

## 2.1.2 REQUISITOS NÃO FUNCIONAIS

Os requisitos não funcionais especificam critérios de qualidade e restrições do sistema.

### DESEMPENHO

#### RNF01 - Tempo de Carregamento
**Descrição**: Páginas principais devem carregar em no máximo 3 segundos em conexão 3G.
**Categoria**: Desempenho
**Métrica**: Tempo até First Contentful Paint (FCP) < 3s

#### RNF02 - Responsividade da Interface
**Descrição**: Interações do usuário devem ter resposta visual em menos de 100ms.
**Categoria**: Desempenho
**Métrica**: Latência de interação < 100ms

#### RNF03 - Execução de Código em Blocos
**Descrição**: Algoritmos devem executar em menos de 2 segundos, mesmo com loops complexos.
**Categoria**: Desempenho
**Métrica**: Tempo de execução < 2s para algoritmos padrão

#### RNF04 - Suporte a Concorrência
**Descrição**: O sistema deve suportar pelo menos 500 usuários simultâneos sem degradação.
**Categoria**: Desempenho
**Métrica**: 500 usuários simultâneos com tempo de resposta < 3s

### USABILIDADE

#### RNF05 - Facilidade de Aprendizado
**Descrição**: Alunos devem conseguir completar primeiro desafio em menos de 5 minutos sem ajuda.
**Categoria**: Usabilidade
**Métrica**: 80% dos alunos concluem tutorial inicial em < 5 min

#### RNF06 - Interface Intuitiva para Professores
**Descrição**: Professores devem criar uma turma e convidar alunos em menos de 3 minutos.
**Categoria**: Usabilidade
**Métrica**: 90% dos professores concluem setup inicial em < 3 min

#### RNF07 - Consistência de Design
**Descrição**: Interface deve seguir padrões consistentes de cores, tipografia e layout.
**Categoria**: Usabilidade
**Métrica**: Design system documentado e aplicado em 100% das telas

### ACESSIBILIDADE

#### RNF08 - Conformidade WCAG 2.1 Nível AA
**Descrição**: Plataforma deve atender todos os critérios WCAG 2.1 Nível AA.
**Categoria**: Acessibilidade
**Métrica**: 100% de conformidade em auditoria automatizada (WAVE, axe) e manual

#### RNF09 - Contraste de Cores
**Descrição**: Contraste mínimo de 4.5:1 para texto normal e 3:1 para texto grande.
**Categoria**: Acessibilidade
**Métrica**: Contraste verificado em todas as combinações de cores

#### RNF10 - Suporte a Tecnologias Assistivas
**Descrição**: Compatibilidade total com NVDA, JAWS (Windows), VoiceOver (Mac/iOS), TalkBack (Android).
**Categoria**: Acessibilidade
**Métrica**: Testes manuais com leitores de tela sem bloqueios críticos

### COMPATIBILIDADE

#### RNF11 - Compatibilidade com Navegadores
**Descrição**: Funcionamento pleno em Chrome, Firefox, Edge, Safari (últimas 2 versões).
**Categoria**: Compatibilidade
**Métrica**: 100% das funcionalidades operacionais nos navegadores listados

#### RNF12 - Responsividade de Dispositivos
**Descrição**: Interface adaptável para desktops, tablets (7" e 10") e smartphones (>5").
**Categoria**: Compatibilidade
**Métrica**: Layout responsivo testado em resoluções de 320px a 1920px

#### RNF13 - Requisitos Mínimos de Hardware
**Descrição**: Funcionamento em dispositivos com 2GB RAM, processador dual-core 1.5GHz.
**Categoria**: Compatibilidade
**Métrica**: Performance aceitável em dispositivos de referência (Chromebook básico)

### SEGURANÇA

#### RNF14 - Proteção de Dados Pessoais (LGPD)
**Descrição**: Conformidade total com Lei Geral de Proteção de Dados.
**Categoria**: Segurança
**Métrica**: Política de privacidade, termos de uso, consentimento explícito, direito ao esquecimento

#### RNF15 - Autenticação Segura
**Descrição**: Senhas devem ser armazenadas com hash bcrypt (cost factor ≥ 12).
**Categoria**: Segurança
**Métrica**: 0 senhas em texto plano no banco de dados

#### RNF16 - Proteção contra Vulnerabilidades
**Descrição**: Sistema deve estar protegido contra OWASP Top 10 (XSS, SQL Injection, CSRF).
**Categoria**: Segurança
**Métrica**: Scan de segurança automatizado sem vulnerabilidades críticas/altas

#### RNF17 - Controle de Acesso
**Descrição**: Professores só acessam dados de suas turmas; alunos só veem próprios dados.
**Categoria**: Segurança
**Métrica**: Testes de autorização sem vazamento de dados entre usuários

### CONFIABILIDADE

#### RNF18 - Disponibilidade
**Descrição**: Sistema deve estar disponível 99% do tempo (excluindo manutenções programadas).
**Categoria**: Confiabilidade
**Métrica**: Uptime ≥ 99% medido mensalmente

#### RNF19 - Backup de Dados
**Descrição**: Backup automático diário de todos os dados com retenção de 30 dias.
**Categoria**: Confiabilidade
**Métrica**: Backups automáticos diários, recuperação testada mensalmente

#### RNF20 - Recuperação de Erros
**Descrição**: Sistema deve se recuperar graciosamente de erros sem perda de progresso do aluno.
**Categoria**: Confiabilidade
**Métrica**: Salvamento automático a cada ação; mensagens de erro claras

### MANUTENIBILIDADE

#### RNF21 - Código Documentado
**Descrição**: Código-fonte deve ter documentação inline e README detalhado.
**Categoria**: Manutenibilidade
**Métrica**: Funções críticas com JSDoc/comentários; README com instruções de setup

#### RNF22 - Testes Automatizados
**Descrição**: Cobertura de testes de pelo menos 70% do código.
**Categoria**: Manutenibilidade
**Métrica**: Cobertura de testes ≥ 70% (unitários + integração)

#### RNF23 - Padrões de Código
**Descrição**: Código deve seguir style guide consistente (ESLint, Prettier).
**Categoria**: Manutenibilidade
**Métrica**: 0 violações de linting em build de produção

### ESCALABILIDADE

#### RNF24 - Arquitetura Escalável
**Descrição**: Arquitetura deve permitir escalar horizontalmente conforme aumento de usuários.
**Categoria**: Escalabilidade
**Métrica**: Arquitetura stateless; uso de cache distribuído; balanceamento de carga

#### RNF25 - Banco de Dados Otimizado
**Descrição**: Consultas ao banco devem ser otimizadas com índices apropriados.
**Categoria**: Escalabilidade
**Métrica**: Queries principais < 100ms; índices em chaves de busca frequentes

### PORTABILIDADE

#### RNF26 - Modo Offline Parcial
**Descrição**: Alunos devem poder trabalhar em desafios sem internet (sincronização posterior).
**Categoria**: Portabilidade
**Métrica**: Service Workers para cache; sincronização ao reconectar

#### RNF27 - Exportação de Dados
**Descrição**: Professores devem poder exportar todos os dados de suas turmas.
**Categoria**: Portabilidade
**Métrica**: Exportação em formatos abertos (JSON, CSV)

### LOCALIZAÇÃO

#### RNF28 - Idioma Português Brasileiro
**Descrição**: Toda interface, mensagens e conteúdo devem estar em português brasileiro claro.
**Categoria**: Localização
**Métrica**: 100% do conteúdo em PT-BR; linguagem adequada à faixa etária

#### RNF29 - Contextualização Cultural
**Descrição**: Exemplos, narrativas e referências devem incluir cultura paraibana/nordestina.
**Categoria**: Localização
**Métrica**: Pelo menos 50% dos desafios com elementos culturais regionais

### LEGAL E REGULATÓRIO

#### RNF30 - Alinhamento com BNCC
**Descrição**: Todos os desafios devem estar mapeados para competências específicas da BNCC.
**Categoria**: Legal/Regulatório
**Métrica**: 100% dos desafios com tags de habilidades BNCC; documento de mapeamento completo

#### RNF31 - Acessibilidade Educacional (Lei 13.146/2015)
**Descrição**: Conformidade com Lei Brasileira de Inclusão da Pessoa com Deficiência.
**Categoria**: Legal/Regulatório
**Métrica**: Recursos de acessibilidade atendem à legislação; validação com usuários PcD

---

## Matriz de Rastreabilidade

| Requisito Funcional | Requisitos Não Funcionais Relacionados | Prioridade |
|---------------------|---------------------------------------|------------|
| RF01 - RF14 | RNF14, RNF15, RNF16, RNF17 | Alta |
| RF04 - RF05 | RNF01, RNF02, RNF03, RNF11, RNF13 | Alta |
| RF26 - RF30 | RNF08, RNF09, RNF10, RNF31 | Alta |
| RF17 - RF18 | RNF01, RNF04, RNF24, RNF25 | Alta |
| RF19 - RF21 | RNF27, RNF30 | Média |

---

## Priorização (MoSCoW)

### Must Have (Deve ter)
- RF01, RF03, RF04, RF05, RF06, RF14, RF15, RF17, RF18, RF24, RF26, RF27, RF28
- RNF01, RNF08, RNF11, RNF14, RNF15, RNF18, RNF30

### Should Have (Deveria ter)
- RF02, RF07, RF08, RF09, RF12, RF16, RF19, RF20, RF21, RF29, RF30
- RNF04, RNF05, RNF06, RNF10, RNF16, RNF24

### Could Have (Poderia ter)
- RF10, RF11, RF13, RF22, RF23, RF25
- RNF20, RNF22, RNF26, RNF27

### Won't Have (Não terá nesta versão)
- Suporte a múltiplos idiomas além de PT-BR
- Integração com redes sociais externas
- Aplicativo mobile nativo (apenas PWA)
