let usuario = null;

const nomeProfessorEl = document.getElementById('nomeProfessor');
const nomeTurmaEl = document.getElementById('nomeTurma');
const codigoTurmaEl = document.getElementById('codigoTurma');
const listaAlunosEl = document.getElementById('listaAlunos');
const totalAlunosEl = document.getElementById('totalAlunos');
const xpMedioEl = document.getElementById('xpMedio');
const nivelMedioEl = document.getElementById('nivelMedio');

window.addEventListener('DOMContentLoaded', () => {
    initProfessor();
});

async function initProfessor() {
    try {
        const response = await fetch('/api/autenticado');
        if (!response.ok) {
            window.location.href = 'index.html';
            return;
        }

        const data = await response.json();
        usuario = data.usuario;

        if (usuario.tipo !== 'professor') {
            window.location.href = 'index.html';
            return;
        }

        nomeProfessorEl.textContent = usuario.nome;
        carregarTurma(1);
    } catch (err) {
        window.location.href = 'index.html';
    }
}

async function carregarTurma(turmaId) {
    try {
        const response = await fetch(`/api/professor/turma/${turmaId}`);
        const data = await response.json();

        if (data.erro) {
            alert('Erro ao carregar turma.');
            return;
        }

        nomeTurmaEl.textContent = data.turma.nome;
        codigoTurmaEl.textContent = data.turma.codigo;
        renderizarAlunos(data.alunos);
        calcularEstatisticas(data.alunos);
    } catch (err) {
        alert('Erro ao carregar dados da turma.');
    }
}

function renderizarAlunos(alunos) {
    listaAlunosEl.innerHTML = '';

    if (alunos.length === 0) {
        listaAlunosEl.innerHTML = '<p class="nenhum-aluno">Nenhum aluno cadastrado ainda.</p>';
        return;
    }

    alunos.forEach(aluno => {
        const item = document.createElement('div');
        item.className = 'aluno-item';
        item.innerHTML = `
            <div class="aluno-nome">👤 ${aluno.nome}</div>
            <div class="aluno-stats">
                <div><span>Nível:</span> <strong>${aluno.nivel}</strong></div>
                <div><span>XP:</span> <strong>${aluno.xp}</strong></div>
            </div>
        `;
        listaAlunosEl.appendChild(item);
    });
}

function calcularEstatisticas(alunos) {
    const total = alunos.length;
    const xpTotal = alunos.reduce((soma, aluno) => soma + (aluno.xp || 0), 0);
    const nivelTotal = alunos.reduce((soma, aluno) => soma + (aluno.nivel || 1), 0);
    totalAlunosEl.textContent = total;
    xpMedioEl.textContent = total ? Math.round(xpTotal / total) : 0;
    nivelMedioEl.textContent = total ? (nivelTotal / total).toFixed(1) : '0.0';
}

async function logout() {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = 'index.html';
}
