# 5.3 DESCRIÇÃO DOS MÓDULOS E FUNCIONALIDADES

## Visão Geral

A plataforma ComputaPlay é organizada em módulos funcionais que agrupam features relacionadas. Esta seção detalha cada módulo e suas funcionalidades principais.

---

## MÓDULO 1: Autenticação e Gerenciamento de Usuários

### Responsabilidades:
- Cadastro e login de usuários
- Gerenciamento de sessões
- Recuperação de senha
- Controle de acesso (RBAC - Role-Based Access Control)

### Funcionalidades Detalhadas:

#### 1.1 Cadastro de Aluno
- Formulário com campos: nome, usuário, senha, código da turma
- Validação do código de turma em tempo real
- Criação automática de avatar padrão
- Envio de email de confirmação (opcional)

#### 1.2 Cadastro de Professor
- Formulário estendido com: instituição, documento
- Aprovação manual por administrador (opcional)

#### 1.3 Login
- Autenticação via email/usuário + senha
- Geração de JWT (access + refresh token)
- "Lembrar-me" com sessão estendida

#### 1.4 Recuperação de Senha
- Envio de token por email
- Link temporário (válido por 1 hora)
- Redefinição segura

---

## MÓDULO 2: Editor de Programação em Blocos

### Responsabilidades:
- Interface visual drag-and-drop
- Interpretação e execução de código em blocos
- Validação de sintaxe
- Visualização animada da execução

### Funcionalidades Detalhadas:

#### 2.1 Paleta de Blocos
Blocos organizados em categorias:
- **Movimento**: Mover direita/esquerda/cima/baixo, girar
- **Loops**: Repetir N vezes, Enquanto condição
- **Condicionais**: Se/então, Se/senão
- **Variáveis**: Criar, definir, incrementar
- **Funções**: Criar função personalizada

#### 2.2 Área de Trabalho
- Arrastar blocos da paleta
- Encaixar blocos (validação visual)
- Blocos aninhados (loops dentro de loops)
- Colorização por tipo
- Zoom in/out

#### 2.3 Execução
- Interpretador de blocos → código JavaScript interno
- Execução passo a passo com animação
- Controles: Play, Pause, Stop, Velocidade
- Breakpoints (para debug)

#### 2.4 Validação
- Verificação em tempo real de encaixe
- Detecção de loops infinitos (timeout 2s)
- Comparação com solução esperada
- Feedback específico sobre erros

---

## MÓDULO 3: Sistema de Desafios

### Responsabilidades:
- Gerenciamento de desafios
- Progressão sequencial
- Contextualização narrativa

### Funcionalidades Detalhadas:

#### 3.1 Catálogo de Desafios
- Trilha de aprendizagem estruturada por nível
- Desafios organizados por conceito (decomposição, padrões, algoritmos)
- Filtros: dificuldade, ano escolar, tema
- Preview do desafio antes de iniciar

#### 3.2 Estrutura de um Desafio
- **Título e Descrição**: Contexto do problema
- **Objetivo**: Meta clara a ser atingida
- **Cenário Visual**: Personagens, obstáculos, itens a coletar
- **Blocos Disponíveis**: Subconjunto de blocos permitidos
- **Dicas Graduais**: 3 níveis de ajuda
- **Solução Esperada**: Múltiplas soluções aceitas

#### 3.3 Narrativa Contextualizada
- História contínua ao longo dos desafios
- Personagens recorrentes (ex: João e Maria, guias do aluno)
- Missões temáticas (Festival Junino, Expedição ao Sertão, etc.)
- Elementos culturais paraibanos integrados

---

## MÓDULO 4: Gamificação

### Responsabilidades:
- Sistema de XP e níveis
- Medalhas e conquistas
- Rankings
- Customização de avatar

### Funcionalidades Detalhadas:

#### 4.1 Pontos de Experiência (XP)
- XP base por desafio (varia com dificuldade)
- Bônus de eficiência (menos blocos = mais XP)
- Bônus de velocidade (tempo abaixo da média)
- Penalidade por dicas (mínimo 50% do XP base)

#### 4.2 Sistema de Níveis
- Progressão exponencial (níveis iniciais rápidos)
- Desbloqueio de itens de avatar
- Desbloqueio de blocos avançados
- Feedback visual ao subir de nível

#### 4.3 Medalhas
**Categorias**:
- **Progresso**: Primeira Vitória, Desbravador, Maratonista, Mestre
- **Maestria**: Mestre do Loop, Lógico, Eficiente, Depurador
- **Colaboração**: Ajudante, Mentor, Trabalho em Equipe
- **Especiais**: Persistente, Cultural, Explorador

**Mecânica**:
- Verificação automática de critérios após cada ação
- Animação de "conquista" ao desbloquear
- Galeria de medalhas (conquistadas + bloqueadas)

#### 4.4 Ranking Colaborativo
- Pontuação: 60% XP + 30% colaboração + 10% medalhas especiais
- Top 10 + posição do aluno atual
- Anonimização de últimas posições
- Atualização em tempo real

#### 4.5 Customização de Avatar
- Itens iniciais gratuitos
- Novos itens desbloqueados por níveis
- Itens exclusivos por medalhas especiais
- Categorias: Pele, cabelo, roupa, acessórios
- Preview em tempo real

---

## MÓDULO 5: Dashboard do Professor

### Responsabilidades:
- Acompanhamento de turmas
- Identificação de dificuldades
- Geração de relatórios
- Gestão de alunos

### Funcionalidades Detalhadas:

#### 5.1 Visão Geral de Turmas
- Cards de cada turma com resumo:
  - Número de alunos
  - Média de progresso
  - Alertas ativos (🟢 🟡 🔴)
- Acesso rápido ao dashboard detalhado

#### 5.2 Dashboard Detalhado da Turma
- **Gráficos**:
  - Progresso médio da turma ao longo do tempo
  - Distribuição de desafios concluídos
  - Tempo médio por desafio
- **Lista de Alunos**:
  - Barra de progresso individual
  - XP acumulado
  - Última atividade
  - Status (ativo, atenção, urgente)
- **Filtros**:
  - Por período (última semana, mês, todo o tempo)
  - Por status (todos, com dificuldades, inativos)

#### 5.3 Perfil Individual do Aluno
- Histórico completo de desafios
- Gráfico de evolução de XP
- Medalhas conquistadas
- Tempo médio por desafio
- Conceitos com dificuldade
- Sugestões de intervenção

#### 5.4 Sistema de Alertas
- **Critérios de Geração**:
  - 3+ tentativas erradas em 3 desafios consecutivos
  - Tempo 50% acima da média da turma
  - 0 desafios concluídos em 7 dias (aluno ativo)
- **Severidade**:
  - 🟡 Atenção: 1 critério atendido
  - 🔴 Urgente: 2+ critérios atendidos
- **Informações do Alerta**:
  - Aluno afetado
  - Conceito específico com dificuldade
  - Sugestões de atividades remediais
  - Data de geração

#### 5.5 Geração de Relatórios
- **Tipos**:
  - Individual (1 aluno)
  - Turma completa
- **Conteúdo**:
  - Desafios concluídos
  - XP total e médio
  - Tempo total e médio
  - Medalhas conquistadas
  - Competências BNCC atingidas
  - Gráficos visuais
- **Formatos**:
  - PDF (visual, para apresentação)
  - CSV (dados, para análise)
- **Período Customizável**

---

## MÓDULO 6: Recursos Pedagógicos

### Responsabilidades:
- Planos de aula prontos
- Atividades desplugadas
- Materiais complementares

### Funcionalidades Detalhadas:

#### 6.1 Biblioteca de Planos de Aula
- **Organização**:
  - Por ano escolar (6º, 7º, 8º, 9º)
  - Por conceito (decomposição, padrões, abstração, algoritmos)
  - Por duração (1 aula, 2 aulas, sequência didática)
- **Conteúdo de cada Plano**:
  - Objetivos de aprendizagem
  - Competências BNCC atendidas
  - Tempo estimado
  - Materiais necessários
  - Passo a passo detalhado
  - Sugestões de avaliação
  - Atividades complementares (online e desplugadas)
- **Funcionalidades**:
  - Visualização completa
  - Edição e salvamento de versão personalizada
  - Exportação em PDF
  - Impressão

#### 6.2 Banco de Atividades Desplugadas
- **Organização**:
  - Por conceito
  - Por materiais necessários (baixo custo, sem materiais, etc.)
  - Por duração (15min, 30min, 1h)
- **Conteúdo de cada Atividade**:
  - Título e conceito trabalhado
  - Duração estimada
  - Lista de materiais
  - Instruções detalhadas
  - Variações da atividade
  - Avaliação sugerida
  - Fotos/ilustrações (quando aplicável)
- **Funcionalidades**:
  - Busca e filtros
  - Visualização completa
  - Download em PDF
  - Impressão

---

## MÓDULO 7: Colaboração e Comunicação

### Responsabilidades:
- Desafios em equipe
- Ajuda entre colegas
- Notificações
- Chat (moderado)

### Funcionalidades Detalhadas:

#### 7.1 Desafios Colaborativos
- Professor cria grupos de 2-4 alunos
- Código sincronizado em tempo real (WebSocket)
- Cada aluno contribui com parte do código
- Todos recebem XP se bem-sucedidos
- Histórico de contribuições

#### 7.2 Ajuda entre Colegas
- Aluno solicita ajuda clicando em "Pedir Ajuda a Colega"
- Sistema sugere colegas elegíveis:
  - Online no momento
  - Já resolveram este desafio
  - Mesma turma
- Colega pode aceitar ou recusar
- Chat temporário durante a ajuda
- Ajudante recebe XP bônus (+15 XP)
- Contribui para medalha "Mentor"

#### 7.3 Sistema de Notificações
- **Para Alunos**:
  - Nova medalha desbloqueada
  - Subiu de nível
  - Colega pediu ajuda
  - Atribuição de tarefa pelo professor
- **Para Professores**:
  - Novo alerta de dificuldade
  - Aluno inativo há 7 dias
  - Relatório pronto para download
- **Tipos**:
  - Push notifications (web)
  - Email (configurável)
  - In-app (sino no topo da tela)

---

## MÓDULO 8: Acessibilidade

### Responsabilidades:
- Configurações de acessibilidade
- Compatibilidade com tecnologias assistivas
- Personalização visual

### Funcionalidades Detalhadas:

#### 8.1 Menu de Acessibilidade
- Tamanho de fonte: P, M, G, XG
- Temas: Claro, Escuro, Alto Contraste
- Ativar/desativar leitor de tela
- Ativar/desativar legendas
- Preferências de animação

#### 8.2 Navegação por Teclado
- Todos os elementos navegáveis via Tab
- Atalhos de teclado customizados
- Indicador visual de foco

#### 8.3 Leitores de Tela
- ARIA labels em todos os elementos
- Descrições textuais de blocos visuais
- Anúncios de mudanças dinâmicas

---

## MÓDULO 9: Administração

### Responsabilidades:
- Gestão de conteúdo (desafios, planos de aula)
- Moderação
- Logs e auditoria
- Configurações globais

### Funcionalidades Detalhadas:

#### 9.1 Gestão de Desafios
- CRUD completo de desafios
- Editor de blocos esperados (solução)
- Mapeamento de competências BNCC
- Teste de desafio antes de publicação
- Versionamento de desafios

#### 9.2 Gestão de Conteúdo Pedagógico
- CRUD de planos de aula
- CRUD de atividades desplugadas
- Upload de arquivos PDF

#### 9.3 Moderação
- Visualização de chats entre alunos
- Bloqueio de usuários (casos extremos)
- Revisão de conteúdo gerado por usuários

#### 9.4 Logs e Auditoria
- Logs de acesso
- Logs de erros
- Logs de alterações de dados sensíveis
- Dashboard de uso da plataforma

---

## Resumo de Módulos

| Módulo | Funcionalidades Principais | Usuários |
|--------|---------------------------|----------|
| **1. Autenticação** | Cadastro, Login, Recuperação | Todos |
| **2. Editor de Blocos** | Drag-and-drop, Execução | Aluno |
| **3. Desafios** | Trilha, Narrativa | Aluno |
| **4. Gamificação** | XP, Medalhas, Ranking, Avatar | Aluno |
| **5. Dashboard Professor** | Acompanhamento, Alertas, Relatórios | Professor |
| **6. Recursos Pedagógicos** | Planos, Atividades Desplugadas | Professor |
| **7. Colaboração** | Desafios em equipe, Ajuda | Aluno |
| **8. Acessibilidade** | Configurações, Leitor de tela | Todos |
| **9. Administração** | Gestão de conteúdo, Logs | Admin |

---

## Integrações Futuras (Roadmap)

### Fase 2
- Integração com Google Classroom
- Exportação de código em blocos para Python/JavaScript
- Certificados de conclusão

### Fase 3
- API pública para terceiros criarem desafios
- Comunidade de professores (compartilhamento de planos)
- Modo offline completo (PWA)
