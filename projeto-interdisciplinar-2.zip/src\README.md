# ComputaPlay - Protótipo Funcional

Protótipo desenvolvido pela equipe UNIFACISA para demonstração do projeto.

## Como Rodar

### 1. Instalar Node.js
Se não tiver instalado, baixe em: https://nodejs.org/

### 2. Instalar Dependências
Abra o terminal nesta pasta e execute:
```bash
npm install
```

### 3. Iniciar o Servidor
```bash
npm start
```

### 4. Acessar no Navegador
Abra: http://localhost:3000

## Usuários de Teste

### Aluno
- Usuário: `maria`
- Senha: `123456`

### Professor
- Usuário: `carla`
- Senha: `prof123`

## Funcionalidades Implementadas

### Área do Aluno
- ✅ Login
- ✅ Dashboard com XP e Nível
- ✅ Lista de desafios (3 desafios)
- ✅ Editor de blocos (drag and drop)
- ✅ Sistema de XP ao concluir desafios
- ✅ Progressão de níveis automática

### Área do Professor
- ✅ Login
- ✅ Dashboard da turma
- ✅ Lista de alunos
- ✅ Estatísticas (XP médio, nível médio)

## Estrutura de Arquivos

```
src/
├── server.js          # Servidor Node.js + Express
├── package.json       # Dependências do projeto
├── dados.json         # "Banco de dados" (criado automaticamente)
└── public/
    ├── index.html     # Tela de login
    ├── aluno.html     # Dashboard do aluno
    ├── professor.html # Dashboard do professor
    └── style.css      # Estilos CSS
```

## Observações Técnicas

- Banco de dados: JSON local (para simplificar)
- Autenticação: LocalStorage (não usar em produção)
- Editor de blocos: Drag and Drop nativo HTML5
- Responsivo: Funciona em desktop e mobile

## Próximas Melhorias (Fora do Escopo)

- Banco de dados real (PostgreSQL)
- Autenticação JWT
- Mais desafios
- Validação real de algoritmos
- Gráficos no dashboard do professor
- Sistema de medalhas

---

**Desenvolvido por:**
- Luiz Henrique da Silva Araujo
- Kaua Douglas Pereira Moura
- Pedro Henrique Falcao

**Disciplina:** Projeto Interdisciplinar I
**Professor:** Ricardo Dantas Silva
**UNIFACISA - 2025**
