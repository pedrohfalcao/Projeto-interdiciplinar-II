# 1.6 PÚBLICO-ALVO E PERFIS DE USUÁRIOS

## Público-Alvo Principal

O ComputaPlay é destinado primariamente a **alunos do 6º ao 9º ano do Ensino Fundamental II** e **professores da rede pública de ensino**, com foco inicial nas escolas da região de João Pessoa - PB e expansão gradual para outras regiões da Paraíba e do Brasil.

## Perfis de Usuários Detalhados

### 1. ALUNO DO ENSINO FUNDAMENTAL II

#### 1.1 Características Demográficas
- **Faixa etária**: 11 a 15 anos
- **Escolaridade**: 6º ao 9º ano
- **Rede de ensino**: Pública (municipal e estadual)
- **Localização**: Predominantemente João Pessoa e região metropolitana

#### 1.2 Características Comportamentais
- **Familiaridade com tecnologia**:
  - Uso frequente de smartphones (redes sociais, jogos, vídeos)
  - Baixa experiência com computadores desktop/notebooks
  - Pouca ou nenhuma experiência com programação

- **Estilo de aprendizagem**:
  - Preferência por conteúdos visuais e interativos
  - Atenção fragmentada (necessidade de feedback constante)
  - Aprendizado através de tentativa e erro
  - Engajamento maior com narrativas e desafios

- **Motivações**:
  - Curiosidade sobre tecnologia e jogos
  - Desejo de reconhecimento social (rankings, medalhas)
  - Interesse em atividades diferentes das aulas tradicionais

- **Barreiras**:
  - Medo de errar ou "quebrar" o sistema
  - Dificuldade com conceitos abstratos
  - Possível déficit de atenção
  - Limitações de acesso (internet, dispositivos em casa)

#### 1.3 Sub-Perfis de Alunos

**A) Aluno Nativo Digital (25%)**
- Tem computador/tablet em casa
- Familiarizado com jogos digitais complexos
- Aprende rapidamente interfaces novas
- Pode se tornar mentor de colegas

**B) Aluno Casual (50%)**
- Acesso limitado à tecnologia (apenas smartphone)
- Usa principalmente redes sociais
- Precisa de mais tempo para adaptação
- Beneficia-se de tutoriais passo a passo

**C) Aluno com Dificuldades Tecnológicas (20%)**
- Acesso muito limitado ou inexistente à tecnologia
- Ansiedade com relação a computadores
- Necessita de acompanhamento próximo do professor
- Aprende melhor com atividades desplugadas antes das digitais

**D) Aluno com Necessidades Especiais (5%)**
- Pode ter deficiências visuais, auditivas, cognitivas ou motoras
- Necessita de recursos de acessibilidade específicos
- Beneficia-se de interfaces personalizáveis e simplificadas

### 2. PROFESSOR DO ENSINO FUNDAMENTAL II

#### 2.1 Características Demográficas
- **Faixa etária**: 25 a 55 anos
- **Formação**: Licenciatura em Matemática, Ciências, Pedagogia, Língua Portuguesa ou áreas afins
- **Experiência**: 2 a 30 anos de magistério
- **Carga horária**: 20 a 40 horas semanais
- **Número de alunos**: 80 a 200 alunos (múltiplas turmas)

#### 2.2 Características Comportamentais
- **Familiaridade com tecnologia**:
  - Uso básico de computadores (editor de texto, e-mail)
  - Conhecimento limitado ou nulo de programação
  - Uso moderado de redes sociais
  - Pouca experiência com plataformas educacionais digitais

- **Desafios enfrentados**:
  - Sobrecarga de trabalho e falta de tempo
  - Salas superlotadas (35-40 alunos por turma)
  - Infraestrutura escolar precária
  - Pressão por resultados em avaliações externas
  - Dificuldade em engajar alunos com métodos tradicionais

- **Motivações**:
  - Melhorar a qualidade do ensino
  - Inovar nas práticas pedagógicas
  - Atender às demandas da BNCC
  - Facilitar o acompanhamento individual dos alunos
  - Reduzir tempo de preparação de aulas

- **Barreiras**:
  - Falta de formação em tecnologia educacional
  - Medo de expor desconhecimento técnico diante dos alunos
  - Resistência à mudança de metodologias consolidadas
  - Desconfiança quanto à eficácia de ferramentas digitais

#### 2.3 Sub-Perfis de Professores

**A) Professor Inovador (15%)**
- Busca ativamente novas metodologias
- Tem conhecimentos básicos de informática
- Disposto a experimentar e aprender
- Pode ser multiplicador na escola

**B) Professor Tradicional Aberto (50%)**
- Usa métodos convencionais, mas está disposto a mudar
- Precisa ver resultados práticos para aderir
- Valoriza ferramentas que economizem tempo
- Necessita de suporte técnico constante

**C) Professor Resistente (25%)**
- Desconfia de tecnologias educacionais
- Prefere métodos tradicionais comprovados
- Pode aderir se a ferramenta for muito simples
- Necessita de evidências robustas de eficácia

**D) Professor Próximo da Aposentadoria (10%)**
- Baixa familiaridade com tecnologia
- Pouca motivação para aprender ferramentas novas
- Valoriza simplicidade extrema
- Pode ser conquistado por benefícios claros de redução de carga de trabalho

### 3. GESTOR ESCOLAR (Usuário Secundário)

#### 3.1 Perfil
- **Função**: Diretor, coordenador pedagógico, secretário de educação
- **Interesse**: Acompanhar resultados da escola/rede
- **Necessidades**:
  - Relatórios consolidados de desempenho
  - Indicadores de uso da plataforma
  - Evidências de alinhamento com a BNCC
  - Dados para prestação de contas

### 4. FAMILIAR/RESPONSÁVEL (Usuário Terciário)

#### 4.1 Perfil
- **Relação**: Pais, avós, tutores
- **Interesse**: Acompanhar progresso do filho/pupilo
- **Necessidades**:
  - Visualização simples do desempenho
  - Orientações sobre como ajudar em casa
  - Comunicação clara sobre objetivos pedagógicos

## Personas Detalhadas

### Persona 1: Maria Eduarda - "A Curiosa"

**Idade**: 12 anos | **Ano escolar**: 7º ano | **Tipo**: Aluna Nativa Digital

**Contexto**:
Maria tem um tablet em casa que ganhou de aniversário. Adora jogar no celular da mãe e assistir vídeos no YouTube. Já tentou aprender a programar sozinha assistindo tutoriais, mas achou muito difícil. É curiosa, participa das aulas e gosta de desafios.

**Objetivos**:
- Aprender a criar seus próprios jogos
- Se destacar entre os colegas
- Entender como funcionam os aplicativos que usa

**Frustrações**:
- Tutoriais muito complicados ou em inglês
- Falta de feedback quando erra
- Não saber por onde começar

**Como o ComputaPlay a atende**:
- Interface visual intuitiva em português
- Desafios progressivos com dificuldade crescente
- Sistema de medalhas que reconhece suas conquistas
- Possibilidade de compartilhar criações com colegas

---

### Persona 2: João Pedro - "O Resistente"

**Idade**: 14 anos | **Ano escolar**: 9º ano | **Tipo**: Aluno com Dificuldades Tecnológicas

**Contexto**:
João não tem computador em casa, apenas o celular da mãe que usa às vezes. Tem dificuldades em Matemática e já teve experiências frustrantes com tecnologia. Prefere atividades práticas e tem medo de "apertar o botão errado".

**Objetivos**:
- Passar de ano sem dificuldades
- Entender melhor Matemática
- Não passar vergonha na frente dos colegas

**Frustrações**:
- Interfaces confusas
- Sentir que está atrasado em relação aos colegas
- Não ter ajuda quando precisa

**Como o ComputaPlay o atende**:
- Navegação simples e intuitiva
- Impossibilidade de "quebrar" o sistema (ambiente seguro)
- Dicas contextuais quando fica preso em um desafio
- Atividades desplugadas que complementam o digital
- Sistema que valoriza progresso individual, não apenas ranking geral

---

### Persona 3: Ana Clara - "A Incluída"

**Idade**: 13 anos | **Ano escolar**: 8º ano | **Tipo**: Aluna com Necessidades Especiais (Deficiência Visual Parcial)

**Contexto**:
Ana tem baixa visão e usa recursos de ampliação para ler. Inteligente e dedicada, frequentemente enfrenta barreiras em ferramentas digitais não acessíveis. Usa leitor de tela em algumas situações e precisa de alto contraste.

**Objetivos**:
- Participar das atividades como qualquer outro aluno
- Desenvolver habilidades em tecnologia
- Ser independente no uso da plataforma

**Frustrações**:
- Ferramentas incompatíveis com leitores de tela
- Textos pequenos e baixo contraste
- Dependência constante de terceiros

**Como o ComputaPlay a atende**:
- Compatibilidade total com leitores de tela
- Opções de alto contraste e ampliação
- Navegação completa via teclado
- Blocos de programação com descrições textuais detalhadas
- Feedback sonoro além do visual

---

### Persona 4: Professora Carla - "A Sobrecarregada"

**Idade**: 38 anos | **Formação**: Licenciatura em Matemática | **Tipo**: Professora Tradicional Aberta

**Contexto**:
Carla leciona há 12 anos e tem 5 turmas com média de 35 alunos cada. Quer inovar, mas tem pouco tempo para planejar aulas e nenhum conhecimento de programação. Sente pressão para trabalhar pensamento computacional conforme a BNCC, mas não sabe como.

**Objetivos**:
- Cumprir as exigências da BNCC
- Engajar melhor os alunos
- Economizar tempo na preparação de aulas
- Identificar rapidamente quais alunos têm dificuldades

**Frustrações**:
- Ferramentas que exigem muito tempo de aprendizado
- Falta de suporte técnico
- Dificuldade em acompanhar 175 alunos individualmente
- Plataformas que "mais dão trabalho do que ajudam"

**Como o ComputaPlay a atende**:
- Interface de professor extremamente simples
- Planos de aula prontos alinhados à BNCC
- Dashboard que mostra automaticamente quem está com dificuldades
- Não exige conhecimento de programação
- Banco de atividades desplugadas para usar quando não há computadores disponíveis
- Relatórios automáticos de desempenho

---

### Persona 5: Professor Roberto - "O Cético"

**Idade**: 52 anos | **Formação**: Licenciatura em Ciências | **Tipo**: Professor Resistente

**Contexto**:
Roberto ensina há 28 anos com métodos tradicionais que "sempre funcionaram". É cético quanto a "modismos pedagógicos" e já viu várias iniciativas tecnológicas fracassarem na escola. Usa computador apenas para tarefas básicas.

**Objetivos**:
- Manter a qualidade do ensino que sempre ofereceu
- Não perder tempo com ferramentas complicadas
- Evitar constrangimento por não dominar tecnologia

**Frustrações**:
- Pressão para usar tecnologias sem formação adequada
- Ferramentas que prometem muito e entregam pouco
- Sistemas que "travam" ou têm problemas técnicos

**Como o ComputaPlay o atende**:
- Funcionalidade mesmo com conhecimento técnico zero
- Confiabilidade e estabilidade do sistema
- Resultados visíveis rapidamente (engajamento dos alunos)
- Não obriga a mudar completamente sua metodologia (pode integrar gradualmente)
- Suporte técnico responsivo

## Síntese: Necessidades Comuns aos Perfis

### Para Alunos:
- Interface visual, intuitiva e atrativa
- Feedback imediato e construtivo
- Progressão clara e recompensas
- Ambiente seguro para experimentar e errar
- Acessibilidade universal

### Para Professores:
- Simplicidade extrema de uso
- Economia de tempo
- Resultados mensuráveis
- Autonomia (não depender de suporte técnico constante)
- Alinhamento explícito com BNCC

### Para Ambos:
- Gratuidade
- Funcionamento em equipamentos simples
- Conteúdo contextualizado e relevante
- Suporte e documentação clara
