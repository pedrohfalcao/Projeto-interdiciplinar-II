# 4.2 PROTÓTIPO NAVEGÁVEL

## Descrição

O protótipo navegável é uma versão interativa de média fidelidade da plataforma ComputaPlay, permitindo simular a experiência do usuário através das principais funcionalidades sem código funcional.

## Ferramenta

O protótipo será desenvolvido em plataforma de design interativo, permitindo navegação entre telas e simulação de interações.

---

## Fluxos de Navegação Implementados

### 1. FLUXO DO ALUNO

#### A) Onboarding Completo
```
Tela Login
  ↓ [Cadastrar com código]
Tela Cadastro
  ↓ [Enviar]
Tela Criação Avatar
  ↓ [Salvar e Continuar]
Tutorial Interativo (5 passos)
  ↓ [Concluir Tutorial]
Dashboard Principal
```

#### B) Resolver Desafio
```
Dashboard
  ↓ [Clicar em Desafio]
Tela do Desafio (Editor de Blocos)
  ↓ [Arrastar blocos]
Área de Trabalho (código em blocos)
  ↓ [Executar]
Animação de Execução
  ↓ [Se sucesso]
Tela de Parabéns
  ↓ [Próximo Desafio ou Dashboard]
```

#### C) Pedir Ajuda
```
Tela do Desafio
  ↓ [Preciso de Ajuda]
Modal: Escolher tipo
  ↓ [Dica Automática] ou [Pedir a Colega]

Se Dica Automática:
  → Exibir dica gradual
  → Voltar ao desafio

Se Pedir a Colega:
  → Lista de colegas disponíveis
  → Enviar pedido
  → Aguardar aceitação
  → Abrir chat
```

#### D) Ver Progresso e Medalhas
```
Dashboard
  ↓ [Clicar em "Medalhas"]
Galeria de Medalhas
  ↓ [Clicar em medalha]
Modal com detalhes da medalha

Dashboard
  ↓ [Clicar em "Progresso"]
Tela de Estatísticas Pessoais
  (Gráficos, histórico, conquistas)
```

### 2. FLUXO DO PROFESSOR

#### A) Criar Turma
```
Dashboard Professor
  ↓ [+ Nova Turma]
Formulário de Criação
  ↓ [Criar]
Modal: Código Gerado
  (Opções: Imprimir, Projetar, Copiar)
  ↓ [Fechar]
Dashboard atualizado com nova turma
```

#### B) Acompanhar Turma
```
Dashboard Professor
  ↓ [Ver Dashboard - Turma X]
Dashboard Detalhado da Turma
  (Gráficos, lista de alunos, alertas)
  ↓ [Clicar em aluno específico]
Perfil do Aluno
  (Histórico completo, desafios concluídos)
```

#### C) Gerar Relatório
```
Dashboard Professor
  ↓ [Seção Relatórios]
Tela de Configuração de Relatório
  (Selecionar alunos, período, formato)
  ↓ [Gerar]
Tela de Carregamento (2 seg)
  ↓
Modal: Relatório Pronto
  ↓ [Download]
Simulação de arquivo baixado
```

#### D) Acessar Recursos Pedagógicos
```
Dashboard Professor
  ↓ [Planos de Aula]
Biblioteca de Planos
  (Filtros por ano, conceito)
  ↓ [Clicar em plano]
Visualização do Plano Completo
  (Opções: Editar, Exportar PDF)

Dashboard Professor
  ↓ [Atividades Desplugadas]
Banco de Atividades
  ↓ [Selecionar atividade]
Detalhes da Atividade
  (Opção: Imprimir)
```

---

## Interações Implementadas no Protótipo

### Micro-interações
1. **Hover em botões**: Mudança de cor/elevação
2. **Feedback de clique**: Animação de scale (0.95)
3. **Arrastar blocos**: Simulação com transição
4. **Progresso em barras**: Animação de preenchimento
5. **Notificações**: Toast messages animadas
6. **Modals**: Fade in/out
7. **Medalhas desbloqueadas**: Animação de "conquista"

### Transições
- Tempo padrão: 300ms
- Easing: ease-in-out
- Páginas: Slide left/right

### Estados dos Elementos
- **Normal**
- **Hover** (desktop)
- **Active** (clicado)
- **Disabled** (bloqueado)
- **Focus** (teclado - borda azul)

---

## Acessibilidade no Protótipo

### Implementado
- ✅ Tamanho mínimo de botões: 44x44px
- ✅ Contraste de cores validado (4.5:1)
- ✅ Indicadores visuais de foco
- ✅ Alt text em elementos informativos
- ✅ Ordem de tabulação lógica

### Demonstrado (via overlays/notas)
- Navegação via teclado (setas indicativas)
- Compatibilidade com leitor de tela (notas explicativas)
- Opções de personalização visual (telas alternativas)

---

## Estrutura de Arquivos no Figma

```
📁 ComputaPlay - Protótipo
  ├── 📄 Capa (informações do projeto)
  ├── 🎨 Design System
  │   ├── Cores
  │   ├── Tipografia
  │   ├── Componentes (botões, inputs, cards)
  │   └── Ícones
  ├── 📱 Fluxos - Aluno
  │   ├── 01 - Login/Cadastro
  │   ├── 02 - Onboarding
  │   ├── 03 - Dashboard
  │   ├── 04 - Desafio (Editor)
  │   ├── 05 - Parabéns (Sucesso)
  │   ├── 06 - Medalhas
  │   └── 07 - Progresso
  ├── 👨‍🏫 Fluxos - Professor
  │   ├── 01 - Login
  │   ├── 02 - Dashboard
  │   ├── 03 - Criar Turma
  │   ├── 04 - Dashboard Turma
  │   ├── 05 - Perfil Aluno
  │   ├── 06 - Relatórios
  │   └── 07 - Recursos Pedagógicos
  └── 📲 Versão Mobile (Responsiva)
      ├── Aluno
      └── Professor
```

---

## Guia de Navegação do Protótipo

### Para Testar como Aluno:
1. Iniciar na tela "Login"
2. Clicar em "Cadastrar com Código da Turma"
3. Preencher formulário e clicar "Cadastrar"
4. Customizar avatar
5. Seguir tutorial interativo (5 passos)
6. Explorar dashboard e clicar em desafio
7. Arrastar blocos e clicar "Executar"
8. Visualizar animação e tela de sucesso
9. Navegar para medalhas e progresso

### Para Testar como Professor:
1. Iniciar na tela "Login Professor"
2. Fazer login (simulado)
3. Clicar em "+ Nova Turma"
4. Preencher e ver código gerado
5. Acessar dashboard de uma turma
6. Clicar em aluno para ver detalhes
7. Gerar relatório
8. Explorar planos de aula

---

## Telas Responsivas

### Desktop (1920x1080)
- Layout padrão com sidebar
- Visualização ampla de gráficos

### Tablet (768x1024)
- Sidebar retrátil
- Cards em 2 colunas

### Mobile (375x667)
- Menu hamburger
- Cards em 1 coluna
- Editor de blocos adaptado (scroll horizontal)

---

## Componentes Reutilizáveis Criados

### Design System Components
1. **Botões**
   - Primary (azul)
   - Secondary (cinza)
   - Success (verde)
   - Danger (vermelho)

2. **Cards**
   - Card de Desafio
   - Card de Aluno
   - Card de Estatística

3. **Inputs**
   - Text input
   - Password input
   - Select dropdown
   - Checkbox/Radio

4. **Navegação**
   - Top navigation bar
   - Sidebar menu
   - Breadcrumbs

5. **Feedback**
   - Toast notifications
   - Modals
   - Alerts

6. **Gamificação**
   - Barra de progresso XP
   - Badge de medalha
   - Avatar

---

## Notas de Prototipação

### Limitações do Protótipo
Este protótipo simula a experiência visual e de navegação, mas **não inclui**:
- Código funcional de programação em blocos
- Validação real de algoritmos
- Persistência de dados
- Integração com banco de dados
- Animações complexas de execução de código

### O que está simulado:
- ✅ Fluxos completos de navegação
- ✅ Interações básicas (cliques, hovers)
- ✅ Transições entre telas
- ✅ Estados de componentes
- ✅ Responsividade

---

## Links de Acesso

### Protótipo Navegável (Figma)
- **Modo Visualização**: [Link para compartilhamento]
- **Modo Apresentação**: [Link para fullscreen]
- **Com Comentários**: [Link para colaboração]

### Instruções de Acesso
1. Clicar no link acima
2. Não é necessário conta Figma para visualizar
3. Usar setas ou clicar nos elementos interativos
4. Tecla "R" para resetar
5. Tecla "F" para fullscreen

---

## Critérios de Avaliação do Protótipo

### Usabilidade
- [ ] Navegação intuitiva
- [ ] Tempo para completar tarefa < 3 minutos (primeira vez)
- [ ] Usuários encontram funções principais sem ajuda

### Acessibilidade
- [ ] Contraste adequado (WCAG AA)
- [ ] Foco visível
- [ ] Tamanhos de toque adequados

### Alinhamento com Requisitos
- [ ] Todos os requisitos de alta prioridade representados
- [ ] Fluxos críticos implementados
- [ ] Gamificação visível

---

## Próximos Passos

1. **Teste com Usuários**: Sessões com 5-8 alunos e 3-5 professores
2. **Coleta de Feedback**: Questionário pós-teste (SUS - System Usability Scale)
3. **Iteração**: Ajustes baseados em feedback
4. **Aprovação**: Validação com stakeholders
5. **Handoff para Desenvolvimento**: Specs detalhadas e assets

---

## Entregáveis

- **Link do protótipo Figma** (compartilhável)
- **Vídeo de demonstração** (2-3 minutos)
- **Documento de especificações** (para desenvolvedores)
- **Exportação de assets** (ícones, imagens)

Local da documentação: `/wireframes/prototipo-navegavel/`
