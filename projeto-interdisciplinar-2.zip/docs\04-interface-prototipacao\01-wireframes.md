# 4.1 WIREFRAMES DAS TELAS PRINCIPAIS

## Visão Geral

Este documento descreve os wireframes (esqueletos visuais) das principais telas da plataforma ComputaPlay, organizadas por perfil de usuário.

---

## WIREFRAMES - ÁREA DO ALUNO

### 1. Tela de Login/Cadastro

```
┌─────────────────────────────────────────────┐
│          [LOGO COMPUTAPLAY]                 │
│                                             │
│  ┌────────────────────────────────────┐    │
│  │  [ícone] Nome de usuário           │    │
│  └────────────────────────────────────┘    │
│                                             │
│  ┌────────────────────────────────────┐    │
│  │  [ícone] Senha                     │    │
│  └────────────────────────────────────┘    │
│                                             │
│  [ Esqueci minha senha ]                   │
│                                             │
│  ┌────────────────────────────────────┐    │
│  │        ENTRAR                      │    │
│  └────────────────────────────────────┘    │
│                                             │
│  ───────────── OU ─────────────            │
│                                             │
│  Primeiro acesso?                          │
│  ┌────────────────────────────────────┐    │
│  │     CADASTRAR COM CÓDIGO DA TURMA  │    │
│  └────────────────────────────────────┘    │
│                                             │
│  [ícone acessibilidade] Configurações      │
└─────────────────────────────────────────────┘
```

---

### 2. Dashboard Principal do Aluno

```
┌─────────────────────────────────────────────────────────────┐
│ [LOGO] ComputaPlay    [notif]  [config]  [Avatar]  Sair  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Olá, João Pedro!                   Nível 5 (450/600 XP)   │
│  ───────────────────────────────────────────────────────   │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  TRILHA DE APRENDIZAGEM                           │    │
│  │                                                    │    │
│  │  [✓] Desafio 1: Primeira Jornada (10 XP)         │    │
│  │  [✓] Desafio 2: Padrões Visuais (15 XP)          │    │
│  │  [▶️] Desafio 3: O Labirinto (25 XP) ← Atual     │    │
│  │  [bloq] Desafio 4: Festa Junina (30 XP)          │    │
│  │  [bloq] Desafio 5: Construindo a Ponte (50 XP)  │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │   MEDALHAS   │  │   PROGRESSO  │  │   RANKING    │    │
│  │              │  │              │  │              │    │
│  │   [8/20]     │  │   25 de 50   │  │   3º lugar   │    │
│  │   Ver Todas  │  │  desafios    │  │  Ver Ranking │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  NARRATIVA ATUAL                                  │    │
│  │  "O festival de São João está chegando!          │    │
│  │   Ajude Maria a organizar a quadrilha..."        │    │
│  │                                         [Continuar]│    │
│  └───────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

---

### 3. Tela de Resolução de Desafio (Editor de Blocos)

```
┌─────────────────────────────────────────────────────────────────┐
│ ← Voltar  Desafio 3: O Labirinto            [?] Ajuda  [⚙️]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ┌─────────────────────────┬─────────────────────────────────┐ │
│ │ PALETA DE BLOCOS        │  ÁREA DE VISUALIZAÇÃO           │ │
│ │                         │                                 │ │
│ │ 🔹 Movimento            │     [Personagem]                │ │
│ │  [→ Mover Direita]      │          ┌─┐                   │ │
│ │  [← Mover Esquerda]     │          │ │                   │ │
│ │  [↑ Mover Cima]         │      ────┼─┼────               │ │
│ │  [↓ Mover Baixo]        │          │⭐│                   │ │
│ │                         │          └─┘                   │ │
│ │ 🔄 Loops                │                                 │ │
│ │  [Repetir N vezes]      │  Objetivo: Alcançar a estrela  │ │
│ │  [Enquanto]             │                                 │ │
│ │                         │  [▶️ Executar] [⏸ Pausar]      │ │
│ │ 🔀 Condicionais         │  [🔄 Reiniciar]                │ │
│ │  [Se... então]          │                                 │ │
│ │  [Se... senão]          │  Tentativas: 2  Tempo: 1:35    │ │
│ │                         │                                 │ │
│ └─────────────────────────┴─────────────────────────────────┘ │
│                                                                 │
│ ┌───────────────────────────────────────────────────────────┐ │
│ │  💡 ÁREA DE TRABALHO (Seu Código)                         │ │
│ │                                                            │ │
│ │  ┌──────────────────────┐                                 │ │
│ │  │  Repetir 4 vezes     │                                 │ │
│ │  │  ┌────────────────┐  │                                 │ │
│ │  │  │ → Mover Direita│  │                                 │ │
│ │  │  └────────────────┘  │                                 │ │
│ │  │  ┌────────────────┐  │                                 │ │
│ │  │  │ ↑ Mover Cima   │  │                                 │ │
│ │  │  └────────────────┘  │                                 │ │
│ │  └──────────────────────┘                                 │ │
│ │                                                            │ │
│ │  [ 💡 Preciso de Ajuda ]  [ 🗑️ Limpar Tudo ]            │ │
│ └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

### 4. Tela de Sucesso (Desafio Concluído)

```
┌─────────────────────────────────────────────┐
│                                             │
│           ⭐ PARABÉNS! ⭐                   │
│                                             │
│    Você completou "O Labirinto"!            │
│                                             │
│  ┌────────────────────────────────────┐    │
│  │   🎯 XP Ganho: +120 XP             │    │
│  │   ⚡ Bônus Eficiência: +20 XP      │    │
│  │   ──────────────────────────       │    │
│  │   💫 Total: 140 XP                 │    │
│  └────────────────────────────────────┘    │
│                                             │
│  🏅 Nova Medalha Desbloqueada!              │
│     "Mestre do Loop"                        │
│     [Ícone da medalha]                      │
│                                             │
│  ┌────────────────────────────────────┐    │
│  │  📊 Suas Estatísticas:             │    │
│  │  • Tentativas: 3                   │    │
│  │  • Tempo: 2:15                     │    │
│  │  • Eficiência: 90%                 │    │
│  └────────────────────────────────────┘    │
│                                             │
│  ┌────────────────┐  ┌────────────────┐    │
│  │ VER SOLUÇÃO    │  │ PRÓXIMO DESAFIO│    │
│  └────────────────┘  └────────────────┘    │
│                                             │
│         [ Voltar ao Dashboard ]             │
└─────────────────────────────────────────────┘
```

---

## WIREFRAMES - ÁREA DO PROFESSOR

### 5. Dashboard do Professor

```
┌─────────────────────────────────────────────────────────────────┐
│ [LOGO] ComputaPlay - Área do Professor  [🔔] [Prof. Carla] ▼  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  MINHAS TURMAS                                  [+ Nova Turma]  │
│  ───────────────────────────────────────────────────────────   │
│                                                                 │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────┐   │
│  │ 7º Ano A         │ │ 8º Ano B         │ │ 9º Ano C     │   │
│  │ 32 alunos        │ │ 28 alunos        │ │ 25 alunos    │   │
│  │ Código: A3F7K2   │ │ Código: B9G2X5   │ │ Código: ...  │   │
│  │                  │ │                  │ │              │   │
│  │ 🟢 23 ativos     │ │ 🟢 20 ativos     │ │ ...          │   │
│  │ 🟡 5 atenção     │ │ 🟡 4 atenção     │ │              │   │
│  │ 🔴 4 urgente     │ │ 🔴 4 urgente     │ │              │   │
│  │                  │ │                  │ │              │   │
│  │ [Ver Dashboard]  │ │ [Ver Dashboard]  │ │ [Ver ...]    │   │
│  └──────────────────┘ └──────────────────┘ └──────────────┘   │
│                                                                 │
│  ⚠️ ALERTAS RECENTES                                            │
│  ───────────────────────────────────────────────────────────   │
│  • João Pedro (7º A) - Dificuldade com Loops              🔴   │
│  • Ana Silva (8º B) - Inativo há 5 dias                   🟡   │
│  • Carlos Souza (7º A) - Múltiplas tentativas em desafios 🟡   │
│                                                  [Ver Todos]    │
│                                                                 │
│  📚 RECURSOS PEDAGÓGICOS                                        │
│  ───────────────────────────────────────────────────────────   │
│  [📄 Planos de Aula] [🎲 Atividades Desplugadas] [📊 Relatórios]│
└─────────────────────────────────────────────────────────────────┘
```

---

### 6. Dashboard Detalhado da Turma

```
┌─────────────────────────────────────────────────────────────────┐
│ ← Voltar  7º Ano A - Dashboard                    [📊 Relatório]│
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  VISÃO GERAL DA TURMA              Filtro: [Última semana ▼]   │
│  ───────────────────────────────────────────────────────────   │
│                                                                 │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────┐  │
│  │ 32 Alunos  │ │ 68% Média  │ │ 450 Desaf. │ │ 12h Tempo  │  │
│  │ Total      │ │ Progresso  │ │ Concluídos │ │ Médio      │  │
│  └────────────┘ └────────────┘ └────────────┘ └────────────┘  │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  📊 GRÁFICO: Progresso da Turma                           │ │
│  │  [Gráfico de barras mostrando desafios concluídos/semana] │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ALUNOS                        🔍 [Buscar aluno...]   [Filtros]│
│  ───────────────────────────────────────────────────────────   │
│                                                                 │
│  Nome              Progresso  XP    Última Ativ.   Status      │
│  ────────────────────────────────────────────────────────────  │
│  👤 Ana Clara      ████████░░ 80%   520   Há 1 hora    🟢      │
│  👤 Carlos Edu     ███████░░░ 75%   480   Há 2 horas   🟢      │
│  👤 João Pedro     ████░░░░░░ 45%   280   Há 3 dias    🔴 ⚠️   │
│  👤 Maria Luisa    █████████░ 92%   650   Há 30 min    🟢      │
│  ...                                                            │
│                                                   [Ver Todos]   │
│                                                                 │
│  ⚠️ REQUER ATENÇÃO (7)                            [Ver Detalhes]│
│  • João Pedro - Dificuldade com Loops                          │
│  • Lucas Sousa - Tempo excessivo em desafios                   │
│  ...                                                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## Wireframes Adicionais (Descrição Resumida)

### 7. Tela de Customização de Avatar
- Cabeçalho com preview do avatar em tempo real
- Categorias: Pele, Cabelo, Roupa, Acessórios
- Grid de opções (bloqueadas e desbloqueadas)
- Botão "Salvar"

### 8. Galeria de Medalhas
- Grid de medalhas conquistadas (coloridas) e bloqueadas (cinza)
- Cada medalha mostrando: ícone, nome, descrição, data de conquista
- Filtros por categoria

### 9. Ranking da Turma
- Top 10 com avatares
- Colunas: Posição, Nome, XP, Colaboração, Total
- Destaque para posição do aluno atual

### 10. Tela de Criação de Turma (Professor)
- Formulário simples: Nome, Ano Escolar, Escola
- Código gerado automaticamente em destaque
- Opções de impressão/projeção do código

### 11. Geração de Relatório (Professor)
- Seleção de tipo: Individual/Turma
- Filtros: Alunos, Período, Métricas
- Escolha de formato: PDF/CSV
- Preview antes de exportar

### 12. Configurações de Acessibilidade
- Sliders para tamanho de fonte
- Botões de seleção de tema (Claro/Escuro/Alto Contraste)
- Toggles para: Leitor de tela, Legendas, Navegação por teclado
- Preview em tempo real

---

## Diretrizes de Design

### Cores Principais
- **Primária**: #4A90E2 (Azul - Confiança, Aprendizado)
- **Secundária**: #F5A623 (Laranja - Energia, Criatividade)
- **Sucesso**: #7ED321 (Verde)
- **Atenção**: #F8E71C (Amarelo)
- **Urgente**: #D0021B (Vermelho)
- **Neutro**: #4A4A4A (Cinza Escuro)

### Tipografia
- **Títulos**: Montserrat Bold
- **Corpo**: Open Sans Regular
- **Tamanhos**: 14px (P), 16px (M - padrão), 18px (G), 22px (XG)

### Ícones
- Biblioteca: Font Awesome ou Material Icons
- Tamanho mínimo: 24x24px (clicável: 44x44px)

### Espaçamento
- Grid: 8px (múltiplos de 8)
- Padding de cards: 16px
- Margem entre seções: 24px

### Acessibilidade
- Contraste mínimo: 4.5:1 (texto normal)
- Todas as imagens com alt text
- Indicador visual de foco: borda azul 2px
- Botões com estado hover, active, disabled

---

## Ferramentas para Criação dos Wireframes

### Recomendadas:
1. **Figma** (Gratuito, colaborativo)
2. **Adobe XD** (Gratuito para estudantes)
3. **Balsamiq** (Especializado em wireframes)
4. **Sketch** (MacOS, pago)

### Entregáveis:
- Arquivo Figma/XD com todas as telas
- Exportação em PNG (1920x1080) de cada tela
- Local: `/wireframes/`
