# 3.1 DIAGRAMA DE CASOS DE USO

## Visão Geral

O diagrama de casos de uso representa as interações entre os atores (Aluno, Professor, Sistema) e as principais funcionalidades da plataforma ComputaPlay.

## Atores

### Primários
1. **Aluno**: Usuário que utiliza a plataforma para aprender pensamento computacional
2. **Professor**: Educador que gerencia turmas e acompanha progresso dos alunos
3. **Administrador**: Responsável por gerenciar conteúdo e configurações do sistema

### Secundários
4. **Sistema**: Executa processos automatizados (gamificação, alertas)

## Casos de Uso por Ator

### ALUNO
- **UC01**: Cadastrar-se na Plataforma
- **UC02**: Autenticar-se
- **UC03**: Criar e Customizar Avatar
- **UC04**: Visualizar Trilha de Aprendizagem
- **UC05**: Selecionar Desafio
- **UC06**: Resolver Desafio com Blocos
- **UC07**: Executar Algoritmo
- **UC08**: Solicitar Dica
- **UC09**: Visualizar Progresso Pessoal
- **UC10**: Ganhar XP e Medalhas
- **UC11**: Subir de Nível
- **UC12**: Ver Ranking da Turma
- **UC13**: Participar de Desafio Colaborativo
- **UC14**: Solicitar Ajuda de Colega
- **UC15**: Ajustar Configurações de Acessibilidade
- **UC16**: Revisar Desafio Concluído

### PROFESSOR
- **UC17**: Cadastrar-se como Professor
- **UC18**: Autenticar-se
- **UC19**: Criar Turma
- **UC20**: Gerar Código de Turma
- **UC21**: Visualizar Dashboard de Turma
- **UC22**: Acompanhar Progresso Individual
- **UC23**: Identificar Alunos com Dificuldades
- **UC24**: Gerar Relatório de Desempenho
- **UC25**: Acessar Planos de Aula
- **UC26**: Buscar Atividades Desplugadas
- **UC27**: Atribuir Tarefa Específica
- **UC28**: Enviar Mensagem para Alunos
- **UC29**: Gerenciar Alunos da Turma

### ADMINISTRADOR
- **UC30**: Criar/Editar/Excluir Desafios
- **UC31**: Mapear Competências BNCC
- **UC32**: Moderar Conteúdo
- **UC33**: Visualizar Logs do Sistema
- **UC34**: Gerenciar Usuários

### SISTEMA (Automatizado)
- **UC35**: Verificar Critérios de Medalhas
- **UC36**: Atualizar Níveis de Alunos
- **UC37**: Gerar Alertas de Dificuldades
- **UC38**: Salvar Progresso Automaticamente
- **UC39**: Validar Código em Blocos

## Relacionamentos entre Casos de Uso

### Inclusões (<<include>>)
- **UC06** (Resolver Desafio) **include** **UC07** (Executar Algoritmo)
- **UC06** (Resolver Desafio) **include** **UC39** (Validar Código)
- **UC10** (Ganhar XP) **include** **UC36** (Atualizar Níveis)
- **UC21** (Visualizar Dashboard) **include** **UC23** (Identificar Dificuldades)

### Extensões (<<extend>>)
- **UC08** (Solicitar Dica) **extends** **UC06** (Resolver Desafio)
- **UC14** (Solicitar Ajuda) **extends** **UC06** (Resolver Desafio)
- **UC13** (Desafio Colaborativo) **extends** **UC06** (Resolver Desafio)

### Generalizações
- **UC01** (Cadastrar Aluno) e **UC17** (Cadastrar Professor) generalizam de "Cadastrar Usuário"
- **UC02** (Autenticar Aluno) e **UC18** (Autenticar Professor) generalizam de "Autenticar"

## Descrição Textual para Criação do Diagrama

```
[DIAGRAMA DE CASOS DE USO - ComputaPlay]

                        SISTEMA
                           |
                    [UC35-UC39]
                    (automáticos)
                           |
                           |
    ALUNO ---------------SISTEMA----------------PROFESSOR
      |                    |                       |
   UC01-UC16          [Processos]              UC17-UC29
      |                    |                       |
      |                    |                       |
      +---Aprendizagem     |                       +---Gestão
      |   - UC04-UC08      |                       |   - UC19-UC24
      |                    |                       |
      +---Gamificação      |                       +---Recursos Pedagógicos
      |   - UC10-UC12      |                       |   - UC25-UC26
      |                    |                       |
      +---Colaboração      |                       +---Comunicação
      |   - UC13-UC14      |                       |   - UC27-UC28
      |                    |                       |
      +---Personalização   |                   ADMINISTRADOR
          - UC03, UC15     |                       |
                           |                    UC30-UC34
                           |                       |
                           +---Conteúdo e Moderação
```

## Representação Visual

O diagrama será criado utilizando ferramentas de modelagem UML padrão.

## Exemplo em Notação PlantUML

```plantuml
@startuml
left to right direction
skinparam packageStyle rectangle

actor Aluno
actor Professor
actor Sistema
actor Administrador

rectangle ComputaPlay {
  usecase "UC06: Resolver Desafio" as UC06
  usecase "UC07: Executar Algoritmo" as UC07
  usecase "UC08: Solicitar Dica" as UC08
  usecase "UC10: Ganhar XP" as UC10
  usecase "UC21: Visualizar Dashboard" as UC21
  usecase "UC23: Identificar Dificuldades" as UC23
  usecase "UC35: Verificar Medalhas" as UC35
  usecase "UC36: Atualizar Níveis" as UC36
}

Aluno --> UC06
Aluno --> UC08
Aluno --> UC10

Professor --> UC21

Sistema --> UC35
Sistema --> UC36

UC06 ..> UC07 : <<include>>
UC08 ..> UC06 : <<extend>>
UC21 ..> UC23 : <<include>>
UC10 ..> UC36 : <<include>>

@enduml
```

## Observações

1. O diagrama completo deve incluir todos os 39 casos de uso
2. Organizar visualmente por funcionalidade (agrupamento)
3. Destacar casos de uso críticos (Alta prioridade) com cores diferenciadas
4. Incluir legenda explicativa dos relacionamentos

## Entregável

- **Arquivo**: diagrama-casos-de-uso.png (ou .pdf)
- **Local**: `/diagramas/diagrama-casos-de-uso.png`
- **Resolução mínima**: 1920x1080px para legibilidade
