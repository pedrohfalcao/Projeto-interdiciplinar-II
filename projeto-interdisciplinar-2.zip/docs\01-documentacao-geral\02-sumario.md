# SUMÁRIO

## 1. DOCUMENTAÇÃO GERAL DO PROJETO
1.1. [Capa e Identificação do Grupo](./01-capa-identificacao.md)
1.2. [Sumário](./02-sumario.md)
1.3. [Descrição da Situação-Problema](./03-descricao-problema.md)
1.4. [Objetivos do Projeto](./04-objetivos.md)
   - 1.4.1. Objetivo Geral
   - 1.4.2. Objetivos Específicos
1.5. [Justificativa e Relevância da Solução](./05-justificativa.md)
1.6. [Público-Alvo e Perfis de Usuários](./06-publico-alvo.md)

## 2. ENGENHARIA DE REQUISITOS
2.1. [Levantamento e Análise de Requisitos](../02-engenharia-requisitos/01-requisitos-funcionais-nao-funcionais.md)
   - 2.1.1. Requisitos Funcionais
   - 2.1.2. Requisitos Não Funcionais
2.2. [Histórias de Usuário](../02-engenharia-requisitos/02-historias-de-usuario.md)
2.3. [Casos de Uso](../02-engenharia-requisitos/03-casos-de-uso.md)
2.4. [Regras de Negócio](../02-engenharia-requisitos/04-regras-de-negocio.md)

## 3. MODELAGEM E ARQUITETURA
3.1. [Diagrama de Casos de Uso](../03-modelagem-arquitetura/01-diagrama-casos-de-uso.md)
3.2. [Diagrama de Classes](../03-modelagem-arquitetura/02-diagrama-classes.md)
3.3. [Fluxogramas e BPMN](../03-modelagem-arquitetura/03-fluxograma-bpmn.md)
3.4. [Diagrama de Sequência](../03-modelagem-arquitetura/04-diagrama-sequencia.md)
3.5. [Modelo Conceitual de Dados (DER)](../03-modelagem-arquitetura/05-modelo-dados-der.md)

## 4. INTERFACE E PROTOTIPAÇÃO
4.1. [Wireframes das Telas Principais](../04-interface-prototipacao/01-wireframes.md)
4.2. [Protótipo Navegável](../04-interface-prototipacao/02-prototipo-navegavel.md)
4.3. [Diretrizes de Acessibilidade (WCAG)](../04-interface-prototipacao/03-diretrizes-acessibilidade.md)

## 5. DESIGN DA SOLUÇÃO
5.1. [Arquitetura do Sistema](../05-design-solucao/01-arquitetura-sistema.md)
5.2. [Tecnologias Utilizadas](../05-design-solucao/01-arquitetura-sistema.md#tecnologias-previstas)
   - 5.2.1. Front-end
   - 5.2.2. Back-end
   - 5.2.3. Banco de Dados
   - 5.2.4. Frameworks e Bibliotecas
5.3. [Descrição dos Módulos e Funcionalidades](../05-design-solucao/02-modulos-funcionalidades.md)

## 6. CONSIDERAÇÕES FINAIS
6.1. [Limitações do Protótipo Atual](../06-consideracoes-finais/01-limitacoes-melhorias.md)
6.2. [Possíveis Evoluções e Melhorias Futuras](../06-consideracoes-finais/01-limitacoes-melhorias.md#melhorias-futuras)
6.3. [Referências Bibliográficas](../06-consideracoes-finais/02-referencias.md)

## ANEXOS
A. Glossário de Termos
B. Pesquisas com Público-Alvo
C. Documentação Técnica Complementar
