# 1.3 DESCRIÇÃO DA SITUAÇÃO-PROBLEMA

## Contexto

A Base Nacional Comum Curricular (BNCC), implementada progressivamente desde 2018, estabelece que o desenvolvimento do pensamento computacional deve ser trabalhado desde os anos iniciais do Ensino Fundamental. Este documento normativo define as aprendizagens essenciais que todos os alunos devem desenvolver ao longo da Educação Básica, incluindo competências relacionadas à cultura digital e ao raciocínio lógico.

No entanto, a realidade das escolas públicas brasileiras, especialmente em regiões como João Pessoa e outras cidades da Paraíba, apresenta desafios significativos para a implementação efetiva desses objetivos:

### 1. Carência de Infraestrutura
- Falta de laboratórios de informática adequados
- Equipamentos obsoletos ou insuficientes
- Conectividade limitada à internet
- Recursos financeiros escassos para investimento em tecnologia

### 2. Formação Docente Inadequada
- Professores sem formação específica em programação ou pensamento computacional
- Dificuldade em traduzir conceitos abstratos (algoritmos, decomposição, abstração) em atividades práticas
- Resistência à adoção de novas metodologias por falta de capacitação
- Ausência de materiais didáticos apropriados

### 3. Ferramentas Existentes Inadequadas
As plataformas educacionais disponíveis geralmente apresentam limitações:
- **Alto custo de licenciamento**: Inviável para escolas públicas com orçamento limitado
- **Baixa acessibilidade**: Não atendem às necessidades de alunos com deficiências visuais, auditivas ou cognitivas
- **Interface complexa**: Exigem conhecimento prévio que professores e alunos não possuem
- **Dependência de hardware específico**: Necessitam de computadores de alta performance
- **Conteúdo descontextualizado**: Não dialogam com a realidade cultural e social dos estudantes

### 4. Falta de Engajamento
- Métodos tradicionais de ensino não despertam interesse dos alunos nativos digitais
- Ausência de elementos motivacionais que tornem o aprendizado atrativo
- Dificuldade em manter a atenção e participação contínua nas atividades

## Problema Central

**Como criar uma plataforma educacional web, de baixo custo e alta acessibilidade, que utilize a gamificação para ensinar os pilares do pensamento computacional (decomposição, reconhecimento de padrões, abstração e algoritmos) a alunos do 6º ao 9º ano do Ensino Fundamental II, permitindo que professores sem conhecimento prévio em programação possam aplicá-la em sala de aula de forma efetiva e inclusiva?**

## Pilares do Pensamento Computacional a Serem Desenvolvidos

### 1. Decomposição
Capacidade de dividir problemas complexos em partes menores e mais gerenciáveis.

### 2. Reconhecimento de Padrões
Identificação de similaridades, tendências e regularidades nos dados e problemas.

### 3. Abstração
Filtragem e classificação de informações, focando apenas no que é relevante e ignorando detalhes desnecessários.

### 4. Algoritmos
Criação de sequências de passos ordenados para resolver problemas ou realizar tarefas.

## Desafios Específicos a Serem Endereçados

1. **Acessibilidade Digital**: Garantir que estudantes com diferentes tipos de deficiências possam utilizar a plataforma plenamente
2. **Autonomia do Professor**: Criar uma ferramenta que não exija expertise técnica para ser aplicada
3. **Baixo Custo Operacional**: Funcionar em dispositivos de baixo desempenho e com conectividade limitada
4. **Engajamento Sustentável**: Manter os alunos motivados através de mecânicas de gamificação bem projetadas
5. **Alinhamento Curricular**: Atender rigorosamente às competências e habilidades previstas na BNCC
6. **Inclusão Social**: Contextualizar os desafios com a realidade local dos estudantes paraibanos
