# 2.3 CASOS DE USO

## UC01 - Cadastrar e Autenticar Aluno

**Ator Principal**: Aluno
**Pré-condições**: Aluno possui código de turma válido
**Pós-condições**: Aluno está autenticado e pode acessar a plataforma

**Fluxo Principal**:
1. Aluno acessa a página de cadastro
2. Sistema exibe formulário de cadastro
3. Aluno preenche nome, usuário, senha e código da turma
4. Sistema valida código da turma
5. Sistema cria conta do aluno
6. Sistema autentica aluno automaticamente
7. Sistema redireciona para tutorial inicial

**Fluxos Alternativos**:
- 4a. Código da turma inválido
  - Sistema exibe mensagem de erro
  - Retorna ao passo 3

**Fluxos de Exceção**:
- 3a. Usuário já existe
  - Sistema informa que usuário está em uso
  - Sugere variações disponíveis

---

## UC02 - Resolver Desafio com Programação em Blocos

**Ator Principal**: Aluno
**Pré-condições**: Aluno está autenticado e selecionou um desafio
**Pós-condições**: Desafio resolvido, XP concedido, progresso salvo

**Fluxo Principal**:
1. Sistema exibe interface do desafio com descrição e objetivo
2. Sistema mostra editor de blocos e área de visualização
3. Aluno arrasta blocos da paleta para área de trabalho
4. Sistema valida encaixe dos blocos em tempo real
5. Aluno clica em "Executar"
6. Sistema interpreta código em blocos
7. Sistema executa animação do algoritmo
8. Sistema verifica se objetivo foi atingido
9. Sistema exibe mensagem de sucesso
10. Sistema concede XP e atualiza progresso
11. Sistema verifica se desbloqueou medalhas
12. Sistema salva solução do aluno

**Fluxos Alternativos**:
- 8a. Objetivo não atingido
  - Sistema identifica tipo de erro
  - Sistema exibe feedback específico
  - Sistema oferece opção de "Tentar Novamente" ou "Pedir Dica"
  - Retorna ao passo 3

- 8b. Aluno pede dica
  - Sistema exibe dica contextual progressiva
  - Retorna ao passo 3

**Fluxos de Exceção**:
- 6a. Erro de execução (loop infinito detectado)
  - Sistema interrompe execução após 2 segundos
  - Sistema alerta sobre possível loop infinito
  - Retorna ao passo 3

---

## UC03 - Criar Turma e Gerar Código

**Ator Principal**: Professor
**Pré-condições**: Professor está autenticado
**Pós-condições**: Turma criada, código gerado

**Fluxo Principal**:
1. Professor acessa seção "Minhas Turmas"
2. Professor clica em "Nova Turma"
3. Sistema exibe formulário de criação
4. Professor preenche nome da turma, ano escolar e escola
5. Sistema gera código único de 6 caracteres
6. Sistema cria turma no banco de dados
7. Sistema exibe código em formato grande
8. Sistema oferece opção de imprimir ou projetar código

**Fluxos Alternativos**: Nenhum

**Fluxos de Exceção**:
- 5a. Código gerado já existe (improvável)
  - Sistema gera novo código
  - Retorna ao passo 6

---

## UC04 - Acompanhar Progresso da Turma

**Ator Principal**: Professor
**Pré-condições**: Professor possui ao menos uma turma com alunos
**Pós-condições**: Professor visualiza dados atualizados

**Fluxo Principal**:
1. Professor seleciona turma no dashboard
2. Sistema carrega dados de progresso de todos os alunos
3. Sistema exibe gráficos de desempenho geral
4. Sistema lista alunos com indicadores visuais
5. Sistema destaca alunos com alertas (dificuldades)
6. Professor pode clicar em aluno específico para detalhes
7. Sistema exibe histórico individual do aluno selecionado

**Fluxos Alternativos**:
- 6a. Professor filtra por período
  - Sistema atualiza dados conforme filtro
  - Exibe estatísticas do período selecionado

**Fluxos de Exceção**: Nenhum

---

## UC05 - Gerar Relatório de Desempenho

**Ator Principal**: Professor
**Pré-condições**: Professor possui turma com dados
**Pós-condições**: Relatório gerado e disponível para download

**Fluxo Principal**:
1. Professor acessa seção "Relatórios"
2. Sistema exibe opções de relatório (individual/turma)
3. Professor seleciona tipo, alunos e período
4. Professor escolhe formato (PDF ou CSV)
5. Sistema processa dados
6. Sistema gera arquivo
7. Sistema disponibiliza download
8. Professor baixa relatório

**Fluxos Alternativos**: Nenhum

**Fluxos de Exceção**:
- 5a. Erro ao gerar relatório
  - Sistema exibe mensagem de erro
  - Sistema sugere tentar novamente ou contatar suporte

---

## UC06 - Ajustar Configurações de Acessibilidade

**Ator Principal**: Aluno ou Professor
**Pré-condições**: Usuário está autenticado
**Pós-condições**: Preferências salvas e aplicadas

**Fluxo Principal**:
1. Usuário clica no ícone de acessibilidade
2. Sistema exibe menu de opções
3. Usuário seleciona tamanho de fonte
4. Usuário seleciona tema de cores
5. Usuário ativa/desativa leitor de tela (se necessário)
6. Sistema aplica mudanças em tempo real
7. Sistema salva preferências no perfil do usuário

**Fluxos Alternativos**: Nenhum

**Fluxos de Exceção**: Nenhum

---

## UC07 - Desbloquear Medalha

**Ator Principal**: Sistema
**Ator Secundário**: Aluno
**Pré-condições**: Aluno completou critério de medalha
**Pós-condições**: Medalha adicionada ao perfil, notificação exibida

**Fluxo Principal**:
1. Sistema monitora ações do aluno
2. Sistema detecta conclusão de critério de medalha
3. Sistema marca medalha como conquistada
4. Sistema exibe animação de conquista
5. Sistema adiciona medalha ao perfil do aluno
6. Sistema registra conquista no histórico

**Fluxos Alternativos**: Nenhum

**Fluxos de Exceção**: Nenhum

---

## UC08 - Solicitar Ajuda de Colega

**Ator Principal**: Aluno Solicitante
**Ator Secundário**: Aluno Ajudante
**Pré-condições**: Aluno está em desafio, há colegas online que concluíram
**Pós-condições**: Pedido enviado, aguardando resposta

**Fluxo Principal**:
1. Aluno clica em "Pedir Ajuda a Colega"
2. Sistema verifica colegas elegíveis (online, já resolveram)
3. Sistema exibe lista de colegas disponíveis
4. Aluno seleciona colega
5. Sistema envia notificação ao colega
6. Colega aceita pedido
7. Sistema abre chat temporário
8. Alunos interagem via chat
9. Aluno solicitante marca ajuda como concluída
10. Sistema concede XP bônus ao ajudante
11. Sistema fecha chat

**Fluxos Alternativos**:
- 6a. Colega recusa ou não responde em 2 minutos
  - Sistema notifica solicitante
  - Sistema sugere outro colega
  - Retorna ao passo 4

**Fluxos de Exceção**:
- 2a. Nenhum colega elegível disponível
  - Sistema informa que nenhum colega está disponível
  - Sistema sugere usar dicas automáticas

---

## Diagrama de Casos de Uso Geral

```
                         +------------------+
                         |   ComputaPlay    |
                         +------------------+
                                 |
         +----------------------+----------------------+
         |                                             |
    [Aluno]                                      [Professor]
         |                                             |
         |--- UC01: Cadastrar/Autenticar               |--- UC03: Criar Turma
         |--- UC02: Resolver Desafio                   |--- UC04: Acompanhar Progresso
         |--- UC06: Ajustar Acessibilidade             |--- UC05: Gerar Relatório
         |--- UC07: Desbloquear Medalha                |--- UC06: Ajustar Acessibilidade
         |--- UC08: Solicitar Ajuda                    |--- UC21: Atribuir Tarefa
         |
    [Sistema]
         |--- UC07: Desbloquear Medalha (automático)
```

## Matriz de Rastreabilidade: Casos de Uso x Requisitos

| Caso de Uso | Requisitos Funcionais | Prioridade |
|-------------|----------------------|------------|
| UC01 | RF01 | Alta |
| UC02 | RF04, RF05, RF06, RF07, RF08 | Alta |
| UC03 | RF15, RF16 | Alta |
| UC04 | RF17, RF18 | Alta |
| UC05 | RF19 | Média |
| UC06 | RF28, RF29, RF30 | Alta |
| UC07 | RF08 | Média |
| UC08 | RF14 | Baixa |
