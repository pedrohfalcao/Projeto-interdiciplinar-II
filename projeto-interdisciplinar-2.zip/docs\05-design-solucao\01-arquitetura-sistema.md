# 5.1 ARQUITETURA DO SISTEMA

## Visão Geral

A plataforma ComputaPlay adota uma arquitetura **cliente-servidor** com separação clara entre front-end e back-end, seguindo o padrão **MVC (Model-View-Controller)** no back-end e **componentização** no front-end.

---

## Diagrama de Arquitetura de Alto Nível

```
┌─────────────────────────────────────────────────────────────┐
│                    CAMADA DE APRESENTAÇÃO                   │
│                        (Front-end)                          │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │   Web App    │  │  PWA Mobile  │  │  Admin Panel │    │
│  │  (React.js)  │  │   (React)    │  │   (React)    │    │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘    │
│         │                  │                  │            │
│         └──────────────────┴──────────────────┘            │
└─────────────────────────┬───────────────────────────────────┘
                          │
                    HTTP/HTTPS (REST API)
                    WebSocket (Real-time)
                          │
┌─────────────────────────▼───────────────────────────────────┐
│                   CAMADA DE APLICAÇÃO                       │
│                       (Back-end)                            │
│                                                             │
│  ┌────────────────────────────────────────────────────┐    │
│  │           API Gateway / Load Balancer              │    │
│  └──────────────────────┬─────────────────────────────┘    │
│                         │                                   │
│  ┌──────────────┬───────┴────────┬──────────────────┐     │
│  │              │                │                  │     │
│  │  ┌───────────▼──────────┐   ┌─▼──────────────┐  │     │
│  │  │  Serviço de          │   │  Serviço de    │  │     │
│  │  │  Autenticação (JWT)  │   │  Gamificação   │  │     │
│  │  └──────────────────────┘   └────────────────┘  │     │
│  │                                                  │     │
│  │  ┌──────────────────────┐   ┌────────────────┐  │     │
│  │  │  Serviço de          │   │  Serviço de    │  │     │
│  │  │  Desafios/Blocos     │   │  Relatórios    │  │     │
│  │  └──────────────────────┘   └────────────────┘  │     │
│  │                                                  │     │
│  │  ┌──────────────────────┐   ┌────────────────┐  │     │
│  │  │  Serviço de          │   │  Serviço de    │  │     │
│  │  │  Análise/Alertas     │   │  Comunicação   │  │     │
│  │  └──────────────────────┘   └────────────────┘  │     │
│  │                                                  │     │
│  └──────────────────────────────────────────────────┘     │
│                         │                                   │
│  ┌──────────────────────▼──────────────────────────┐       │
│  │         Camada de Persistência (ORM)            │       │
│  └──────────────────────┬──────────────────────────┘       │
└─────────────────────────┼───────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────┐
│                   CAMADA DE DADOS                           │
│                                                             │
│  ┌────────────────┐   ┌────────────────┐   ┌──────────┐   │
│  │   PostgreSQL   │   │     Redis      │   │  S3/CDN  │   │
│  │ (Dados Princ.) │   │    (Cache)     │   │ (Assets) │   │
│  └────────────────┘   └────────────────┘   └──────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## Componentes Detalhados

### 1. FRONT-END (Camada de Apresentação)

#### Tecnologia Principal: **React.js 18+**

**Justificativa**:
- Componentização reutilizável
- Virtual DOM para performance
- Ecossistema robusto
- Suporte a PWA (Progressive Web App)
- Comunidade ativa

#### Bibliotecas Complementares:

| Biblioteca | Propósito |
|-----------|-----------|
| **React Router** | Navegação entre páginas |
| **Redux Toolkit** | Gerenciamento de estado global |
| **React Query** | Cache e sincronização de dados do servidor |
| **Blockly** ou **Scratch Blocks** | Editor visual de programação em blocos |
| **Chart.js** ou **Recharts** | Gráficos e visualizações |
| **Tailwind CSS** | Estilização responsiva |
| **Framer Motion** | Animações e transições |
| **Axios** | Requisições HTTP |
| **Socket.io-client** | Comunicação em tempo real (WebSocket) |

#### Estrutura de Pastas (Front-end):

```
src/
├── components/
│   ├── common/         # Componentes reutilizáveis (Button, Input, Card)
│   ├── aluno/          # Componentes específicos do aluno
│   ├── professor/      # Componentes específicos do professor
│   └── acessibilidade/ # Wrappers de acessibilidade
├── pages/              # Páginas da aplicação
│   ├── AlunoDesafio.jsx
│   ├── ProfessorDashboard.jsx
│   └── ...
├── store/              # Redux store e slices
├── services/           # Camada de serviço (API calls)
├── hooks/              # Custom React hooks
├── utils/              # Funções utilitárias
├── constants/          # Constantes da aplicação
└── assets/             # Imagens, ícones, fontes
```

---

### 2. BACK-END (Camada de Aplicação)

#### Tecnologia Principal: **Node.js com Express.js**

**Justificativa**:
- JavaScript full-stack (mesma linguagem no front e back)
- Assíncrono e escalável
- NPM com vasto ecossistema
- Boa performance para I/O

**Alternativa**: **Python com FastAPI** (caso equipe tenha mais experiência)

#### Frameworks e Bibliotecas:

| Biblioteca | Propósito |
|-----------|-----------|
| **Express.js** | Framework web minimalista |
| **Prisma** ou **TypeORM** | ORM para banco de dados |
| **Passport.js** | Autenticação |
| **jsonwebtoken** | Geração e validação de JWT |
| **bcrypt** | Hash de senhas |
| **Socket.io** | WebSocket para real-time |
| **node-cron** | Agendamento de tarefas (análise de dificuldades) |
| **multer** | Upload de arquivos |
| **joi** ou **yup** | Validação de dados |
| **winston** | Logging |
| **helmet** | Segurança HTTP |
| **cors** | Configuração de CORS |

#### Estrutura de Pastas (Back-end):

```
server/
├── src/
│   ├── controllers/    # Lógica de controle (requisições/respostas)
│   ├── models/         # Modelos de dados (Prisma/TypeORM)
│   ├── services/       # Lógica de negócio
│   ├── routes/         # Definição de rotas da API
│   ├── middlewares/    # Middlewares (auth, validação, etc.)
│   ├── utils/          # Funções utilitárias
│   ├── config/         # Configurações (DB, JWT, etc.)
│   └── jobs/           # Tarefas agendadas (cron)
├── tests/              # Testes unitários e de integração
└── prisma/             # Schema do banco de dados
    └── schema.prisma
```

---

### 3. BANCO DE DADOS

#### Banco Principal: **PostgreSQL 14+**

**Justificativa**:
- Relacional robusto e confiável
- Suporte a JSON (flexibilidade para dados de blocos)
- ACID compliant
- Open-source e gratuito
- Escalável

**Alternativa**: **MySQL 8+** (caso infraestrutura exija)

#### Cache: **Redis**

**Usos**:
- Cache de sessões
- Cache de queries frequentes (ranking, estatísticas)
- Fila de tarefas (Bull queue)
- Pub/Sub para eventos em tempo real

---

### 4. AUTENTICAÇÃO E AUTORIZAÇÃO

#### Estratégia: **JWT (JSON Web Tokens)**

**Fluxo de Autenticação**:

```
1. Usuário envia credenciais (email/senha)
   ↓
2. Servidor valida credenciais
   ↓
3. Servidor gera JWT com payload:
   {
     userId: "uuid",
     role: "aluno" | "professor" | "admin",
     iat: timestamp,
     exp: timestamp (24h depois)
   }
   ↓
4. JWT retornado ao cliente
   ↓
5. Cliente armazena em localStorage (ou httpOnly cookie)
   ↓
6. Cliente envia JWT em header Authorization em requisições:
   Authorization: Bearer <token>
   ↓
7. Middleware valida JWT em cada requisição protegida
```

**Renovação de Token**:
- Access Token: 24 horas
- Refresh Token: 30 dias (httpOnly cookie)

---

### 5. API RESTful

#### Endpoints Principais:

##### Autenticação
```
POST   /api/auth/register            # Cadastro
POST   /api/auth/login               # Login
POST   /api/auth/refresh             # Renovar token
POST   /api/auth/logout              # Logout
POST   /api/auth/forgot-password     # Recuperar senha
```

##### Aluno
```
GET    /api/aluno/perfil             # Perfil do aluno
PUT    /api/aluno/perfil             # Atualizar perfil
GET    /api/aluno/desafios           # Listar desafios disponíveis
GET    /api/aluno/desafios/:id       # Detalhes do desafio
POST   /api/aluno/progresso          # Salvar progresso
POST   /api/aluno/concluir-desafio   # Marcar desafio como concluído
GET    /api/aluno/medalhas           # Listar medalhas
GET    /api/aluno/ranking            # Ver ranking da turma
```

##### Professor
```
POST   /api/professor/turma          # Criar turma
GET    /api/professor/turmas         # Listar turmas
GET    /api/professor/turma/:id      # Detalhes da turma
GET    /api/professor/alunos/:turmaId # Alunos da turma
GET    /api/professor/dashboard/:turmaId # Dashboard da turma
GET    /api/professor/alertas        # Alertas de dificuldades
POST   /api/professor/relatorio      # Gerar relatório
GET    /api/professor/planos-aula    # Planos de aula
```

##### Admin
```
POST   /api/admin/desafio            # Criar desafio
PUT    /api/admin/desafio/:id        # Editar desafio
DELETE /api/admin/desafio/:id        # Excluir desafio
GET    /api/admin/logs               # Logs do sistema
```

---

### 6. COMUNICAÇÃO EM TEMPO REAL

#### Tecnologia: **WebSocket (Socket.io)**

**Casos de Uso**:
- Desafios colaborativos (código sincronizado entre alunos)
- Notificações em tempo real (alertas para professor)
- Chat de ajuda entre alunos

**Eventos**:
```javascript
// Cliente → Servidor
socket.emit('entrar_desafio_colaborativo', { desafioId, alunoId });
socket.emit('atualizar_codigo', { codigo });

// Servidor → Cliente
socket.on('codigo_atualizado', (codigo) => { ... });
socket.on('nova_notificacao', (notificacao) => { ... });
```

---

### 7. ARMAZENAMENTO DE ARQUIVOS

#### Serviço: **AWS S3** ou **Cloudinary**

**Conteúdo Armazenado**:
- Avatares dos alunos
- Ícones de medalhas
- Imagens de desafios
- PDFs de planos de aula e atividades
- Relatórios gerados

---

### 8. SEGURANÇA

#### Medidas Implementadas:

1. **HTTPS Obrigatório** (SSL/TLS)
2. **Helmet.js** - Headers HTTP seguros
3. **CORS** configurado para domínios permitidos
4. **Rate Limiting** (express-rate-limit) - 100 req/15min por IP
5. **Sanitização de Inputs** (xss-clean, express-mongo-sanitize)
6. **Validação de Dados** (Joi/Yup)
7. **SQL Injection Protection** (ORM com prepared statements)
8. **Senhas com bcrypt** (cost factor 12)
9. **Tokens JWT** com expiração
10. **LGPD Compliance** - Criptografia de dados sensíveis

---

### 9. MONITORAMENTO E LOGGING

#### Ferramentas:

- **Winston** - Logging estruturado
- **Morgan** - HTTP request logger
- **Sentry** - Rastreamento de erros em produção
- **PM2** - Process manager e monitoramento (Node.js)

**Níveis de Log**:
- `error`: Erros críticos
- `warn`: Avisos importantes
- `info`: Informações gerais
- `debug`: Detalhes para debugging (só em dev)

---

### 10. ESCALABILIDADE

#### Estratégias:

1. **Horizontal Scaling**: Múltiplas instâncias do servidor atrás de load balancer
2. **Caching**: Redis para queries frequentes
3. **CDN**: Assets estáticos servidos via CDN (CloudFlare, AWS CloudFront)
4. **Database Indexing**: Índices otimizados em queries frequentes
5. **Lazy Loading**: Carregar componentes sob demanda
6. **Pagination**: Listar dados em páginas (não carregar tudo de uma vez)

---

## Fluxo de Dados - Exemplo: Resolver Desafio

```
1. [Aluno Front] Usuário arrasta blocos no editor
   ↓
2. [Aluno Front] Clica "Executar"
   ↓
3. [Aluno Front] Envia POST /api/aluno/concluir-desafio
   Body: { desafioId, codigo, tentativas, tempoGasto }
   Header: Authorization: Bearer <JWT>
   ↓
4. [Back] Middleware valida JWT
   ↓
5. [Back] Controller recebe requisição
   ↓
6. [Back] Service valida código contra solução esperada
   ↓
7. [Back] Service calcula XP (base + bônus - penalidades)
   ↓
8. [Back] Model atualiza ProgressoDesafio no PostgreSQL
   ↓
9. [Back] Service verifica critérios de medalhas
   ↓
10. [Back] Se medalha desbloqueada, insere em Aluno_Medalha
   ↓
11. [Back] Service verifica se aluno subiu de nível
   ↓
12. [Back] Retorna resposta JSON:
    {
      sucesso: true,
      xpGanho: 140,
      xpTotal: 590,
      nivelAtual: 6,
      medalhaDesbloqueada: { id, nome, icone }
    }
   ↓
13. [Aluno Front] Recebe resposta
   ↓
14. [Aluno Front] Atualiza Redux store
   ↓
15. [Aluno Front] Exibe animação de sucesso
   ↓
16. [Aluno Front] Navega para próximo desafio
```

---

## Deployment (Implantação)

### Ambiente de Desenvolvimento:
- **Front**: `localhost:3000`
- **Back**: `localhost:5000`
- **DB**: `localhost:5432` (PostgreSQL)
- **Redis**: `localhost:6379`

### Ambiente de Produção:

#### Opção 1: **Vercel (Front) + Heroku (Back + DB)**
- **Vantagens**: Fácil deploy, gratuito para pequenos projetos
- **Limitações**: Performance limitada no free tier

#### Opção 2: **AWS (Full Stack)**
- **Front**: S3 + CloudFront (CDN)
- **Back**: EC2 ou Elastic Beanstalk
- **DB**: RDS (PostgreSQL)
- **Cache**: ElastiCache (Redis)
- **Vantagens**: Escalável, profissional
- **Desvantagens**: Custo mais alto

#### Opção 3: **DigitalOcean (App Platform)**
- Meio termo entre facilidade e controle
- Custo acessível
- Boa documentação

---

## Tecnologias em Resumo

| Camada | Tecnologia | Versão Mínima |
|--------|------------|---------------|
| **Front-end Framework** | React.js | 18.2+ |
| **State Management** | Redux Toolkit | 1.9+ |
| **Block Editor** | Blockly | 9.0+ |
| **Styling** | Tailwind CSS | 3.3+ |
| **Back-end Runtime** | Node.js | 18 LTS |
| **Back-end Framework** | Express.js | 4.18+ |
| **ORM** | Prisma | 5.0+ |
| **Banco de Dados** | PostgreSQL | 14+ |
| **Cache** | Redis | 7.0+ |
| **Autenticação** | JWT | - |
| **Real-time** | Socket.io | 4.5+ |
| **Testes** | Jest + Testing Library | - |
